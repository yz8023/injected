调用com.lingmeng.CloudText.string方法，该方法为string类型

示例:

	const-string p0, "URL"

	invoke-static {p0}, Lcom/lingmeng/CloudText;->string(Ljava/lang/String;)Ljava/lang/String;

	move-result-object p0

QQ收藏内容格式为:【内容】自定义文本【/内容】

拉取失败后会显示预设文本"Default"

如有需要自行修改正则和预设文本，dex未加密混淆

By Lingmeng