#by 逗比滑稽
DexTool
工具版本：1.4
工具介绍：此工具的初衷是打算给无root的逆向分析者提供一些简单的分析帮助
目前工具提供的功能：
PrintLog：日志打印，堆栈打印
DeviceID：伪造Android，随机id
ViewClickEventListener：点击事件监听器
DialogListener：弹窗监听器
TextViewListener：文本赋值监听器
ActivityJumpListener：活动跳转监听器
SPListener：SP读写监听器
AllView：视图劫持器
ReflectTool：反射工具

目前只提供以上这些功能支持
注意：部分功能并不能完全监听
日志会打印在
/storage/emulated/0/Android/data/目标应用包名/files/Main.log

#另外，在写这工具我有立一个优先级
#使用方便(能实现目的的情况) > 功能目的 > 兼容性 > 性能
#所以某些功能虽然实现了目的，但实现原理不成熟（极其拉胯
#使用起来也不是很方便(有几个功能不能做到完全监听)
#甚至可能会出现崩溃的情况，所以工具为了实现某些目的是很随意的
【还请以娱乐性看待此工具】

————————————————————
类：PrintLog
作用：打印日志，获取调用堆栈
原理：null
说明：考虑到此工具顶多拿来打印几个数据点(毕竟多的话为啥不用mt?）
所以代码处理数据都在主线程处理，当然也不排除打印大型数据
如果要启用子线程打印日志，可以调用以下代码开启
或者说直接把PrintLog.Thread字段改成true
#启动子线程打印日志
invoke-static {}, Lcom/doubihuaji/Tool/PrintLog;->setPrintLogThread()V


#这里另外给小白提个醒，如果打印的数据是九大基本数据类型(除String)的话
#请勿使用对象打印(会报错)，需要使用对应的调用代码

#对象打印：
invoke-static {v0}, Lcom/doubihuaji/Tool/PrintLog;->Printlog(Ljava/lang/Object;)V


#调用堆栈打印：
invoke-static {}, Lcom/doubihuaji/Tool/PrintLog;->PrintStack()V


#八大基本类型打印：

#int：
invoke-static {v0}, Lcom/doubihuaji/Tool/PrintLog;->Printint(I)V


#long：
invoke-static {v0, v1}, Lcom/doubihuaji/Tool/PrintLog;->Printlong(J)V


#boolean：
invoke-static {v0}, Lcom/doubihuaji/Tool/PrintLog;->Printboolean(Z)V


#char：
invoke-static {v0}, Lcom/doubihuaji/Tool/PrintLog;->Printchar(C)V


#short：
invoke-static {v0}, Lcom/doubihuaji/Tool/PrintLog;->Printshort(S)V


#byte：
invoke-static {v0}, Lcom/doubihuaji/Tool/PrintLog;->Printbyte(B)V


#double：
invoke-static {v0, v1}, Lcom/doubihuaji/Tool/PrintLog;->Printdouble(D)V


#float：
invoke-static {v0}, Lcom/doubihuaji/Tool/PrintLog;->Printfloat(F)V



————————————————————
类：ReflectTool
作用：反射
原理：反射
说明：
所有日志文件都会写入至
/storage/emulated/0/Android/data/包名/files/ReflectTool
具体使用方法请看文档

#请将调用代码插入至application的onCreate方法

#调用
invoke-static {p0}, Lcom/doubihuaji/Tool/ReflectTool;->init(Landroid/app/Application;)V



————————————————————
类：DeviceID
作用：伪造Android_id，随机ID
原理：【ProxyAndroid_id】反射代理Settings$ContentProviderHolder类mContentProvider字段实例
说明：ProxyAndroid_id能够破坏以下代码获取设备id逻辑
Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID)
调用代码尽好插在较早能够调用的地方，比如onCreate

#伪造Android_id调用
invoke-static {}, Lcom/doubihuaji/Tool/DeviceID;->ProxyAndroid_id()V


#伪造Android_id调用
#如果要每间隔一段时间再进行随机，则调用以下代码
#时间单位是分钟，可以根据自身情况调解
const v0, 0x0

invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->ProxyAndroid_id(I)V


#1小时
const v0, 0x3c

invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->ProxyAndroid_id(I)V


#6小时
const v0, 0x168

invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->ProxyAndroid_id(I)V


#12小时
const v0, 0x2d0

invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->ProxyAndroid_id(I)V


#24小时
const v0, 0x1d10

invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->ProxyAndroid_id(I)V



#当然怎么少得了手动调用的随机字符串
#而且考虑到某些极端的需求🙃，所以我提供了亿些api

#另外，如果你需要UUID类型的id(下面例子)
#3c5e62d9-cd7d-407d-aaa7-ab3998b6de60
#你可以先用下面的代码随机“任意”一串字符串(不能是null或者空值)
#然后调用以下代码即可转换成UUID(注：传入的值转换的UUID是固定的不是随机的)

#字符串转UUID
invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->toUUID(Ljava/lang/String;)Ljava/lang/String;

move-result-object v0


#最后提一嘴，此工具提供一个空方法A_getString，你问我为什么提供这个？🤔
#如果用带参的随机id代码，在smali插代码难免因为寄存器分配问题不好赋值
#由此就提供这个空方法节省不必要的麻烦
invoke-static {}, Lcom/doubihuaji/Tool/DeviceID;->A_getString()Ljava/lang/String;

move-result-object v0


#随机id代码


#随机由abcdef123456790组成的16位字符串
invoke-static {}, Lcom/doubihuaji/Tool/DeviceID;->getRandomID()Ljava/lang/String;

move-result-object v0


#随机由abcdef123456790组成的16位字符串(只获取每次打开应用第一次随机的id，之后每次调用都只返回第一次获取的随机id)
invoke-static {}, Lcom/doubihuaji/Tool/DeviceID;->getKeyRandomID()Ljava/lang/String;

move-result-object v0


#随机由abcdef123456790组成的16位字符串(每间隔一段时间才进行获取)
#间隔时间(时间单位：分钟)
const v0, 0x3c

invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->getRandomID(I)Ljava/lang/String;

move-result-object v1


#功能同上(只不过可以随机多个id，由键值取对应的值)
#(键值：你可以理解这是取件码，如果这个取件码里边没有东西，则会存储一段随机id并返回此随机id，之后再输入这个取件码就会返回之前存储的随机id)
#键值
const-string v0, "key"

invoke-static {v0}, Lcom/doubihuaji/Tool/DeviceID;->getKeyRandomID(Ljava/lang/String;)Ljava/lang/String;

move-result-object v0


#功能同上(可以设定间隔时间随机id)
#键值
const-string v0, "key"
#间隔时间(时间单位：分钟)
const/4 v1, 0x3c

invoke-static {v0, v1}, Lcom/doubihuaji/Tool/DeviceID;->getKeyRandomID(Ljava/lang/String;I)Ljava/lang/String;

move-result-object v0


#随机自定义字符和长度的字符串
#随机的特征字符
const-string v0, "0123456789abcdef"
#长度
const v1, 0x10

invoke-static {v0, v1}, Lcom/doubihuaji/Tool/DeviceID;->getRandomStr(Ljava/lang/String;I)Ljava/lang/String;

move-result-object v0


#随机自定义字符和长度的字符串(每次打开应用只随机一次，之后每次此调用方法都获取第一次的随机id)
#随机特征字符
const-string v0, "0123456789abcdef"
#长度
const v1, 0x10

invoke-static {v0, v1}, Lcom/doubihuaji/Tool/DeviceID;->getKeyRandomStr(Ljava/lang/String;I)Ljava/lang/String;

move-result-object v0


#功能同上(可以设定间隔时间随机id)
#随机特征字符
const-string v0, "0123456789abcdef"
#长度
const v1,0x10
#间隔时间(时间单位：分钟)
const v2, 0x3c

invoke-static {v0, v1, v2}, Lcom/doubihuaji/Tool/DeviceID;->getKeyRandomStr(Ljava/lang/String;II)Ljava/lang/String;

move-result-object v0


#随机自定义字符和长度的字符串(可得到多个随机id，根据键值取对应的随机id)
#随机特征字符
const-string v0, "0123456789abcdef"
#长度
const v1, 0x10
#键值
const-string v2, "key"

invoke-static {v0, v1, v2}, Lcom/doubihuaji/Tool/DeviceID;->getKeyRandomStr(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

move-result-object v0


#功能同上(可以设定间隔时间随机id)
#随机特征字符
const-string v0, "0123456789abcdef"
#长度
const v1, 0x10
#键值
const-string v2, "key"
#间隔时间(时间单位：分钟)
const v3, 0x3c

invoke-static {v0, v1, v2, v3}, Lcom/doubihuaji/Tool/DeviceID;->getKeyRandomStr(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;

move-result-object v0



————————————————————
类：ViewClickEventListener
作用：监听View点击事件
原理：反射代理ViewOutlineProvider.BACKGROUND字段
这个点在View构建视图控件附加到窗口的时候会走一个抽象方法getOutline
工具通过实现该抽象类替代了ViewOutlineProvider.BACKGROUND字段实例的工作
在View走入getOutline抽象方法的时候，劫持原本的点击事件并替换为工具自实现点击事件达成监听目的

说明：此工具是测试性阶段工具，因为反射代理点的关系
所以我不确定应用内存会不会被工具子线程灌成奶油泡芙😕(具体看代码就明白为什么了)
此工具会监听使用此类代码实现的点击事件
View.setOnClickListener
在成功监听到某控件点击事件时，你只需要触碰该控件就会自动打印堆栈日志
需要注意的是，此工具只能打印到点击事件的“实现类”，其余的堆栈信息是假的。
初始化代码最好插入在第一个启动的Activity类比较早调用的方法，比如init,onCreate,onStart

#初始化：
invoke-static {}, Lcom/doubihuaji/Tool/ViewClickEventListener;->init()V



————————————————————
类：DialogListener
作用：监听/拦截 Dialog/Toast弹窗
原理：
【Dialog】注册activity生命周期回调，在执行onCreate方法回调时获取窗口服务实例劫持监听视图追加字段
窗口每次添加视图都将被代理类获取到，如果此次追加视图来自Dialog堆栈则进行捕获日志
【Toast】反射代理Toast.sService字段

【黑名单】通过弹窗调用堆栈生成一个弹窗伪唯一标识令牌提供用户查看
如果在触发日志打印条件时判断此弹窗令牌是否为用户输入的指定令牌
如果是则进行以下操作：
【Toast】拦截enqueueTextToast与enqueueTextToast方法防止弹出
【Dialog】生成一个子线程死循环判断直到Dialog显示到窗口，接着立即删除该弹窗视图
(这是因为追加弹窗视图在给Activity显示弹窗视图的前面，所以不能移除视图比显示视图快)

说明：
Toast与Dialog在显示时就会捕获堆栈日志
如果要拦截指定弹窗，捕获到该弹窗日志
通过日志找到这个弹窗调用堆栈
将这个弹窗的Token输入到DialogListener类的$Blacklist$方法即可触发拦截

不过请注意，如果使用黑名单机制拦截，那么这个类调用代码就不能移除
如果你要关闭烦人的堆栈日志
请在DialogListener类的$Blacklist$黑名单方法加入此字符串(区分大小写)：
Close

这一版的Toast监听方案还是会受到灰名单限制版本无法监听
如果apk的sdk＞28监听就会失效，黑名单拦截功能也会受到影响
(如果要解除这个问题，要自行将Axml的targetSdkVersion修改至＜= 28)


#请将代码插入至Application的onCreate方法

#代码：
invoke-static {p0}, Lcom/doubihuaji/Tool/DialogListener;->init(Landroid/app/Application;)V



————————————————————
类：TextViewListener
作用：监听控件setText文本赋值
原理：
TextView.setFilters方法的作用是一个文本过滤器
它可以实现在调用setText的时候对赋值的文本进行一个过滤修改后再显示给用户
比如对文本内容的字母全修改为大写后再显示给用户
在新实例化一个TextView对象是默认没有过滤器的
这时在init初始化会通过静态NO_FILTERS给予一个空数组
告诉代码这个TextView对象没有过滤器，不用对文本进行过滤修改
工具通过反射代理NO_FILTERS字段，将其添加一个用于监听文本的过滤器
这样在每个新实例化的TextView对象都默认添加一个监听文本赋值的监听器达成监听目的

说明：原理很简单粗暴，但这也浮现他的一个缺陷
如果这个TextView在原代码中重新调用了setFilters方法
这会使我们工具的过滤器被替换掉，也就是说这个对象赋值的文本我们无法监听(但谁没事用setFilters添加过滤器，就算有也是一小部分，所以该工具还是能监听大部分文本的)
不过有一点就需要注意了，因为NO_FILTERS字段有灰名单版本限制
如果apk的sdk＞28监听就会失效，
(如果要解除这个问题，要自行将Axml的targetSdkVersion修改至＜= 28)
#请将代码插入到Activity最早能调用的地方，哪怕是static都可以

#代码：
invoke-static {}, Lcom/doubihuaji/Tool/TextViewListener;->init()V


————————————————————
类：ActivityJumpListener
作用：监听startActivity相关页面跳转事件
原理：通过Application注册activity生命周期回调，得到每个Activity类的Instrumentation对象
重新实例一个Instrumentation对象并重写execStartActivity方法成为其代理类，并反射Activity.mInstrumentation字段将实例给予activity
(Activity的StartActivity方法最终实现方法是由Instrumentation的execStartActivity实现的)

说明：
同样，这个和上面的功能有一个缺陷
因为Activity.mInstrumentation字段有灰名单版本限制
如果apk的sdk＞28监听就会失效
(如果要解除这个问题，要自行将Axml的targetSdkVersion修改至＜= 28)

#请将调用代码插入到application类的onCreate方法里

#代码：
invoke-static {p0}, Lcom/doubihuaji/Tool/ActivityJumpListener;->init(Landroid/app/Application;)V



#如果application没有onCreate方法，请在此类添加以下代码
.method public onCreate()V
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 15
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 17
    invoke-static {p0}, Lcom/doubihuaji/Tool/ActivityJumpListener;->init(Landroid/app/Application;)V

    return-void
.end method



————————————————————
类：AllView
作用：遍历当前Activity页面所有视图/定位追加视图位置
原理：
【遍历】通过findViewById解析android.R.id.content父视图，遍历其所有的控件
(通过setContentView方法设置页面布局的，最终布局都会被添加到android.R.id.content父视图)
【定位视图位置】对android.R.id.content父视图添加布局更改监听器(setOnHierarchyChangeListener)

说明：使用该功能需要将调用代码插入至Application的onCreate方法里
在需要查询的控件页面点右上角的getView按钮截取该页面控件的日志文件
日志文件格式如下
activity-View.log
  ↑
截取页面的活动名称，会因你截取的页面产生变化

文件主要记录这个页面的所有控件信息
日志例子如下：
ViewClass：com.doubihuaji.app.MainActivity           ←截取页面的类名
Parent：android.widget.LinearLayout{a7f9870 V.E...... ........ 0,0-1440,2884 #666666}    ←截取这控件的父视图，日志内容是父视图实例强转字符串而来
ParentID：666666           ←父视图资源id
TYPE：android.widget.TextView           ←控件的类型
Value：android.widget.TextView{ac4fc6e V.ED..... ........ 0,51-126,117}           ←控件实例强转字符串而来
ID：-1           ←控件资源id#View.getId()            -1表示没有资源id
️Tag️：null           ←控件标签#View.getTag()
⭐️Tag⭐️️：【ᇳᶞड़ᄧ⨚߂⬣⼀ᵎ╷】           ←⭐️特殊标签
ClickEvent：null           ←控件点击事件#(没有则null表示)
LongClickEvent：null           ←控件的长按事件
Text：升天✝           ←控件文本#TextView.getText()
TextChangedListener：null           ←控件的文本更改监听器

截取页面之后大概会得到如上方的信息
当你在日志文件找到了你想找的控件的信息时
请看该控件信息的⭐️Tag⭐️属性

【⭐️Tag⭐️】由工具主动标记的特殊标签，大部分控件都会拥有此⭐️Tag⭐️属性
这个属性的符号是独一无二的，也就是说每个控件只有这一个
将这个属性包括符号【】一同复制，然后打开Main.log日志文件

【Main.log】负责监听运行时控件所调用位置堆栈
这个⭐️Tag⭐️可以在Main.log日志定位这个控件追加位置堆栈
从而方便工具使用者更容易找到该控件在代码具体方法位置


另外，这个⭐️Tag⭐️标签还有一个特别用处
如果你在应用调用了这个工具，使用Auto.js查看这个应用布局某个控件
#(其它的查布局工具应该也能查到，只要查布局工具支持查询ContentDescription属性)
你会发现这个控件能直接看到特殊标签
没错，即使你不使用工具的截取Activity遍历View的功能
你也能通过查布局工具得到特殊标签
拿着这个标签打开Main.log文件也能找到该控件调用位置



⚠️最后注意事项：⭐️Tag⭐️虽然会给独一无二的标签
但如果你退出应用重新打开
这个标签会重新刷新
请注意Main.log日志文件和Activity-View.log文件是在同一次打开应用产生的



//////////////////////////////附加功能//////////////////////////////////////////////////
#这是1.3版本更新对AllView功能的改进
#对窗口新增了两个按钮
#【getImage】
#该按钮可以截取当前activity所有ImageView的图像图片
#图像会存储到存放Main.log文件所处目录的子目录Image文件夹
#/storage/emulated/0/Android/data/包名/files/Image

#【getImage2】
#该功能同上
#但可以获取指定“区域内所有image图像”或者单独一个图像
#只要输入你要获取这个区域或者ImageView的特殊标签就可以截取该图像并存储至Image文件夹
#至于你怎么得到这个标签，当然是用查布局工具了
#标签可以带多余字符，这是给使用Auto.js的用户一个方便
#因为使用Auto.js复制内容会多携带多余字符 例如：desc('【Ẕ༻ǧᙦ⪥ᶽ⎳ᨂᲁṻ】')
#但请确保【】符号在这文本当中
//////////////////////////////////////////////////////////////////////////////////////////



#请将调用代码插入至application的onCreate方法

#调用
invoke-static {p0}, Lcom/doubihuaji/Tool/AllView;->init(Landroid/app/Application;)V



#如果application没有onCreate方法，请在此类添加以下代码
.method public onCreate()V
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 15
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 17
    invoke-static {p0}, Lcom/doubihuaji/Tool/AllView;->init(Landroid/app/Application;)V

    return-void
.end method




————————————————————
类：SPListener
作用：监听SP读写删行为
原理：代理ContextWrapper类mBase字段，重写getSharedPreferences方法返回自身实例代理类
说明：
真c蛋，重写了那么多版终于实现了🍋
也算是补回了之前的功能
(之前明明试过这个方法 但不知道为何失败了🤓)
使用此功能可以监听SharedPreferences的读写删行为
以及调用的部分方法，应用存储值或者获取值时日志将会自动打印

以下是部分日志信息解读

SPName<-存储文件名称
Key<-键值
defValue<-默认值
retValue<-返回值
setValue<-设置值

#如果你觉得堆栈信息很烦人，你只是想分析应用设置了些什么值
#可以通过正则剔除：
#—{6}【Stack】—{6}[\s\S]+?(?=—{6})



#请将调用代码插入至application的onCreate方法

#调用
invoke-static {p0}, Lcom/doubihuaji/Tool/SPListener;->init(Landroid/content/ContextWrapper;)V




————————————————————