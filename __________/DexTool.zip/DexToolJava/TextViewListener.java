package com.doubihuaji.Tool;
import android.text.InputFilter;
import android.text.Spanned;
import java.io.IOException;
import java.lang.reflect.Field;

//TextViewListener
//作用：监听文本赋值
public class TextViewListener implements InputFilter {

	private static Main main;

	private TextViewListener() throws IOException {
		main = new Main("/Main.log");
		main.setConfig();
	}

    public static void init() {
		try {
			//判断sdk版本，因为字段灰名单版本的限制，只能在sdk < 28的情况使用
			if (Main.getContext().getApplicationInfo().targetSdkVersion > 28) {
				return;
			}
			//获取TextView类
			Class<?> C_TextView = Class.forName("android.widget.TextView");
			//从TextView类获取NO_FILTERS字段
			Field F_NO_FILTERS = C_TextView.getDeclaredField("NO_FILTERS");
			//设置访问权限
			F_NO_FILTERS.setAccessible(true);
			//实例化自身并把实例给予NO_FILTERS字段
			TextViewListener Listener = new TextViewListener();
			F_NO_FILTERS.set(null, new InputFilter[]{Listener});
		} catch (Exception e) {}
	}

	@Override
	public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
		//监听写入文本内容但不对文本做任何处理
		Write(source);
		return source;
	}

	private void Write(CharSequence source) {
		try {
			//过滤无效监视
			String Stack = PrintLog.getstack();
			//控件实例化时
			if (Stack.contains("android.widget.TextView-><init>")
			//标题栏调用时
				|| Stack.contains("android.widget.Toolbar->setTitle")) {
				return;
			}
			String str = source.toString();
			String[] BStack = PrintLog.splitStack(PrintLog.getstack(3));
			main.WriteLog(BStack[0],
						  BStack[1],
						  "TextListener：" + str.length() + " length",
						  str
						  + "\n——————【Stack】——————\n"
						  + Stack.split("\n", 3)[2])
				.flush();
		} catch (IOException e) {
			throw new RuntimeException("TextViewListener输出流异常：" + e.toString());
		}
	}

}
