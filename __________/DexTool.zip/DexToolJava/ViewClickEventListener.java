package com.doubihuaji.Tool;
import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

//ViewClickEventListener
//作用：劫持View控件的点击事件
public class ViewClickEventListener extends ViewOutlineProvider 
implements Runnable,View.OnClickListener {

	private ViewOutlineProvider Instance;

	private View view;

	private View.OnClickListener Click;

	private static Main main;

	private ViewClickEventListener(ViewOutlineProvider Instance) {
		this.Instance = Instance;
	}

	private ViewClickEventListener(View view) {
		this.view = view;
	}

    public static void init() {
		try {
			main = new Main("/Main.log");
			main.setConfig("onClickEvent");
			//获取ViewOutlineProvider类
			Class<?> c_ViewOutlineProvider = ViewOutlineProvider.class;
			//从ViewOutlineProvider类获取BACKGROUND字段
			Field f_BACKGROUND = c_ViewOutlineProvider.getField("BACKGROUND");
			//设置为可访问
			f_BACKGROUND.setAccessible(true);
			//获取BACKGROUND字段实例
			Object i_ViewOutlineProvider = f_BACKGROUND.get(null);
			//实例自身并替换BACKGROUND字段实例
			f_BACKGROUND.set(null, new ViewClickEventListener((ViewOutlineProvider)i_ViewOutlineProvider));
		} catch (Exception e) {
			//失败
			throw new RuntimeException("ViewClickEventListener初始化失败：" + e.toString());
		}
	}

	@Override
	public void run() {
		try {
			//获取view类
			Class<?> c_View = View.class;
			//获取view类getListenerInfo方法
			Method m_getListenerInfo = c_View.getDeclaredMethod("getListenerInfo");
			//设置可访问
			m_getListenerInfo.setAccessible(true);
			//执行方法获取View$ListenerInfo实例
			Object View$ListenerInfo = m_getListenerInfo.invoke(view);
			//获取View$ListenerInfo类
			Class<?> c_View$ListenerInfo = View$ListenerInfo.getClass();
			//从View$ListenerInfo类获取mOnClickListener字段
			Field f_mOnClickListener = c_View$ListenerInfo.getDeclaredField("mOnClickListener");
			//设置可访问
			f_mOnClickListener.setAccessible(true);
			//休眠3s
			Thread.sleep(3000);
			//执行循环
			for (int i = 0; i < 5; i++) {
				//获取点击事件实例
				Object obj = f_mOnClickListener.get(View$ListenerInfo);
				//如果有点击事件则替换为自身点击事件
				if (obj != null) {
					Click = (View.OnClickListener) obj;
					view.setOnClickListener(this);
					break;
				}
				//没有则休眠3s
				Thread.sleep(3000);
			}
		} catch (Exception e) {
			//失败
			throw new RuntimeException("ViewClickEventListener子线程异常：" + e.toString());
		}
	}

	@Override
	public void onClick(View v) {
		//走回原来点击事件
		Click.onClick(v);
		try {
			Class<?> name = Click.getClass();
			main.WriteLog(
				name.getName(),
				"onClick",
				null,
				name.getName()
				+
				"->onClick("
				+
				name.getSimpleName()
				+
				".java:-1)\n"
				+
				PrintLog.getstack()
			).flush();
		} catch (IOException e) {
			throw new RuntimeException("ViewClickEventListener输出流异常：" + e.toString());
		}
	}

	@Override
	public void getOutline(View view, Outline outline) {
		Instance.getOutline(view, outline);
		if (!PrintLog.getstack(1).startsWith("android.view.View->onAttachedToWindow")) {
			return;
		}
		//实例自身并把控件参数存入字段内
		ViewClickEventListener viewclickeventlistener = new ViewClickEventListener(view);
		//线程执行
		new Thread(viewclickeventlistener).start();
	}

}
