package com.doubihuaji.Tool;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

//ReflectTool
//作用：反射工具(YYDS!)
public class ReflectTool
implements Application.ActivityLifecycleCallbacks,
    DialogInterface.OnClickListener {

        public Activity activity;

        //对象管理器
        static Map < String, Object > ObjectManager;

        //全局(存储所有唯一标识NewButton控件)
        static Map < Long, NewButton > ButtonViewManager;

        //当前activityButton
        static Map < Activity, Map < Long, NewButton >> currentActivityButtonView;

        //最新按钮坐标
        static Map < Long, WindowManager.LayoutParams > currentXY;

        public ReflectTool() {

        }

        //调用
        public static void init(Application app) {
            ReflectTool Instance = new ReflectTool();
            ObjectManager = new HashMap < String, Object > ();
            ButtonViewManager = new HashMap < Long, NewButton > ();
            currentActivityButtonView = new HashMap < Activity, Map < Long, NewButton >> ();
            currentXY = new HashMap < Long, WindowManager.LayoutParams > ();
            app.registerActivityLifecycleCallbacks(Instance);
        }

        @Override
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
            this.activity = activity;
            currentActivityButtonView.put(activity, new HashMap < Long, NewButton > ());
            if (activityinit()) {
                return;
            }
            //第一个activity启动时会执行
            NewButton MainButton = new NewButton(this, null);
            MainButton.setButtonText("新建类")
                .setId(NewClassEvent)
                .setButtonTextColor(Color.RED)
                .show();

            NewButton Main2Button = new NewButton(this, null);
            Main2Button.setButtonText("新建实例类")
                .setId(NewClassInstance)
                .setButtonTextColor(Color.RED)
                .show();

            NewButton Main3Button = new NewButton(this, null);
            Main3Button.setButtonText("快速获取")
                .setId(fastGetInstanceEvent)
                .setButtonTextColor(Color.YELLOW)
                .show();

            NewButton Main4Button = new NewButton(this, null);
            Main4Button.setButtonText("拆分数组")
                .setId(splitArrayEvent)
                .setButtonTextColor(Color.parseColor("#FFFF8C00"))
                .show();
        }
        @Override
        public void onActivityDestroyed(Activity activity) {}
        @Override
        public void onActivityPaused(Activity activity) {}
        @Override
        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

        @Override
        public void onActivityStarted(Activity activity) {
            this.activity = activity;
            ObjectManager.put("this@activity", activity);
            ObjectManager.put("this@application", activity.getApplication());
        }
        @Override
        public void onActivityStopped(Activity activity) {}

        @Override
        public void onActivityResumed(Activity activity) {
            this.activity = activity;
            try {
                //表示第一次启动
                boolean startactivity = false;

                //每次启动活动检查控件是否同步
                Map < Long, NewButton > current = currentActivityButtonView.get(activity);

                if (current != null && current.size() < 2) {
                    startactivity = true;
                }

                //销毁视图
                Map < Long, NewButton > Cache = new HashMap < Long, NewButton > ();
                Iterator < Map.Entry < Long, NewButton >> It = current.entrySet().iterator();
                while (It.hasNext()) {
                    Map.Entry < Long, NewButton > entry = It.next();
                    //如果当前活动的特征码不存在于管理器则销毁视图
                    if (ButtonViewManager.get(entry.getKey()) == null) {
                        //存储起来后再销毁
                        Cache.put(entry.getKey(), entry.getValue());
                    }
                }

                //销毁
                for (Map.Entry < Long, NewButton > entry: Cache.entrySet()) {
                    current.remove(entry.getKey());
                    entry.getValue().removeView();
                }

                //创建视图
                //List<NewButton> Cache2 = new ArrayList<NewButton>();
                Iterator < Map.Entry < Long, NewButton >> It2 = ButtonViewManager.entrySet().iterator();
                while (It2.hasNext()) {
                    Map.Entry < Long, NewButton > entry = It2.next();
                    if (current.get(entry.getKey()) == null) {
                        NewButton button = NewButtonView(entry.getValue(), false);
                        current.put(button.code, button);
                        //Cache2.add(button);
                    }
                }

                //存储起来后处理
                //for(NewButton newbutton : Cache2){
                //ButtonViewManager.put(newbutton.code,newbutton);
                //}

                if (!startactivity) {
                    //刷新视图xy坐标
                    Iterator < Map.Entry < Long, WindowManager.LayoutParams >> It3 = currentXY.entrySet().iterator();
                    while (It3.hasNext()) {
                        Map.Entry < Long, WindowManager.LayoutParams > entry = It3.next();
                        NewButton button = current.get(entry.getKey());
                        WindowManager.LayoutParams Params = entry.getValue();
                        if (button != null) {
                            button.getParams().x = Params.x;
                            button.getParams().y = Params.y;
                            button.updateView();
                        }

                        //管理器中的视图(fuck,原控件坐标不同步问题搞不定)
                        //因为进入新activity，加载视图逻辑会从ButtonViewManager取值加载
                        //也由此不会受到上方代码影响
                        //                NewButton button2 = ButtonViewManager.get(entry.getKey());
                        //                if (button2 != null && button != null) {
                        //					if(button2.context == activity){
                        //							button2.getParams().x = Params.x;
                        //							button2.getParams().y = Params.y;
                        //							button2.updateView();
                        //							ButtonViewManager.put(entry.getKey(), button2);
                        //					}
                        //                }
                    }
                }

                currentXY = new HashMap < Long, WindowManager.LayoutParams > ();
                currentActivityButtonView.put(activity, current);
            } catch (Exception e) {
                Toast.makeText(activity, "啊欧：" + e.toString(), 1).show();
            }
        }

        //初始化布局
        private boolean activityinit() {
            //管理器为3则不加载
            int size = ButtonViewManager.size();
            if (size == 0) {
                return false;
            }
            //将重新实例化的视图存入当前活动
            Map < Long, NewButton > map = currentActivityButtonView.get(activity);
            //否则重新实例化所有NewButton
            for (Map.Entry < Long, NewButton > entry: ButtonViewManager.entrySet()) {
                NewButton button = entry.getValue();
                button = NewButtonView(button, false);
                map.put(button.code, button);
            }
            currentActivityButtonView.put(activity, map);
            return true;
        }

        //StorageView 表示是否将该视图记录到管理器 true同意
        private NewButton NewButtonView(NewButton button, boolean SaveView) {
            WindowManager.LayoutParams Params = new WindowManager.LayoutParams();
            Params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            Params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            Params.type = 2;
            Params.flags = 8;
            Params.format = 1;
            Params.gravity = Gravity.LEFT;
            Params.x = button.getButtonParams().x;
            Params.y = button.getButtonParams().y;
            //重新实例化类管理器
            try {
                ClassManager Class = null;
                if (button.getManager() != null) {
                    Class = new ClassManager(activity, button.getManager().toClass(), button.getManager().getInstance());
                }
                NewButton NewInstance = new NewButton(this, Class, button);
                NewInstance.setId(button.getId());
                if (SaveView) {
                    NewInstance.show();
                } else {
                    NewInstance.Show2();
                }
                return NewInstance;
            } catch (Exception e) {
                throw new RuntimeException("ReflectTool.NewButtonView初始化失败：" + e.toString());
            }
        }

        //窗口按钮click
        public static final int NewClassEvent = 0xFFFFFF01;
        public static final int ClassManagerEvent = 0xFFFFFF02;
        public static final int NewClassInstance = 0xFFFFFF03;
        public static final int fastGetInstanceEvent = 0xFFFFFF04;
        public static final int splitArrayEvent = 0xFFFFFF05;
        public void onButtonClick(NewButton Instance) {
            EditText edit, edit2;
            switch (Instance.getId()) {
                //创建类弹窗
                case NewClassEvent:
                    edit = new EditText(activity);
                    edit.setHint("com.xxx.xxx");
                    edit.setId(0xF1);
                    edit.setBackgroundTintList(null);
                    edit.setSingleLine(true);

                    AlertDialog.Builder Dia = new AlertDialog.Builder(activity);
                    Dia.setTitle("NewClass")
                        .setMessage("新建类")
                        .setView(edit)
                        .setPositiveButton("创建", this)
                        .show();
                    DialogEvent = NewClassDialogEvent;
                    break;
                    //创建类实例弹窗
                case NewClassInstance:
                    LinearLayout Linear = new LinearLayout(activity);
                    Linear.setOrientation(LinearLayout.VERTICAL);
                    edit = new EditText(activity);
                    edit.setHint("com.xxx.xxx@0x0");
                    edit.setId(0xF1);
                    edit.setBackgroundTintList(null);
                    edit.setSingleLine(true);
                    Linear.addView(edit);
                    edit2 = new EditText(activity);
                    edit2.setHint("ClassType(com.xxx.xxx)");
                    edit2.setId(0xF2);
                    edit2.setSingleLine(true);
                    edit2.setBackgroundTintList(null);
                    Linear.addView(edit2);


                    Dia = new AlertDialog.Builder(activity);
                    Dia.setTitle("NewInstanceClass")
                        .setMessage("第一个框输入类实例地址，第二个框则是可以指定该实例的父类为反射目标\n(如果不需要可以留空，代码将以实例类为目标)")
                        .setView(Linear)
                        .setPositiveButton("创建", this)
                        .show();
                    DialogEvent = NewClassInstanceDialogEvent;
                    break;
                    //显示反射工具
                case ClassManagerEvent:
                    Instance.startButton2();
                    break;
                    //获取activity，application实例
                case fastGetInstanceEvent:
                    Dia = new AlertDialog.Builder(activity);
                    Dia.setTitle("获取")
                        .setItems(new String[] {
                            "Current Activity",
                            "Current Application"
                        }, this).show();
                    DialogEvent = GiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveInstanceDialogEvent;
                    break;
                    //拆分数组
                case splitArrayEvent:
                    edit = new EditText(activity);
                    edit.setHint("[xxx.xxx@0x0");
                    edit.setId(0xF1);
                    edit.setBackgroundTintList(null);
                    edit.setSingleLine(true);
                    Dia = new AlertDialog.Builder(activity);
                    Dia.setTitle("SplitArray")
                        .setMessage("可以将任何数据类型的数组进行拆分")
                        //				.setNegativeButton("复制全部",this)
                        .setPositiveButton("拆分", this)
                        .setView(edit)
                        .show();
                    DialogEvent = splitArrayDialogEvent;
                    break;
            }
        }

        @Override
        private int DialogEvent;
        public static final int NewClassDialogEvent = 0xF11;
        public static final int NewClassInstanceDialogEvent = 0xF12;
        public static final int GiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveInstanceDialogEvent = 0xF555;
        public static final int splitArrayDialogEvent = 0xF14;
        public static final int splitArrayListDialogEvent = 0xF15;
        private String[] DialogCache;
        public void onClick(DialogInterface dialog, int which) {
            EditText edit, edit2;
            String Text, Text2;
            AlertDialog Dia = (AlertDialog) dialog;
            switch (DialogEvent) {
                //新建类
                case NewClassDialogEvent:
                    edit = Dia.findViewById(0xF1);
                    Text = edit.getText().toString();
                    Text = Text.replace("\n", "").replace("/", ".").replace(" ", "");
                    Class < ? > Cla = ClassManager.ParseClass(Text);
                    if (Cla == null) {
                        Toast.makeText(activity, "此类不存在：" + Text, 1).show();
                        break;
                    }
                    try {
                        NewButton button = new NewButton(this, new ClassManager(activity, Cla));
                        button.setButtonText("Class")
                            .setButtonTextColor(Color.BLUE)
                            .setId(ClassManagerEvent)
                            .show();
                    } catch (IOException e) {
                        Toast.makeText(activity, "IO输出流异常", 1).show();
                    }
                    break;
                    //新建实例类
                case NewClassInstanceDialogEvent:
                    edit = Dia.findViewById(0xF1);
                    Text = edit.getText().toString();
                    Object value = ClassManager.getObjectValue(Text);
                    if (value == null) {
                        Toast.makeText(activity, "该地址无对象", 1).show();
                        break;
                    }

                    edit2 = Dia.findViewById(0xF2);
                    Text2 = edit2.getText().toString();

                    Class < ? > Clas;
                    //检查类型框是否有内容
                    if (Text2.length() > 2) {
                        //按用户填写的类进行处理
                        Text2 = Text2.replace("\n", "").replace("/", ".").replace(" ", "");
                        Clas = ClassManager.ParseClass(Text2);
                        if (Clas == null) {
                            Toast.makeText(activity, "该类型不存在", 1).show();
                            break;
                        }
                    } else {
                        //没有则按value对象取
                        Clas = value.getClass();
                    }

                    if (!ClassManager.isObjectValueequals(value, Clas)) {
                        Toast.makeText(activity, "该对象实例与类型不符", 1).show();
                        break;
                    }

                    try {
                        NewButton button = new NewButton(this, new ClassManager(activity, Clas, value));
                        button.setButtonText("Class")
                            .setButtonTextColor(Color.BLUE)
                            .setId(ClassManagerEvent)
                            .show();
                    } catch (IOException e) {
                        Toast.makeText(activity, "IO输出流异常", 1).show();
                    }
                    break;
                    //快速获取(我很急)
                case GiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveGiveInstanceDialogEvent:
                    Class < ? > type = null;
                    Object Value = null;
                    switch (which) {
                        case 0:
                            type = activity.getClass();
                            Value = activity;
                            break;
                        case 1:
                            type = activity.getApplication().getClass();
                            Value = activity.getApplication();
                            break;
                            //					case 2:
                            //						type = ClassManager.ParseClass("android.app.Activity");
                            //						Value = activity;
                            //						break;
                            //					case 3:
                            //						type = ClassManager.ParseClass("android.app.Application");
                            //						Value = activity.getApplication();
                            //						break;
                    }
                    try {
                        ReflectTool.ClassManager ClasM = new ClassManager(activity, type, Value);
                        ClasM.setObjectValue(Value);
                        NewButton button = new NewButton(this, ClasM);
                        button.setButtonText(type.getSimpleName())
                            .setButtonTextColor(Color.YELLOW)
                            .setId(ClassManagerEvent)
                            .show();
                    } catch (IOException e) {
                        throw new RuntimeException("ReflectTool.获取实例时发生意外：" + e.toString());
                    }
                    break;
                    //拆分数组
                case splitArrayDialogEvent:
                    edit = Dia.findViewById(0xF1);
                    Text = edit.getText().toString();
                    Object ArrayObject = ClassManager.getObjectValue(Text);
                    if (ArrayObject == null) {
                        Toast.makeText(activity, "该地址无数组对象", 1).show();
                        break;
                    }
                    if (!ArrayObject.getClass().isArray()) {
                        Toast.makeText(activity, "该实例不是数组", 1).show();
                        break;
                    }
                    int count = Array.getLength(ArrayObject);
                    if (count == 0) {
                        Toast.makeText(activity, "该数组是空数组", 1).show();
                        break;
                    }
                    try {
                        Main main = new Main("ReflectTool/Array.log");
                        main.setConfig("Array");

                        //排除所有null值
                        List < Object > Vvalue = new ArrayList < Object > ();
                        //将不为null值的存入Vvalue
                        for (int i = 0; i < count; i++) {
                            Object item = Array.get(ArrayObject, i);
                            if (item != null) {
                                Vvalue.add(item);
                            }
                        }

                        //可视化文本提供给用户
                        String[] ArrayStr = new String[Vvalue.size()];
                        //值对象ip
                        String[] ArrayIp = new String[Vvalue.size()];
                        StringBuffer log = new StringBuffer();
                        for (int i = 0; i < Vvalue.size(); i++) {
                            Object obj = Vvalue.get(i);
                            ClassManager.setObjectValue(obj);
                            String itemName = obj.toString();
                            if (itemName.length() > 30) {
                                itemName = itemName.substring(0, 15) + "..." + itemName.substring(itemName.length() - 15);
                            }
                            ArrayStr[i] = itemName;
                            ArrayIp[i] = ClassManager.ParseObjectIp(obj);
                            //日志
                            log.append("Array：")
                                .append(Text)
                                .append("\n")
                                .append("Index：")
                                .append(i)
                                .append("\n")
                                .append("toString：")
                                .append(ArrayStr[i])
                                .append("\n")
                                .append("Object：")
                                .append(ArrayIp[i]);
                            main.WriteLog(log.toString());
                            log = new StringBuffer();
                        }

                        new AlertDialog.Builder(activity)
                            .setTitle("Array")
                            .setItems(ArrayStr, this)
                            .setPositiveButton("复制全部", this)
                            .show();
                        DialogCache = ArrayIp;
                        DialogEvent = splitArrayListDialogEvent;
                    } catch (Exception e) {
                        AlertDialog.Builder ExceptionDialog = new AlertDialog.Builder(activity);
                        ExceptionDialog.setTitle("Exception")
                            .setMessage(e.toString())
                            .show();
                    }
                    break;
                    //复制数组中的内容
                case splitArrayListDialogEvent:
                    ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                    //复制全部
                    if (which == -1) {
                        String arraystr = Arrays.toString(DialogCache);
                        clipboard.setText(arraystr);
                        Toast.makeText(activity, "Array：" + ClassManager.getObjectValue(arraystr).toString(), 1).show();
                        break;
                    }
                    //复制单个体
                    String arraystr = DialogCache[which];
                    clipboard.setText(arraystr);
                    Toast.makeText(activity, "ArrayItem：" + ClassManager.getObjectValue(arraystr).toString(), 1).show();
                    break;
            }
        }

        //窗口按钮
        public static class NewButton
        implements View.OnTouchListener,
            View.OnClickListener,
            DialogInterface.OnClickListener,
            View.OnLongClickListener {

                private ReflectTool Instance;
                //上下文
                private Activity context;
                //服务
                private WindowManager Service;
                //父视图
                private WindowManager.LayoutParams Params;
                //按钮父视图
                private LinearLayout MainLinear;
                //按钮副父视图(左右)
                private LinearLayout Main2Linear;
                private LinearLayout Main3Linear;
                //主按钮中框消息
                private LinearLayout MessageLinear;
                //主按钮
                private Button Mainbutton;
                //类实例显示文本
                private TextView ClassInstanceTextView;
                //类名文本(附加在类管理器按钮上方文本)
                private TextView ClassManagerTopTextView;

                //类管理器
                private ClassManager Manager;

                //特征码(唯一标识码)
                Long code;

                public NewButton(ReflectTool Context, ClassManager ClassTool) {
                    this(Context, ClassTool, null);
                }

                //ClassTool：类管理器 null则不显示反射工具纯悬浮按钮
                //newbutton：附着原按钮属性 
                public NewButton(ReflectTool Context, ClassManager ClassTool, NewButton newbutton) {
                    //窗口服务
                    WindowManager Service = (WindowManager) Context.activity.getSystemService("window");
                    //副视图
                    WindowManager.LayoutParams Params = new WindowManager.LayoutParams();
                    Params.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    Params.width = WindowManager.LayoutParams.WRAP_CONTENT;
                    Params.type = 2;
                    Params.flags = 8;
                    Params.format = 1;
                    Params.gravity = Gravity.LEFT;
                    //

                    //此判断主要是判主按钮还是子按钮(主按钮不包含反射工具，所以自然没有类管理器)
                    //如果是主按钮则到处乱跑🤓
                    if (ClassTool == null) {
                        Random random = new Random();
                        Display Display = Service.getDefaultDisplay();
                        Params.x = random.nextInt(random.nextInt(Display.getWidth()));
                        Params.y = random.nextInt(random.nextInt(Display.getHeight() + 1));
                    }

                    this.Instance = Context;
                    this.context = Context.activity;
                    this.Manager = ClassTool;
                    this.Service = Service;
                    this.Params = Params;

                    //主视图
                    LinearLayout Linear = new LinearLayout(context);
                    Linear.setOrientation(LinearLayout.HORIZONTAL);

                    if (ClassTool != null) {
                        //左副功能按钮
                        LinearLayout LinearLeft2 = new LinearLayout(context);
                        LinearLayout.LayoutParams LinearLeft2Params = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);
                        LinearLeft2Params.weight = 1;
                        LinearLeft2.setLayoutParams(LinearLeft2Params);
                        LinearLeft2.setOrientation(LinearLayout.VERTICAL);
                        LinearLeft2.setPadding(0, 100, 0, 0);
                        LinearLeft2.setVisibility(8);

                        Button LinearLeftOutlogbutton = new Button(context);
                        LinearLeftOutlogbutton.setId(OutLogEvent);
                        LinearLeftOutlogbutton.setAllCaps(false);
                        LinearLeftOutlogbutton.setText("Outlog");
                        LinearLeftOutlogbutton.setOnClickListener(this);
                        LinearLeft2.addView(LinearLeftOutlogbutton);

                        Button LinearLeftRenamebutton = new Button(context);
                        LinearLeftRenamebutton.setId(RenameButtonEvent);
                        LinearLeftRenamebutton.setText("重命名");
                        LinearLeftRenamebutton.setOnClickListener(this);
                        LinearLeft2.addView(LinearLeftRenamebutton);

                        Button LinearLeftOutFieldbutton = new Button(context);
                        LinearLeftOutFieldbutton.setId(DestroyButtonEvent);
                        LinearLeftOutFieldbutton.setText("销毁");
                        LinearLeftOutFieldbutton.setOnClickListener(this);
                        LinearLeft2.addView(LinearLeftOutFieldbutton);

                        Linear.addView(LinearLeft2);
                        this.Main2Linear = LinearLeft2;
                    }


                    //中间部分
                    LinearLayout LinearMiddle2 = new LinearLayout(context);
                    LinearMiddle2.setOrientation(LinearLayout.VERTICAL);
                    LinearMiddle2.setGravity(Gravity.CENTER_HORIZONTAL);
                    LinearLayout.LayoutParams LinearMiddle2Params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                    LinearMiddle2Params.weight = 1;
                    if (ClassTool != null) {
                        TextView TextClassNameView = new TextView(context);
                        TextClassNameView.setBackgroundColor(0xB3808080);
                        TextClassNameView.setTextSize(10);
                        TextClassNameView.setTextColor(0xFFFFFFFF);
                        Class < ? > Cla = ClassTool.toClass();
                        String ClaName = Cla.getName();
                        //如果文本太长则截断
                        if (ClaName.length() > 30) {
                            ClaName = "..." + Cla.getSimpleName();
                        }
                        TextClassNameView.setText(ClaName);
                        TextClassNameView.setLayoutParams(LinearMiddle2Params);
                        //如果已填充实例则改变
                        if (getManager().getInstance() != null) {
                            TextClassNameView.setTextColor(Color.GREEN);
                        }
                        ClassManagerTopTextView = TextClassNameView;
                        LinearMiddle2.addView(TextClassNameView);

                        Button button = new Button(context);
                        button.setAllCaps(false);
                        button.setLayoutParams(LinearMiddle2Params);
                        button.setOnTouchListener(this);
                        LinearMiddle2.addView(button);
                        this.Mainbutton = button;

                        LinearLayout Message = new LinearLayout(context);
                        Message.setLayoutParams(TextClassNameView.getLayoutParams());
                        Message.setOrientation(LinearLayout.VERTICAL);
                        Message.setGravity(Gravity.CENTER_HORIZONTAL);
                        Message.setVisibility(8);

                        //当前类实例
                        TextView InstanceMessage = new TextView(context);
                        if (getManager().getInstance() == null) {
                            InstanceMessage.setText("No Instance");
                            InstanceMessage.setTextColor(Color.BLACK);
                        } else {
                            String ip = getManager().ParseObjectIp(getManager().getInstance());
                            ip = ip.substring(ip.lastIndexOf(".") + 1);
                            //如果文本太长则直接截断
                            if (ip.length() > 20) {
                                ip = ip.substring(ip.length() - 17, ip.length());
                                ip = "..." + ip;
                            }
                            InstanceMessage.setText(ip);
                            InstanceMessage.setTextColor(0xFF800080);
                        }
                        InstanceMessage.setTextSize(15);
                        InstanceMessage.setId(setClassInstanceEvent);
                        InstanceMessage.setOnClickListener(this);
                        InstanceMessage.setOnLongClickListener(this);
                        ClassInstanceTextView = InstanceMessage;
                        Message.addView(InstanceMessage);

                        //当前类的父类
                        TextView SuperMessage = new TextView(context);
                        SuperMessage.setTextSize(12);
                        Class < ? > Super = getManager().toClass().getSuperclass();
                        String SuperStr = "Super：";
                        if (Super == null) {
                            SuperStr += "null";
                        } else {
                            SuperStr += Super.getSimpleName();
                            SuperMessage.setId(NewSuperEvent);
                            SuperMessage.setOnClickListener(this);
                        }
                        SuperMessage.setTextColor(Color.BLACK);
                        SuperMessage.setText(SuperStr);
                        Message.addView(SuperMessage);

                        //构造方法数量信息
                        TextView ConstructorCount = new TextView(context);
                        String ConstructorCountStr = "ConstructorCount：";
                        int countConstructor = ClassTool.getConstructorCount();
                        ConstructorCountStr += countConstructor;
                        ConstructorCount.setText(ConstructorCountStr);
                        ConstructorCount.setTextSize(10);
                        if (countConstructor == 0) {
                            ConstructorCount.setTextColor(Color.BLACK);
                        } else {
                            //红色
                            ConstructorCount.setTextColor(Color.RED);
                        }
                        Message.addView(ConstructorCount);

                        //类方法数量信息

                        TextView MethodCount = new TextView(context);
                        String MethodCountStr = "MethodCount：";
                        int countMethod = ClassTool.getMethodCount();
                        MethodCountStr += countMethod;
                        MethodCount.setText(MethodCountStr);
                        MethodCount.setTextSize(10);
                        if (countMethod == 0) {
                            MethodCount.setTextColor(Color.BLACK);
                        } else {
                            MethodCount.setTextColor(Color.BLUE);
                        }
                        Message.addView(MethodCount);

                        //类字段数量信息
                        TextView FieldCount = new TextView(context);
                        String FieldCountStr = "FieldCount：";
                        int countField = ClassTool.getFieldCount();
                        FieldCountStr += countField;
                        FieldCount.setText(FieldCountStr);
                        FieldCount.setTextSize(10);
                        if (countField == 0) {
                            FieldCount.setTextColor(Color.BLACK);
                        } else {
                            //黄色
                            FieldCount.setTextColor(Color.parseColor("#FFFFC800"));
                        }
                        Message.addView(FieldCount);



                        LinearMiddle2.addView(Message);
                        MessageLinear = Message;
                    } else {
                        Button button = new Button(context);
                        button.setAllCaps(false);
                        button.setLayoutParams(LinearMiddle2Params);
                        button.setOnTouchListener(this);
                        LinearMiddle2.addView(button);
                        this.Mainbutton = button;
                    }

                    //判断newbutton是否不为null 用于附着原按钮属性
                    if (newbutton != null) {
                        Params.x = newbutton.getParams().x;
                        Params.y = newbutton.getParams().y;
                        Button button2 = newbutton.Mainbutton;
                        this.Mainbutton.setText(newbutton.getButtonText());
                        this.Mainbutton.setTextColor(newbutton.getButtonTextColor());
                        this.Mainbutton.setId(button2.getId());
                        this.code = newbutton.code;
                    } else {
                        Random random = new Random();
                        this.code = new Long(random.nextLong());
                    }

                    Linear.addView(LinearMiddle2);

                    if (ClassTool != null) {
                        //右副功能按钮
                        LinearLayout LinearRight2 = new LinearLayout(context);
                        LinearLayout.LayoutParams LinearRight2Params = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);
                        LinearRight2Params.weight = 1;
                        LinearRight2.setLayoutParams(LinearRight2Params);
                        LinearRight2.setOrientation(LinearLayout.VERTICAL);
                        LinearRight2.setPadding(0, 100, 0, 0);
                        LinearRight2.setVisibility(8);

                        Button LinearRightNewInstancebutton = new Button(context);
                        LinearRightNewInstancebutton.setId(ConstructorEvent);
                        LinearRightNewInstancebutton.setAllCaps(false);
                        LinearRightNewInstancebutton.setText("New");
                        LinearRightNewInstancebutton.setOnClickListener(this);
                        LinearRightNewInstancebutton.setOnLongClickListener(this);
                        LinearRight2.addView(LinearRightNewInstancebutton);

                        Button LinearRightFieldbutton = new Button(context);
                        LinearRightFieldbutton.setId(FieldEvent);
                        LinearRightFieldbutton.setAllCaps(false);
                        LinearRightFieldbutton.setText("Field");
                        LinearRightFieldbutton.setOnClickListener(this);
                        LinearRight2.addView(LinearRightFieldbutton);

                        Button LinearRightMethodbutton = new Button(context);
                        LinearRightMethodbutton.setId(MethodEvent);
                        LinearRightMethodbutton.setAllCaps(false);
                        LinearRightMethodbutton.setText("Method");
                        LinearRightMethodbutton.setOnClickListener(this);
                        LinearRight2.addView(LinearRightMethodbutton);

                        Linear.addView(LinearRight2);
                        this.Main3Linear = LinearRight2;
                    }

                    //初始化
                    this.MainLinear = Linear;
                    //反射
                }

                private boolean click;
                public void startButton2() {
                    int Visibility;
                    if (click) {
                        click = false;
                        Visibility = 8;
                        //这个是触发了是否销毁反射管理器，但临时反悔
                        DestroySure = false;
                        ((Button) MainLinear.findViewById(DestroyButtonEvent)).setText("销毁");
                    } else {
                        click = true;
                        Visibility = 0;
                    }
                    Main2Linear.setVisibility(Visibility);
                    Main3Linear.setVisibility(Visibility);
                    MessageLinear.setVisibility(Visibility);
                    Service.updateViewLayout(MainLinear, Params);
                }

                //副功能按钮事件
                @Override
                public static final int ConstructorEvent = 0xFFF0;
                public static final int FieldEvent = 0xFFF1;
                public static final int MethodEvent = 0xFFF2;
                public static final int setClassInstanceEvent = 0xFFF4;
                public static final int DestroyButtonEvent = 0xFFF5;
                public static final int NewSuperEvent = 0xFFF6;
                public static final int RenameButtonEvent = 0xFFF7;
                public static final int OutLogEvent = 0xFFF8;
                public static final int NewArrayEvent = 0xFFF9;
                public static final int NewArray2Event = 0xFFF10;
                //确定销毁悬浮按钮
                private boolean DestroySure;
                public void onClick(View v) {
                    switch (v.getId()) {
                        //类构造方法对话框
                        case ConstructorEvent:
                            Manager.showDialog(ConstructorEvent);
                            break;
                            //类字段对话框
                        case FieldEvent:
                            Manager.showDialog(FieldEvent);
                            break;
                            //类方法对话框
                        case MethodEvent:
                            Manager.showDialog(MethodEvent);
                            break;
                            //设置类实例对话框
                        case setClassInstanceEvent:
                            EditText edit = new EditText(context);
                            edit.setHint("com.xxx.xxx@0x0");
                            edit.setId(0xF1);
                            edit.setBackgroundTintList(null);
                            edit.setSingleLine(true);
                            DialogEvent = setInstanceEvent;
                            AlertDialog.Builder Dia = new AlertDialog.Builder(context);
                            Dia.setTitle("设置类实例")
                                .setMessage("格式：Class@Hash")
                                .setView(edit)
                                .setPositiveButton("Init", this)
                                .show();
                            break;
                            //销毁按钮事件
                        case DestroyButtonEvent:
                            if (!DestroySure) {
                                Button button = MainLinear.findViewById(DestroyButtonEvent);
                                button.setText("确定销毁?");
                                DestroySure = true;
                                break;
                            }
                            remove();
                            break;
                            //实例化当前类父类
                        case NewSuperEvent:
                            try {
                                ClassManager manager = getManager();
                                Class < ? > Super = manager.toClass().getSuperclass();
                                Object instance = manager.getInstance();
                                ClassManager classManager = new ClassManager(context, Super, instance);
                                NewButton newbutton = new NewButton(Instance, classManager);
                                newbutton.setButtonText("Class")
                                    .setButtonTextColor(Color.BLUE)
                                    .setId(ClassManagerEvent)
                                    .show();
                                Toast.makeText(context, "new Super", 0).show();
                            } catch (Exception e) {
                                throw new RuntimeException("ReflectTool实例化父类失败：" + e.toString());
                            }
                            break;
                            //重命名
                        case RenameButtonEvent:
                            EditText Edit = new EditText(context);
                            Edit.setHint(getButtonText());
                            Edit.setBackgroundTintList(null);
                            Edit.setSingleLine(true);
                            Edit.setId(0xF1);
                            AlertDialog.Builder RenameDia = new AlertDialog.Builder(context);
                            RenameDia.setTitle("Rename")
                                .setMessage("重命名当前类管理器名称\n字节长度限制：20")
                                .setView(Edit)
                                .setPositiveButton("重命名", this)
                                .show();
                            DialogEvent = RenameEvent;
                            break;
                            //输出日志
                        case OutLogEvent:
                            getManager().outLog();
                            break;
                            //新建数组事件
                        case NewArrayEvent:
                            LinearLayout MainView = (LinearLayout) v.getTag();
                            LinearLayout Main2View = (LinearLayout) MainView.findViewById(NewArrayMain2Linear);
                            EditText MainEdit = Main2View.findViewById(NewArrayEdit);
                            String Text = MainEdit.getText().toString();
                            if (Text.length() == 0) {
                                Toast.makeText(context, "请填写数组长度", 1).show();
                                return;
                            }
                            //清除原视图输入数组长度编辑框
                            Main2View.removeAllViews();
                            //获取输入框数组长度
                            int arraycount = Integer.valueOf(Text);
                            if (arraycount == 0) {
                                //创建空数组
                                Object array = Array.newInstance(getManager().toClass(), 0);
                                getManager().setObjectValue(array);
                                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                                clipboard.setText(getManager().ParseObjectIp(array));
                                Toast.makeText(context, "[]", 1).show();
                                //并取消弹窗
                                ((AlertDialog) Main2View.getTag()).dismiss();
                                break;
                            }
                            EditText[] EditArray = new EditText[arraycount];

                            //滚动视图
                            ScrollView Scroll = new ScrollView(context);
                            Scroll.setVerticalScrollBarEnabled(false);
                            Scroll.setHorizontalScrollBarEnabled(false);
                            LinearLayout ScrolllistView = new LinearLayout(context);
                            ScrolllistView.setOrientation(LinearLayout.VERTICAL);
                            LinearLayout.LayoutParams ScrolllistViewParam = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT);
                            Scroll.setLayoutParams(ScrolllistViewParam);

                            for (int i = 0; i < arraycount; i++) {
                                //填写参数子视图
                                LinearLayout setParamsView = new LinearLayout(context);
                                setParamsView.setGravity(Gravity.BOTTOM);
                                setParamsView.setOrientation(LinearLayout.VERTICAL);
                                setParamsView.setPadding(0, 10, 0, 0);

                                //参数
                                TextView ParamsText = new TextView(context);

                                ParamsText.setText("ArrayItem" + (i + 1) + "：" + getManager().toClassName());
                                ParamsText.setPadding(0, 0, 0, 5);
                                setParamsView.addView(ParamsText);

                                //参数填写框
                                EditText setValueEdit = new EditText(context);
                                setValueEdit.setHint("Value");
                                setValueEdit.setSingleLine(true);
                                setValueEdit.setBackgroundTintList(null);
                                setParamsView.addView(setValueEdit);
                                EditArray[i] = setValueEdit;

                                ScrolllistView.addView(setParamsView);

                                //如果条目数增加到4则限制高度
                                if (i == 3) {
                                    int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(
                                        0,
                                        View.MeasureSpec.UNSPECIFIED);
                                    setParamsView.measure(0, heightMeasureSpec);
                                    int Height = (setParamsView.getMeasuredHeight() * 4) + setParamsView.getMeasuredHeight() / 4;
                                    LinearLayout.LayoutParams xxx = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        Height);
                                    Scroll.setLayoutParams(xxx);
                                    //((ViewGroup.LayoutParams)ScrolllistView.getParent()).height = Height;
                                }
                            }
                            //设置标签(
                            v.setTag(EditArray);
                            v.setId(NewArray2Event);
                            Class < ? > Type = getManager().toClass();
                            ObjectManager.put("this@null" + Type.getName(), ClassManager.BasicNullValue.get(Type));

                            Scroll.addView(ScrolllistView);
                            Main2View.addView(Scroll);
                            break;
                            //新增数组2事件
                        case NewArray2Event:
                            ClassManager manager = getManager();
                            //清除下划线颜色
                            EditText[] ArrEdit = (EditText[]) v.getTag();
                            for (EditText eedit: ArrEdit) {
                                eedit.setBackgroundTintList(null);
                            }
                            //数组
                            Object array = Array.newInstance(manager.toClass(), ArrEdit.length);
                            //遍历
                            for (int i = 0; i < ArrEdit.length; i++) {
                                EditText ItemEdit = ArrEdit[i];
                                String text = ItemEdit.getText().toString();
                                if (text.length() == 0) {
                                    try {
                                        //创建当前类型新实例化实例
                                        Object arrayIn;
                                        if (manager.toClass().isArray()) {
                                            arrayIn = Array.newInstance(manager.toClass().getComponentType(), 0);;
                                        } else {
                                            arrayIn = manager.toClass().newInstance();
                                        }
                                        Array.set(array, i, arrayIn);
                                    } catch (Exception e) {
                                        ItemEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                        Toast.makeText(context, "ArrayItem" + (i + 1) + "：实例化失败", 1).show();
                                        new AlertDialog.Builder(context)
                                            .setTitle("Exception")
                                            .setMessage(e.toString())
                                            .show();
                                        return;
                                    }
                                } else {
                                    //如果用户输入this@null且这个数据类型是9大基础数据则填写默认值
                                    String NullTag = text.toLowerCase() + manager.toClassName();
                                    if (ObjectManager.containsKey(NullTag)) {
                                        Array.set(array, i, ClassManager.BasicNullValue.get(manager.toClass()));
                                        continue;
                                    }
                                    Object value;
                                    //如果是基础类型则强转该基础实例
                                    //但前提这个数据不能在对象管理器获取
                                    if (manager.getObjectValue(text) == null && manager.isBasicObject(manager.toClass())) {
                                        try {
                                            value = manager.StrToBasicObject(manager.toClass(), text);
                                            Array.set(array, i, value);
                                        } catch (NumberFormatException e) {
                                            ItemEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                            Toast.makeText(context, "ArrayItem" + (i + 1) + "：转换失败", 1).show();
                                            new AlertDialog.Builder(context)
                                                .setTitle("Exception")
                                                .setMessage(e.toString())
                                                .show();
                                            return;
                                        }
                                    } else {
                                        //否则从对象管理器取值
                                        value = manager.getObjectValue(text);
                                        if (value == null) {
                                            ItemEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                            Toast.makeText(context, "ArrayItem" + (i + 1) + "：该地址无对象", 1).show();
                                            return;
                                        }
                                        Array.set(array, i, value);
                                    }
                                }
                            }
                            //设置数组实例到对象管理器
                            manager.setObjectValue(array);
                            //show
                            String ip = manager.ParseObjectIp(array);
                            ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                            clipboard.setText(ip);
                            Toast.makeText(context, Arrays.toString((Object[]) array), 1).show();
                            break;
                    }
                }

                //对话框事件
                @Override
                private int DialogEvent;
                public static final int setInstanceEvent = 0xFFFFF01;
                public static final int RenameEvent = 0xFFFF985;
                public void onClick(DialogInterface dialog, int which) {
                    AlertDialog alert = (AlertDialog) dialog;
                    switch (DialogEvent) {
                        //设置类实例点击事件
                        case setInstanceEvent:
                            EditText Edit = alert.findViewById(0xF1);
                            String edittxt = Edit.getText().toString();
                            Object value = getManager().getObjectValue(edittxt);
                            if (value == null) {
                                Toast.makeText(context, edittxt + "：该地址无对象", 1).show();
                                break;
                            }
                            boolean check = getManager().CheckClassManagerInstance(value);
                            if (check) {
                                String ip = getManager().ParseObjectIp(value);
                                ip = ip.substring(ip.lastIndexOf(".") + 1);
                                //如果文本太长则直接截断
                                if (ip.length() > 20) {
                                    ip = ip.substring(ip.length() - 17, ip.length());
                                    ip = "..." + ip;
                                }
                                ClassInstanceTextView.setText(ip);
                                ClassInstanceTextView.setTextColor(0xFF800080);
                                ClassManagerTopTextView.setTextColor(Color.GREEN);
                                Toast.makeText(context, "new success", 1).show();
                                break;
                            }
                            Toast.makeText(context, "该实例与当前Class不符", 1).show();
                            break;
                            //重命名事件
                        case RenameEvent:
                            Edit = alert.findViewById(0xF1);
                            String name = Edit.getText().toString();
                            byte[] byt = name.getBytes();
                            if (byt.length > 20) {
                                for (int i = 20; i < byt.length; i++) {
                                    byt[i] = 00;
                                }
                                name = new String(byt);
                            }
                            setButtonText(name);
                            break;
                    }
                }

                @Override
                public boolean onLongClick(View v) {
                    switch (v.getId()) {
                        //设置实例的长按事件
                        case setClassInstanceEvent:
                            Object In = getManager().getInstance();
                            if (In != null) {
                                String Ip = getManager().ParseObjectIp(In);
                                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                                clipboard.setText(Ip);
                                Toast.makeText(context, "复制成功：" + Ip, 1).show();
                            }
                            break;
                            //实例化数组
                        case ConstructorEvent:
                            NewArrayDialogShow(v);
                            break;
                    }
                    return true;
                }

                public static final int NewArrayEdit = 0xFF64015;
                public static final int NewArrayMain2Linear = 0xFF520;
                private void NewArrayDialogShow(View v) {
                    //主视图
                    LinearLayout MainView = new LinearLayout(context);
                    MainView.setOrientation(LinearLayout.VERTICAL);
                    LinearLayout.LayoutParams MainViewParam = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.FILL_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                    MainView.setLayoutParams(MainViewParam);

                    LinearLayout Main2View = new LinearLayout(context);
                    Main2View.setOrientation(LinearLayout.VERTICAL);
                    Main2View.setId(NewArrayMain2Linear);
                    EditText setValueEdit = new EditText(context);
                    setValueEdit.setLayoutParams(MainViewParam);
                    setValueEdit.setHint("length");
                    //setValueEdit.setMaxLines(3);
                    setValueEdit.setId(NewArrayEdit);
                    setValueEdit.setKeyListener(DigitsKeyListener.getInstance("0123456789"));
                    setValueEdit.setSingleLine(true);
                    setValueEdit.setBackgroundTintList(null);
                    Main2View.addView(setValueEdit);
                    MainView.addView(Main2View);

                    //实例化框
                    LinearLayout NewInstanceView = new LinearLayout(context);
                    NewInstanceView.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
                    LinearLayout.LayoutParams NewInstanceViewParam = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                    NewInstanceViewParam.topMargin = 30;
                    NewInstanceViewParam.bottomMargin = 50;
                    NewInstanceViewParam.rightMargin = 30;
                    NewInstanceView.setLayoutParams(NewInstanceViewParam);

                    //实例化按钮
                    Button NewInstanceButton = new Button(context);
                    NewInstanceButton.setAllCaps(false);
                    NewInstanceButton.setBackground(null);
                    NewInstanceButton.setId(NewArrayEvent);
                    NewInstanceButton.setTag(MainView);
                    NewInstanceButton.setOnClickListener(this);
                    NewInstanceButton.setText("New ->");

                    NewInstanceView.addView(NewInstanceButton);
                    MainView.addView(NewInstanceView);
                    AlertDialog dia = new AlertDialog.Builder(context).setTitle("New Array")
                        .setMessage("留空默认填充当前数组类型的新实例\n如需null空值则填写this@null\n需要当前activity或application也是如此\nActivity：this@activity\nApplication：this@application")
                        .setView(MainView)
                        .show();
                    //设置标签
                    Main2View.setTag(dia);
                }

                //获取父视图
                public WindowManager.LayoutParams getParams() {
                    return Params;
                }

                //移除视图并记录
                public void remove() {
                    removeView();
                    //清除
                    ButtonViewManager.remove(code);
                    Map < Long, NewButton > map = currentActivityButtonView.get(context);
                    map.remove(code);
                }

                //移除视图
                public void removeView() {
                    Service.removeView(MainLinear);
                }

                //获取按钮文本
                public String getButtonText() {
                    return Mainbutton.getText().toString();
                }

                //设置按钮文本
                public NewButton setButtonText(String content) {
                    Mainbutton.setText(content);
                    return this;
                }

                //按钮父视图
                public WindowManager.LayoutParams getButtonParams() {
                    return Params;
                }

                //设置按钮文本颜色
                public NewButton setButtonTextColor(int color) {
                    ButtonTextColor = color;
                    Mainbutton.setTextColor(color);
                    return this;
                }

                //获取button按钮文本颜色
                private int ButtonTextColor;
                public int getButtonTextColor() {
                    return ButtonTextColor;
                }

                //获取资源id
                public int getId() {
                    return Mainbutton.getId();
                }

                //设置id
                public NewButton setId(int id) {
                    Mainbutton.setId(id);
                    return this;
                }

                //获取类管理器
                public ClassManager getManager() {
                    return Manager;
                }

                //显示
                public void show() {
                    ButtonViewManager.put(code, this);
                    Map < Long, NewButton > map = currentActivityButtonView.get(context);
                    map.put(code, this);
                    Service.addView(MainLinear, Params);
                }

                //显示(但不记录给ButtonViewManager管理器，专门给其它ActivityInit提供的)
                public void Show2() {
                    Map < Long, NewButton > current = currentActivityButtonView.get(context);
                    current.put(code, this);
                    Service.addView(MainLinear, Params);
                }

                //更新视图
                public void updateView() {
                    //if(MainLinear.isAttachedToWindow()){
                    Service.updateViewLayout(MainLinear, Params);
                    //}else{
                    //Service.addView(MainLinear, Params);
                    //}
                }

                int startX = 0;
                int startY = 0;
                int downx = 0;
                int downy = 0;
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    switch (motionEvent.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = (int) motionEvent.getRawX();
                            startY = (int) motionEvent.getRawY();
                            downx = startX;
                            downy = startY;
                            return false;
                        case MotionEvent.ACTION_UP:
                            int rawX = (int) motionEvent.getRawX();
                            int rawY = (int) motionEvent.getRawY();
                            if (Math.abs(rawX - downx) >= 10 || Math.abs(rawY - downy) >= 10) {
                                return false;
                            }
                            //onclick();
                            //if (isClick) {
                            Instance.onButtonClick(this);
                            //}
                            return false;
                        case MotionEvent.ACTION_MOVE:
                            int rawX2 = (int) motionEvent.getRawX();
                            int rawY2 = (int) motionEvent.getRawY();
                            int i = rawX2 - startX;
                            int i2 = rawY2 - startY;
                            Params.x += i;
                            Params.y += i2;
                            startX = rawX2;
                            startY = rawY2;
                            Service.updateViewLayout(MainLinear, Params);
                            currentXY.put(code, Params);
                            return false;
                        default:
                            return false;
                    }
                }

            }



        //反射工具
        public static class ClassManager
        implements DialogInterface.OnDismissListener,
            View.OnClickListener,
            TextWatcher {

                Activity activity;

                //类
                Class < ? > Classes;

                //类实例
                Object ClassesInstance;

                //九大基本类型
                private static List < String > BasicType;

                //九大基本类型默认值
                private static Map < Class < ? > , Object > BasicNullValue;

                //类构造方法
                private ReflectConstructor Constructors;

                //类方法
                private ReflectMethod Methods;

                //类字段
                private ReflectField Fields;

                //字段视图
                private LinearLayout MainFieldView;

                //方法视图
                private LinearLayout MainMethodView;

                //字段视图
                private LinearLayout MainConstructorView;

                static {
                    //九大基础数据(包含封装)
                    List < String > BasicType = new ArrayList < String > ();
                    BasicType.add("java.lang.String");
                    BasicType.add("char");
                    BasicType.add("java.lang.Character");
                    BasicType.add("int");
                    BasicType.add("java.lang.Integer");
                    BasicType.add("long");
                    BasicType.add("java.lang.Long");
                    BasicType.add("short");
                    BasicType.add("java.lang.Short");
                    BasicType.add("byte");
                    BasicType.add("java.lang.Byte");
                    BasicType.add("float");
                    BasicType.add("java.lang.Float");
                    BasicType.add("double");
                    BasicType.add("java.lang.Double");
                    BasicType.add("boolean");
                    BasicType.add("java.lang.Boolean");
                    //额外
                    BasicType.add("java.lang.CharSequence");
                    ClassManager.BasicType = BasicType;
                    //九大基础数据(null值)
                    HashMap < Class < ? > , Object > BasicNullValue = new HashMap < Class < ? > , Object > ();
                    BasicNullValue.put(String.class, null);
                    BasicNullValue.put(short.class, null);
                    BasicNullValue.put(byte.class, (byte) 0);
                    BasicNullValue.put(char.class, (char) 0);
                    BasicNullValue.put(int.class, (int) 0);
                    BasicNullValue.put(long.class, (long) 0);
                    BasicNullValue.put(float.class, (float) 0.0);
                    BasicNullValue.put(double.class, (double) 0.0);
                    BasicNullValue.put(boolean.class, (boolean) false);
                    ClassManager.BasicNullValue = BasicNullValue;
                }

                public ClassManager(Activity activity, Class < ? > Clas) throws IOException {
                    this(activity, Clas, null);
                }

                public ClassManager(Activity activity, Class < ? > Clas, Object Instance) throws IOException {
                    //Main main = new Main("ReflectTool/" + Clas.getSimpleName() + "-init.log");
                    //main.setConfig("Reflect");
                    //this.main = main;
                    this.activity = activity;
                    this.ClassesInstance = Instance;
                    this.Classes = Clas;

                    //不是哥们，吃饱撑没事做？
                    if (Clas.getName().startsWith("com.doubihuaji.Tool.ReflectTool")) {
                        throw new NullPointerException("兄弟，你有事？");
                    }

                    //遍历类构造方法
                    List < Constructor > Constructors = new ArrayList < Constructor > ();
                    ReflectConstructor reflectConstructor = new ReflectConstructor(Constructors);
                    ListView MainConstructorListView = TopView("Constructor");
                    for (Constructor constructor: Clas.getDeclaredConstructors()) {
                        Constructors.add(constructor);
                    }
                    //constructors = Constructors;
                    //限制条目
                    reflectConstructor.initListViewHeight(MainConstructorListView);
                    MainConstructorListView.setAdapter(reflectConstructor);
                    this.Constructors = reflectConstructor;
                    //构造方法父视图
                    this.MainConstructorView = (LinearLayout) MainConstructorListView.getParent();

                    //遍历类方法
                    List < Method > Methods = new ArrayList < Method > ();
                    ReflectMethod reflectMethod = new ReflectMethod(Methods);
                    ListView MainMethodListView = TopView("Method");
                    for (Method method: Clas.getDeclaredMethods()) {
                        Methods.add(method);
                    }
                    //methods = Methods;
                    //限制条目
                    reflectMethod.initListViewHeight(MainMethodListView);
                    MainMethodListView.setAdapter(reflectMethod);
                    this.Methods = reflectMethod;
                    //方法父视图
                    this.MainMethodView = (LinearLayout) MainMethodListView.getParent();

                    //遍历类字段
                    List < Field > Fields = new ArrayList < Field > ();
                    ReflectField reflectField = new ReflectField(Fields);
                    ListView MainFieldListView = TopView("Field");
                    for (Field fields: Clas.getDeclaredFields()) {
                        Fields.add(fields);
                    }
                    //fields = Fields;
                    //如果条目数＞8则限制高度
                    reflectField.initListViewHeight(MainFieldListView);
                    MainFieldListView.setAdapter(reflectField);
                    this.Fields = reflectField;
                    //字段父视图
                    this.MainFieldView = (LinearLayout) MainFieldListView.getParent();

                }

                //顶部视图
                public static final int SearchEvent = 0xF321;
                public static final int TopTitleEditView = 0xF123;
                public static final int ListViews = 0xFF22;
                private static String ic_Search = "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAfMSURBVHic7ZxtrBxVHcaf/5nti3i1UqUtVZP6Aqgxgi9N670trUgsAYQWUtAvpiYmRIIvd2fO2mLAJZFc7+7MbSWVlJiY0A8EEURLG41VoAmsfRMR0UijEUTbprRqqbeaeGceP3ibYNOdM3vmZdfc8/t6njn/Z8+zMzs755wBHA6Hw+FwOBwOh8PhcDgcMwXpZ/F6vf52pdQ6ABeJyIUAFgB4K4BFJCkiRwEcBXCU5BEAL8Rx/OjmzZv/0kfbhVJ5AL7vL1VKrSV5nYi837KbZwHsAPBou91+tkB7lVNZAFrrVSS35hj0c0Jyn1LqtlardbDIfqui9AC01hcB2ALg6pJLfU9E6q1W688l1ykUVWbnQRBEAA6h/MEHgPUkXw6C4CsV1CqMUs6AjRs3LpmamvqBiFxaRv8Z2FOr1daPjY290qf6mSk8AN/314jIQyLyxqL77pHDSZKsjaLoQJ99pFLoJSgIgtuUUj8egMEHgMVKqf2NRmNtv42kUdgZEATBOhH5vsWhJwBsJ7kTwLE4jv82b968EwBw8uTJN3uedz6ABSJyLYANAM7vsf9/icjKQb1LKiSAer1+qed5ewHMzXoMyV0A7gvD8LFeagVBcD2Az4vImh5qHZ+amvrAli1bjvRSqwpyB9BoNN5A8jkASzIesjOO4zsnJiZ+mbPucpJ3AfhEFj3Jp4aGhlY1m80kT92iqeXtIEmSbSKyJKN2fRRFD+etCQCtVmsvgDVa688AuN+kF5EVk5OTtwP4ehH1iyLXGRAEwTUistOkI3ksSZKr8n7ru+H7/gql1A6Yfx+mlFKXjY+P/6YMHzZY3wWNjo6+DsC3TTqSxz3PW1rW4ANAFEVPxXG8nOSrBmktjmOj5yqxDqBWq22YfoLZFZKxUuqa8fHxP9nWycrExMQhADeSZJpORD6qtR4p209WbAMQktokIvnFVqu137JGz4Rh+FMAXzPpSH65AjuZsArA9/0rReQdBtmeKIrutek/D0NDQ3eTfD5NIyI3bNq06YKqPKVhFYCIfM6kSZLkVpu+89JsNhMR8Q0yNTU19dlKDBnoOYBms3meiNxkkG2Poui3lp5y0263fwJgd5qG5KcqspNKzwFMTk6uyCD7poWXQiGZ6kFEPjg6Ojq/Kj/dsLkErUprJPlSu91+xtJPYYRhuIvkP9I0nuelfpYqsAngQ4b2R2yMlIGI7DK0X1aVl27YBPAeQ/vjNkbKgOTPDJJLKjGSgk0AS9IaSR61s1I8IvKSQfKuSoykUMac8PES+rRCKWVaP7SgEiMpFB7AqVOnDhfdpy2nT59+2SB5SyVGUug5AJL/Tmuv1Wpz7O0USxzHqc/+Sc6qyks3eg5ARFJv7ebMmbPI3k6xzJ07d7FBMlmJkRRszoDUR75KqYEJQERSvYjI36vy0g2b34DUOwsRMX3rKkNE3maQ/LESIynYXIJ+Z2j/mL2dwrnC0P5CJS5SsDkDnjO0r7MxUhKpXkhWNlfRDZvfgD0GycJBmHEKguAKEUl92JYkydNV+elGzwGEYfg8yWMG2Rcs/RSGiHzJIHlxehqzr9hOyHzXILlZa216aFcajUZjOYDr0jQkbVbxFY7tP+HvZNDcY9l3bkh+y6RJkmR7FV5MWAUwvS3ItDVoRGtd+aVIa307zI/Mn5iYmPhVFX5M5HkW9I0Mmnu01itz1OgJrfVVAO426UTEqKmKXCvjtNZ/APBOg+wVpdRHyl4bVK/XL1ZKHTAtjSf5eBiGHy/TSy/kehqaZXUEgAuSJNnn+/6H89RKw/f9yz3P25tlX4LneQOzJgjIGUCr1XqC5H0ZpIuUUgd9378hT71zobXeoJTagwz7BkhOjI+P/7poD3nIvTo6juNRz/NWisj7TFql1CNBEPzQ87w78g6ExfL0Q0NDQ3fkqVkGhWzQaDQa702S5ICIvL6Hw3YkSbItiqIf9VJLa30zyVtF5PKsx5D8p+d5SwdpVfQZityilGmp+tmQPCIiDwB4jOQJpdRfW63W4enV1/Nnz549P47jhQBuArBeRN5k4y9JkhujKBqIP1+vpdBdkkEQ3CIi24rssyxI3hWGYbPfPrwiO+t0Or8YGRnZB+CT6GG/WBmQfFVEuk6Pisjq4eFh6XQ6T1Zm6hwUGgAAdDqd3y9btuwhpdQqAP2aHXuR5Gql1G4An+4mGoQQSn1XRBAELREx7iMoEpL3zpo1686xsbETAKC1Tt2wMX1M3y5Hpb+sY/oOaauImGan8rKb5C1hGP7PNGOWAID+hVDl62quJdkWEdPSxl55muTWMAwf7FI3UwBAf0Ko/IVN9Xp9WCm1FsD1InKxZTfPkHyY5ANRFKUuEgiCoCkixm1LZ6g6hL6+sqzRaFxC8mqS7wZwoYgsILlYRBYCOA/4758oAAcA/JzkfqVUp91u97T+dJBD6GsAVTKoIRR+GzqodDqdJ4eHh0VEVmfRV3WLOmMCAAYzhBkVADB4Icy4AIDBCmFGBgAMTggzNgBgMEKY0QEA/Q9hxgcA9DcEF8A0/QrBBfAa+hGCC+Asqg6h1HdH/78ShmFzeslL6bgzoAtZzwSSYRiGX7Wt4wJIwRTC9ODnmnJ1ARjoFkIRgw+4ADJxdghFDT7gAsjMmRAAHCxq8B0Oh8PhcDgcDofD4XA4HA6HY+bwH095G7eF7m0dAAAAAElFTkSuQmCC";
                private static String ic_cancel = "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAARnSURBVHic7ZzBbttGEIb/4aUJzaSvEgSwDRhBY7sqEhToPc+gU0pK9HXPFqWiF71CD730VCSoZNhAGsDNJc+SUGpyMKeHkgVRRCIp7YpDe76TYSw0q//XDHeXQwKKoiiKoiiKoiiKoiiKoiiKoiiKoijKbYVcBzg7O/v65ubmNyL6cTQavXcdzwbD4fARM/+0XC5/mE6nqctYnssP7/f7QZZlF0R0zMxXw+Hwkct4NsjFvyKiY9/3Z/1+P3AZz5kBxhjf9/0ZgMcAQEQPpZtQEv8hABDRoe/7M2OM7yqmEwOMMX6apq+J6LD8/8KEKIr2XcTdhiiK9sviFxDRYZqmr12ZYP0aYIy5l6bpH0T0ZNUYZk6Z+XQ8Hr+zHX8ToijaJ6ILIlpZbpj5TRAE3xljPtmMbT0DFovFr+vEBwAiCjzPm8dxfGA7flPiOD7wPG++TnwAIKIni8XiF9vxrRvAzGNm/lxj6IMsy+ZtlqMoivazLJsDeFA1lpk/M/PPtufgZBk6GAyOAbwioq+qxrZVjuqUnYL8B/U8SZJL2/Nwtg+QbIIU8QGHy9B8ws/rlCMiCojoYhflKAzDIyniA443YpuYEIbhkav5hGF45HneTIr4wA6OIoDG5ejvLMt6k8nkrc05lMS/X2cOAL53LT6wIwOA/0z4va4ANk1oKr6LH8AqdmYA0I4QksUHdmwAsFtBpIsPtGAAsBth2ix5TXC6ClrFZDJ5m2VZL7/YrYWI7nueN8sFrUXpol9H/LQt8YGWMqCgYSbUWhZK3gB+iVYyoKCUCZV3nXJBX63LhK6JD7ScAQU2jga6KD4gxABgOxO6Kj4gyACgmQkAwMwn+Z+dFB8QZgAADAaDQwBzItqrMby4O3WvxtiPWZZ9K0l8QKABQPNMqIKZPxDRU4ltMa2uglYxHo/fMfMpM3/Y9rMkiw8INQD41wQierqNCdLFB4SWoDL/79WpSxfEBzpgANDchK6IDwguQXcF8RmgJahFNhW/oAsmiC1Bq3o1myC5F7VAZAY42IiJO4IoEGdAHMcHzDxDjXZBNDyKIKLe+fn5X5vPzj6iDLiLh3FirgFNj6OZ+SRJkkupHXh1EZEBd/mGTOsZYKtXs6uZ0KoBtns1pfWi1qG1EuSyV1NCL2pdtDFrixg20NZES7E2RZtzHcRsgranO45dxU5WQW33arruRd0G5xkgaYPkohd1W5xmgCTxAfu9qDbQx1Sr5+Y0E/RB7dv2oHYXxC+QYIKLa8DLOuID+Nj2iWQeu8fMi6qx+Xd6aXsO1g0IguAFM79ZNybvdvtGwnFwkiTXzHxSdWHOX1fzwnZ86wYYYz4FQfBslQkSOxWqelFz8Z/ZflcQ4HAVlL8166L81iyJ4pf5UhsMM18HQXBqjFm6iOl0I9bv94O9vb0rAI+li19QNoGZr5fLZc/lmxOdbsSm02nqed4pgD+7ID4AjEaj93lX9qVr8RVFURRFURRFURRFURRFURRFURRFUZTbzT9vyirNRPGG2wAAAABJRU5ErkJggg==";
                private ListView TopView(String title) {
                    //列表视图(字段)
                    LinearLayout MainListView = new LinearLayout(activity);
                    MainListView.setOrientation(LinearLayout.VERTICAL);
                    MainListView.setPadding(0, 50, 0, 50);
                    LinearLayout.LayoutParams MainListViewParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                    MainListView.setLayoutParams(MainListViewParams);

                    //顶部视图
                    LinearLayout MainListTopView = new LinearLayout(activity);
                    LinearLayout.LayoutParams MainListTopViewParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.FILL_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                    MainListTopViewParams.leftMargin = 55;
                    MainListTopView.setLayoutParams(MainListTopViewParams);

                    //标题
                    EditText TabTitle = new EditText(activity);
                    LinearLayout.LayoutParams TopTitleParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    TopTitleParams.weight = 1;
                    TabTitle.setLayoutParams(TopTitleParams);
                    TabTitle.setId(TopTitleEditView);
                    TabTitle.setBackgroundTintList(null);
                    TabTitle.setPadding(40, 0, 10, 40);
                    TabTitle.setSingleLine(true);
                    TabTitle.setEnabled(false);
                    TabTitle.setText(title);
                    TabTitle.setTextColor(Color.BLACK);
                    TabTitle.setTextSize(23);
                    MainListTopView.addView(TabTitle);

                    //搜索图标
                    ImageView TabSearchImage = new ImageView(activity);
                    LinearLayout.LayoutParams TabTabSearchImageParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 128);
                    //TabTabSearchImageParams.gravity = Gravity.RIGHT;
                    TabTabSearchImageParams.weight = 4;
                    TabTabSearchImageParams.rightMargin = 55;
                    TabSearchImage.setLayoutParams(TabTabSearchImageParams);
                    TabSearchImage.setPadding(10, 10, 10, 10);
                    TabSearchImage.setTag(TabTitle);
                    TabSearchImage.setId(SearchEvent);
                    TabSearchImage.setContentDescription(title);
                    TabSearchImage.setOnClickListener(this);
                    byte[] decodedBytes = Base64.decode(ic_Search, 0);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                    TabSearchImage.setImageBitmap(bitmap);
                    MainListTopView.addView(TabSearchImage);
                    MainListView.addView(MainListTopView);

                    //滑动视图子视图
                    ListView ListViewLayout = new ListView(activity);
                    LinearLayout.LayoutParams ListViewLayoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    ListViewLayout.setLayoutParams(ListViewLayoutParams);
                    ListViewLayout.setId(ListViews);
                    MainListView.addView(ListViewLayout);

                    return ListViewLayout;
                }

                @Override
                //搜索框监听文本
                public void afterTextChanged(Editable s) {
                    try {
                        switch (ShowDiaViewEvent) {
                            case NewButton.FieldEvent:
                                ListView listViews = MainFieldView.findViewById(ListViews);
                                List < Field > newlist = new ArrayList < Field > ();
                                String str = s.toString();
                                if (str.length() == 0) {
                                    //如果搜索文本为0则复用原数组
                                    newlist = Fields.getFilds();
                                } else {
                                    //否则遍历只保留有包含搜索字符结果的
                                    for (Field field: Fields.getFilds()) {
                                        String name = Fields.getPath(field).toLowerCase();
                                        if (name.contains(str.toLowerCase())) {
                                            newlist.add(field);
                                        }
                                    }
                                }
                                listViews.setAdapter(new ReflectField(newlist));
                                listViews.requestLayout();
                                break;
                            case NewButton.MethodEvent:
                                ListView listViews2 = MainMethodView.findViewById(ListViews);
                                List < Method > newlist2 = new ArrayList < Method > ();
                                String str2 = s.toString();
                                if (str2.length() == 0) {
                                    //如果搜索文本为0则复用原数组
                                    newlist2 = Methods.getMethods();
                                } else {
                                    //否则遍历只保留有包含搜索字符结果的
                                    for (Method method: Methods.getMethods()) {
                                        String name2 = Methods.getPath(method).toLowerCase();
                                        if (name2.contains(str2.toLowerCase())) {
                                            newlist2.add(method);
                                        }
                                    }
                                }
                                listViews2.setAdapter(new ReflectMethod(newlist2));
                                listViews2.requestLayout();
                                break;
                            case NewButton.ConstructorEvent:
                                ListView listViews3 = MainConstructorView.findViewById(ListViews);
                                List < Constructor > newlist3 = new ArrayList < Constructor > ();
                                String str3 = s.toString();
                                if (str3.length() == 0) {
                                    //如果搜索文本为0则复用原数组
                                    newlist3 = Constructors.getConstructors();
                                } else {
                                    //否则遍历只保留有包含搜索字符结果的
                                    for (Constructor constructor: Constructors.getConstructors()) {
                                        String name3 = Constructors.getPath(constructor).toLowerCase();
                                        if (name3.contains(str3.toLowerCase())) {
                                            newlist3.add(constructor);
                                        }
                                    }
                                }
                                listViews3.setAdapter(new ReflectConstructor(newlist3));
                                listViews3.requestLayout();
                                break;
                        }

                    } catch (Exception e) {
                        throw new RuntimeException("文本监听时发生异常：" + e.toString());
                    }
                }

                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                //点击事件
                @Override
                public void onClick(View v) {
                    switch (v.getId()) {
                        //搜索事件
                        case SearchEvent:
                            //从视图标签取出edittext
                            EditText Edit = (EditText) v.getTag();
                            //如果有文本则执行清理文本操作
                            Editable text = Edit.getText();
                            if (text.toString().length() > 0 && Edit.isEnabled()) {
                                Edit.setText("");
                                break;
                            }
                            //标题栏搜索框内容
                            String content = v.getContentDescription().toString();
                            //
                            String icon, Text, Hint;
                            if (!Edit.isEnabled()) {
                                icon = ic_cancel;
                                Text = "";
                                Hint = content;
                            } else {
                                icon = ic_Search;
                                Text = content;
                                Hint = "";
                                Edit.removeTextChangedListener(this);
                            }
                            byte[] decodedBytes = Base64.decode(icon, 0);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                            ((ImageView) v).setImageBitmap(bitmap);

                            Edit.setText(Text);
                            //Edit.setTextSize(Textsize);
                            Edit.setHint(Hint);
                            Edit.setEnabled(!Edit.isEnabled());

                            if (Edit.isEnabled()) {
                                Edit.addTextChangedListener(this);
                            }
                            break;
                    }
                }

                //校验实例
                public boolean CheckClassManagerInstance(Object value) {
                    if (isObjectValueequals(value, toClass())) {
                        //一致则填入实例
                        ClassesInstance = value;
                        return true;
                    }
                    return false;
                }

                //访问修饰词
                public String getAccessModifier(int modifiers) {
                    if (Modifier.isPublic(modifiers)) {
                        return "public";
                    }
                    if (Modifier.isPrivate(modifiers)) {
                        return "private";
                    }
                    if (Modifier.isProtected(modifiers)) {
                        return "protected";
                    }
                    return "default";
                }

                //获取对象
                public static Object getObjectValue(String Ip) {
                    return ObjectManager.get(Ip);
                }

                //输出日志
                public void outLog() {
                    try {
                        Main main = new Main("ReflectTool/" + toClass().getSimpleName() + "-out.smali");
                        //仿smali文件格式
                        //文件头
                        StringBuffer smali = new StringBuffer(".class ");
                        //类访问权限
                        smali.append(getAccessModifier(toClass().getModifiers()));
                        if (isStatic(toClass())) {
                            smali.append(" static ");
                        } else {
                            smali.append(" ");
                        }
                        //类路径
                        smali.append(ClassTypetoClassPath(toClass()))
                            .append("\n");
                        //父类
                        Class < ? > Super = toClass().getSuperclass();
                        if (Super != null) {
                            smali.append(".super ")
                                .append(ClassTypetoClassPath(Super))
                                .append("\n");
                        }
                        smali.append("\n\n# fields\n");

                        //字段
                        List < Field > fields = Fields.getFilds();
                        for (int i = 0; i < fields.size(); i++) {
                            Field field = fields.get(i);
                            field.setAccessible(true);
                            String Path = Fields.getPath(field);
                            if (Path.startsWith("default ")) {
                                Path = Path.substring(8);
                            }
                            smali.append(".field ")
                                .append(Path);
                            Object obj;
                            try {
                                obj = field.get(ClassesInstance);
                            } catch (Exception e) {
                                obj = "Null";
                            }
                            smali.append(" ")
                                .append("= #")
                                .append(obj)
                                .append("\n\n");
                        }

                        //构造
                        smali.append("\n# direct methods\n");
                        List < Constructor > constr = Constructors.getConstructors();
                        for (int i = 0; i < constr.size(); i++) {
                            Constructor constrs = constr.get(i);
                            smali.append(".method ")
                                .append(Constructors.getPath(constrs))
                                .append("\n    .registers ")
                                .append(i)
                                .append("\n    .prologue\n")
                                .append("\n    return-void\n")
                                .append(".end method\n\n");
                        }

                        //方法
                        smali.append("\n# methods\n");
                        List < Method > methods = Methods.getMethods();
                        for (int i = 0; i < methods.size(); i++) {
                            Method method = methods.get(i);
                            method.setAccessible(true);
                            String Path = Methods.getPath(method);
                            if (Path.startsWith("default ")) {
                                Path = Path.substring(8);
                            }
                            smali.append(".method ")
                                .append(Path)
                                .append("\n    .registers ")
                                .append(i)
                                .append("\n\n    .prologue\n");
                            if (method.getReturnType() == Void.TYPE) {
                                smali.append("\n    return-void\n")
                                    .append(".end method")
                                    .append("\n\n\n\n");
                            } else {
                                smali.append("\n    const-string v0, \"");
                                Object obj;
                                if (Methods.isNative(method)) {
                                    obj = "Null";
                                } else {
                                    try {
                                        obj = method.invoke(ClassesInstance);
                                    } catch (Exception e) {
                                        obj = "Null";
                                    }
                                }
                                smali.append(obj)
                                    .append("\"\n\n")
                                    .append("   return-object v0\n")
                                    .append(".end method")
                                    .append("\n\n\n");
                            }
                        }

                        main.Write(toClass().getSimpleName() + "-out.smali", smali.toString());
                        Toast.makeText(activity, "outLog", 1).show();
                    } catch (IOException e) {
                        throw new RuntimeException("输出日志失败：" + e.toString());
                    }
                }

                //设置对象
                public static void setObjectValue(Object obj) {
                    String strip = ParseObjectIp(obj).split("@")[1];
                    ObjectManager.put(ParseObjectIp(obj), obj);
                    ObjectManager.put(strip, obj);
                }

                //是否为九大基础数据(包含封装类)
                public static boolean isBasicObject(Object value) {
                    return isBasicObject(value.getClass());
                }
                public static boolean isBasicObject(Class < ? > Type) {
                    return BasicType.contains(Type.getName());
                }

                //字符串转九大基础数据
                public static Object StrToBasicObject(Class < ? > type, String value) {
                    if (isBasicObject(type)) {
                        switch (type.getName()) {
                            case "java.lang.String":
                                return value;
                            case "short":
                                return Short.parseShort(value);
                            case "byte":
                                return Byte.parseByte(value);
                            case "char":
                                return (char) Integer.parseInt(value);
                            case "int":
                                return Integer.parseInt(value);
                            case "long":
                                return Long.parseLong(value);
                            case "float":
                                return Float.parseFloat(value);
                            case "double":
                                return Double.parseDouble(value);
                            case "boolean":
                                return Boolean.parseBoolean(value);
                                //封装
                            case "java.lang.CharSequence":
                                return (CharSequence) value;
                            case "java.lang.Character":
                                return Character.valueOf((char) Integer.parseInt(value));
                            case "java.lang.Integer":
                                return Integer.parseInt(value);
                            case "java.lang.Long":
                                return Long.valueOf(value);
                            case "java.lang.Short":
                                return Short.valueOf(value);
                            case "java.lang.Byte":
                                return Byte.valueOf(value);
                            case "java.lang.Float":
                                return Float.valueOf(value);
                            case "java.lang.Double":
                                return Double.valueOf(value);
                            case "java.lang.Boolean":
                                return Boolean.valueOf(value);
                        }
                    }
                    return null;
                }

                //将对象解析成地址
                static String ParseObjectIp(Object obj) {
                    Class < ? > Clas = obj.getClass();
                    return Clas.getName() + "@" + Integer.toHexString(obj.hashCode());
                }

                //获取构造方法数量
                public int getConstructorCount() {
                    return Constructors.getCount();
                }

                //获取方法数量
                public int getMethodCount() {
                    return Methods.getCount();
                }

                //获取字段数量
                public int getFieldCount() {
                    return Fields.getCount();
                }

                //获取类实例
                public Object getInstance() {
                    return ClassesInstance;
                }

                //是否静态
                private boolean isStatic(Class < ? > Clas) {
                    return ((Clas.getModifiers() & Modifier.STATIC) != 0);
                }

                //对比值类型是否一致相同
                static boolean isObjectValueequals(Object obj1, Class < ? > Type) {
                    //判断类型是否为接口
                    if (Type.isInterface()) {
                        Class < ? > obj1Type = obj1.getClass();
                        //检查所有接口
                        for (Class InterfacesCla: obj1Type.getInterfaces()) {
                            if (InterfacesCla == Type) {
                                return true;
                            }
                        }
                        //如果当前实例没有实现接口则检查所有父类
                        Class < ? > Super = obj1Type.getSuperclass();
                        while (true) {
                            if (Super == null) {
                                return false;
                            }
                            //检查父类接口
                            for (Class InterfacesCla: Super.getInterfaces()) {
                                if (InterfacesCla == Type) {
                                    return true;
                                }
                            }
                            //没有则查下一个父类
                            Super = Super.getSuperclass();
                        }
                    } else {
                        //不是接口则检测所有继承的类
                        Class < ? > obj1Type = obj1.getClass();
                        if (obj1Type == Type) {
                            return true;
                        }

                        Class < ? > Super = obj1Type.getSuperclass();
                        while (true) {
                            //已经没有父类
                            if (Super == null) {
                                return false;
                            }

                            //父类和类型相同
                            if (Super == Type) {
                                return true;
                            }
                            //否则继续检查父类
                            Super = Super.getSuperclass();
                        }
                    }
                }

                //拆分对象数组
                public static Object[] SplitObjectArray(Object array) {
                    int length = Array.getLength(array);
                    Object[] result = new Object[length];
                    for (int i = 0; i < length; i++) {
                        result[i] = Array.get(array, i);
                    }
                    return result;
                }

                //显示视图
                private int ShowDiaViewEvent;
                public void showDialog(int EventId) {
                    View view = null;
                    switch (EventId) {
                        case NewButton.ConstructorEvent:
                            if (getConstructorCount() == 0) {
                                Toast.makeText(activity, "当前类没有构造方法", 0).show();
                                return;
                            }
                            view = MainConstructorView;
                            break;
                        case NewButton.FieldEvent:
                            if (getFieldCount() == 0) {
                                Toast.makeText(activity, "当前类没有字段", 0).show();
                                return;
                            }
                            view = MainFieldView;
                            break;
                        case NewButton.MethodEvent:
                            if (getMethodCount() == 0) {
                                Toast.makeText(activity, "当前类没有方法", 0).show();
                                return;
                            }
                            view = MainMethodView;
                            break;
                    }
                    AlertDialog.Builder Alert = new AlertDialog.Builder(activity);
                    Alert.setView(view)
                        .setOnDismissListener(this)
                        .show();
                    ShowDiaViewEvent = EventId;
                    DismissDialogEvent = EventId;
                }

                @Override
                //弹窗取消时移除视图
                private int DismissDialogEvent;
                public void onDismiss(DialogInterface dialog) {
                    switch (DismissDialogEvent) {
                        case NewButton.ConstructorEvent:
                            ((ViewGroup) MainConstructorView.getParent()).removeView(MainConstructorView);
                            break;
                        case NewButton.FieldEvent:
                            ((ViewGroup) MainFieldView.getParent()).removeView(MainFieldView);
                            break;
                        case NewButton.MethodEvent:
                            ((ViewGroup) MainMethodView.getParent()).removeView(MainMethodView);
                            break;
                    }

                }

                //输出类名
                public String toClassName() {
                    return Classes.getName();
                }

                //输出类格式
                public String ClassTypetoClassPath(Class < ? > Cla) {
                    if (Cla.isArray()) {
                        return Cla.getName();
                    }
                    switch (Cla.getName()) {
                        case "int":
                            return "I";
						case "long":
							return "J";
                        case "boolean":
                            return "Z";
                        case "char":
                            return "C";
                        case "double":
                            return "D";
                        case "float":
                            return "F";
                        case "byte":
                            return "B";
                        case "void":
                            return "V";
                        case "short":
                            return "S";
                    }
                    StringBuilder sb = new StringBuilder("L");
                    sb.append(Cla.getName().replace(".", "/"))
                        .append(";");
                    return sb.toString();
                }

                //输出类名
                public Class < ? > toClass() {
                    return Classes;
                }

                //解析
                static Class < ? > ParseClass(String ClassName) {
                    try {
                        return Class.forName(ClassName);
                    } catch (ClassNotFoundException e) {
                        return null;
                    }
                }


                public class ReflectConstructor extends BaseAdapter
                implements View.OnClickListener {

                    public static final int ConstructorNameTextView = 0xFF1;

                    public static final int NewEvent = 0xFF150;

                    public static final int NewParamEvent = 0xFF6401;

                    //全部字段
                    private List < Constructor > Constructors;

                    //当前选择的构造方法(点击,长按)
                    private Constructor CurrSelConstructors;

                    //日志
                    private Main main;

                    ReflectConstructor(List < Constructor > Constructors) throws IOException {
                        this.Constructors = Constructors;
                        this.main = new Main("ReflectTool/Constructor.log");
                        this.main.setConfig("New Instance");
                    }

                    @Override
                    //条目数
                    public int getCount() {
                        return getConstructors().size();
                    }

                    //获取所有方法
                    public List < Constructor > getConstructors() {
                        return Constructors;
                    }

                    @Override
                    //索引指定条目
                    public Object getItem(int position) {
                        //return ItemView.get(position);
                        return null;
                    }

                    @Override
                    public long getItemId(int position) {
                        return position;
                    }

                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        View view = initLayout(position);
                        return view;
                    }

                    //初始化最大显示条目数高度
                    public void initListViewHeight(ListView list) {
                        //最多显示八个
                        int totalHeight = 0;
                        int itemsToMeasure = Math.min(getCount(), 8);
                        if (itemsToMeasure < 8) {
                            //终止交易
                            return;
                        }
                        for (int i = 0; i < itemsToMeasure; i++) {
                            View item = initLayout(0);
                            item.measure(0, 0);
                            totalHeight += item.getMeasuredHeight();
                        }
                        //添加分割线高度
                        totalHeight += list.getDividerHeight() * (itemsToMeasure - 1);
                        //设置ListView高度
                        ViewGroup.LayoutParams params = list.getLayoutParams();
                        params.height = totalHeight;
                        list.requestLayout();
                    }

                    private LinearLayout initLayout(int index) {
                        Constructor constructor = getConstructors().get(index);
                        LinearLayout linear = new LinearLayout(activity);
                        linear.setId(NewEvent);
                        linear.setTag(index);
                        linear.setOnClickListener(this);
                        //linear.setOnLongClickListener(this);
                        linear.setOrientation(LinearLayout.HORIZONTAL);
                        linear.setGravity(Gravity.CENTER_VERTICAL);
                        linear.setPadding(0, 30, 0, 30);

                        GradientDrawable drawable = new GradientDrawable();
                        drawable.setColor(0xFFFFFFFF);
                        int[][] states = new int[][] {
                            //启用状态
                            new int[] {
                                    android.R.attr.state_enabled
                                },
                                //禁用状态
                                new int[] {
                                    -android.R.attr.state_enabled
                                },
                                //按下状态
                                new int[] {
                                    android.R.attr.state_pressed
                                }
                        };
                        int[] colors = new int[] {
                            0xFFF5F5F5,
                            Color.GRAY,
                            0xFFF5F5F5
                        };
                        ColorStateList colorStateList = new ColorStateList(states, colors);
                        linear.setBackground(new RippleDrawable(colorStateList, drawable, null));

                        //标识
                        TextView C = new TextView(activity);
                        C.setGravity(Gravity.CENTER);
                        LinearLayout.LayoutParams FParams = new LinearLayout.LayoutParams(
                            100,
                            100);
                        FParams.leftMargin = 55;
                        FParams.rightMargin = 25;
                        C.setLayoutParams(FParams);
                        C.setText("C");
                        C.setTextSize(23);
                        C.setTextColor(Color.BLUE);
                        C.setPadding(0, 0, 0, 0);
                        linear.addView(C);

                        //路径
                        TextView MethodText = new TextView(activity);
                        MethodText.setTextSize(13);
                        MethodText.setId(ConstructorNameTextView);
                        String Path = getPath(constructor);
                        MethodText.setText(Path);
                        linear.addView(MethodText);
                        return linear;
                    }

                    //路径
                    public String getPath(Constructor constructor) {
                        String Path = getAccessModifier(constructor.getModifiers());
                        //构造
                        Path += " constructor ";
                        //方法
                        Path += "<init>";
                        //参数
                        Path += "(";
                        for (Class < ? > Parameter : constructor.getParameterTypes()) {
                            Path += ClassTypetoClassPath(Parameter);
                        }
                        //返回值
                        Path += ")V";
                        return Path;
                    }

                    //对象转字符串
                    private String ObjecttoString(Object obj) {
                        if (obj.getClass().isArray()) {
                            return Arrays.toString((Object[]) obj);
                        }
                        return String.valueOf(obj);
                    }

                    //实例化
                    private Object NewInstance(Constructor constructor, Object[] ParameValue) throws Exception {
                        if (!constructor.isAccessible()) {
                            constructor.setAccessible(true);
                        }
                        Object value = constructor.newInstance(ParameValue);
                        setObjectValue(value);
                        return value;
                    }

                    //清理edittext颜色
                    private void ClearEditTextColor(EditText[] Edit) {
                        for (EditText edit: Edit) {
                            edit.setBackgroundTintList(null);
                        }
                    }

                    @Override
                    public void onClick(View v) {
                        switch (v.getId()) {
                            //有参实例化
                            case NewParamEvent:
                                Object[] tag = (Object[]) v.getTag();
                                //输入框
                                EditText[] ValueEditArray = (EditText[]) tag[0];
                                ClearEditTextColor(ValueEditArray);
                                //参数数量
                                int count = CurrSelConstructors.getParameterCount();
                                //参数类型
                                Class < ? > [] ParamTypeArray = CurrSelConstructors.getParameterTypes();
                                //参数值
                                Object[] ParamValue = new Object[count];
                                //循环
                                for (int i = 0; i < count; i++) {
                                    EditText ValueEdit = ValueEditArray[i];
                                    //用户文本
                                    String text = ValueEdit.getText().toString();
                                    //参数类型
                                    Class < ? > ParamType = ParamTypeArray[i];

                                    //判断是否为Null值
                                    String NullTag = text.toLowerCase() + ParseObjectIp(ParamType);
                                    if (ObjectManager.containsKey(NullTag)) {
                                        ParamValue[i] = BasicNullValue.get(ParamType);
                                        continue;
                                    }

                                    //判断是否为9大基本数据
                                    if (isBasicObject(ParamType)) {
                                        //查看用户使用的是否为对象管理器值
                                        Object value = getObjectValue(text);
                                        if (value == null) {
                                            try {
                                                //否则按基础数据处理
                                                value = StrToBasicObject(ParamType, text);
                                                ParamValue[i] = value;
                                            } catch (NumberFormatException e) {
                                                ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                                Toast.makeText(activity, "Param" + (i + 1) + "值与参数类型不符", 0).show();
                                                return;
                                            }
                                        } else {
                                            //判断用户值是否和参数类型一致
                                            if (!isObjectValueequals(value, ParamType)) {
                                                //暴毙
                                                ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                                Toast.makeText(activity, "Param" + (i + 1) + "值与参数类型不符", 0).show();
                                                return;
                                            }
                                        }
                                        //一致则填入值
                                        ParamValue[i] = value;
                                        continue;
                                    } else {
                                        //从管理器取值
                                        Object value = getObjectValue(text);
                                        if (value == null) {
                                            ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                            Toast.makeText(activity, "Param" + (i + 1) + "：该地址无对象", 0).show();
                                            return;
                                        }
                                        //校验值
                                        if (!isObjectValueequals(value, ParamType)) {
                                            ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                            Toast.makeText(activity, "Param" + (i + 1) + "：该实例与参数类型不符", 0).show();
                                            return;
                                        }
                                        ParamValue[i] = value;
                                        continue;
                                    }
                                }
                                try {
                                    Object New = NewInstance(CurrSelConstructors, ParamValue);
                                    String ip = ParseObjectIp(New);

                                    //复制到剪贴板
                                    ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                                    clipboard.setText(ip);

                                    String valueStr = ObjecttoString(New);
                                    main.WriteLog("java.lang.Object",
                                        "toString",
                                        "New Instance",
                                        "Class：" + toClassName() + "\n" +
                                        "Name：<init>\n" +
                                        "ParamType：" + Arrays.toString((Object[]) ParamTypeArray) + "\n" +
                                        "ParamValue：" + Arrays.toString(ParamValue) + "\n" +
                                        "InstanceStr：" + valueStr + "\n" +
                                        "Object：" + ip);

                                    ((AlertDialog) tag[1]).dismiss();

                                    Toast.makeText(activity, "<init>：" + valueStr, 0).show();
                                } catch (Exception e) {
                                    AlertDialog.Builder ExceptionDialog = new AlertDialog.Builder(activity);
									String mess = e.getCause().getMessage();
									if(mess == null){
										mess = "：Null";
									}else{
										mess = "：" + mess;
									}
                                    ExceptionDialog.setTitle("Exception")
                                        .setMessage(e.toString() + mess)
                                        .show();
                                }
                                break;
                                //实例化
                            case NewEvent:
                                int index = (int) v.getTag();
                                this.CurrSelConstructors = getConstructors().get(index);
                                //如果没有参数则直接实例化
                                if (CurrSelConstructors.getParameterCount() == 0) {
                                    try {
                                        Object value = NewInstance(CurrSelConstructors, null);
                                        String ip = ParseObjectIp(value);
                                        String valueStr = ObjecttoString(value);
                                        main.WriteLog("java.lang.Object",
                                            "toString",
                                            "New Instance",
                                            "Class：" + toClassName() + "\n" +
                                            "Name：<init>\n" +
                                            "ParamType：[]\n" +
                                            "ParamValue：[]\n" +
                                            "InstanceStr：" + valueStr + "\n" +
                                            "Object：" + ip);

                                        ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                                        clipboard.setText(ip);

                                        Toast.makeText(activity, "<init>：" + valueStr, 1).show();
                                    } catch (Exception e) {
                                        AlertDialog.Builder ExceptionDialog = new AlertDialog.Builder(activity);
										String mess = e.getCause().getMessage();
										if(mess == null){
											mess = "：Null";
										}else{
											mess = "：" + mess;
										}
										ExceptionDialog.setTitle("Exception")
											.setMessage(e.toString() + mess)
											.show();
                                    }
                                } else {
                                    //主视图
                                    LinearLayout MainView = new LinearLayout(activity);
                                    MainView.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams MainViewParam = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT);
                                    MainView.setLayoutParams(MainViewParam);

                                    //滚动视图
                                    ScrollView Scroll = new ScrollView(activity);
                                    Scroll.setVerticalScrollBarEnabled(false);
                                    Scroll.setHorizontalScrollBarEnabled(false);
                                    LinearLayout ScrolllistView = new LinearLayout(activity);
                                    ScrolllistView.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams ScrolllistViewParam = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT);
                                    Scroll.setLayoutParams(ScrolllistViewParam);

                                    //列出所有参数供用户填写
                                    Class < ? > [] ParamsArrays = CurrSelConstructors.getParameterTypes();
                                    int Parametercount = CurrSelConstructors.getParameterCount();
                                    EditText[] EditArray = new EditText[Parametercount];
                                    for (int i = 0; i < Parametercount; i++) {
                                        //数据类型
                                        Class < ? > type = ParamsArrays[i];
                                        ObjectManager.put("this@null" + ParseObjectIp(type), BasicNullValue.get(type));

                                        //填写参数子视图
                                        LinearLayout setParamsView = new LinearLayout(activity);
                                        setParamsView.setGravity(Gravity.BOTTOM);
                                        setParamsView.setOrientation(LinearLayout.VERTICAL);
                                        setParamsView.setPadding(0, 10, 0, 0);

                                        //参数
                                        TextView ParamsText = new TextView(activity);
                                        ParamsText.setText("Params" + (i + 1) + "：" + type.getName());
                                        ParamsText.setPadding(0, 0, 0, 5);
                                        setParamsView.addView(ParamsText);

                                        //参数填写框
                                        EditText setValueEdit = new EditText(activity);
                                        setValueEdit.setHint("Value");
                                        setValueEdit.setSingleLine(true);
                                        setValueEdit.setBackgroundTintList(null);
                                        setParamsView.addView(setValueEdit);
                                        EditArray[i] = setValueEdit;

                                        ScrolllistView.addView(setParamsView);

                                        //如果条目数增加到4则限制高度
                                        if (i == 3) {
                                            int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(
                                                0,
                                                View.MeasureSpec.UNSPECIFIED);
                                            setParamsView.measure(0, heightMeasureSpec);
                                            int Height = (setParamsView.getMeasuredHeight() * 4) + setParamsView.getMeasuredHeight() / 4;
                                            LinearLayout.LayoutParams xxx = new LinearLayout.LayoutParams(
                                                LinearLayout.LayoutParams.MATCH_PARENT,
                                                Height);
                                            Scroll.setLayoutParams(xxx);
                                            //((ViewGroup.LayoutParams)ScrolllistView.getParent()).height = Height;
                                        }
                                    }
                                    Scroll.addView(ScrolllistView);
                                    MainView.addView(Scroll);

                                    //实例化框
                                    LinearLayout NewInstanceView = new LinearLayout(activity);
                                    NewInstanceView.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
                                    LinearLayout.LayoutParams NewInstanceViewParam = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT);
                                    NewInstanceViewParam.topMargin = 30;
                                    NewInstanceViewParam.bottomMargin = 50;
                                    NewInstanceViewParam.rightMargin = 30;
                                    NewInstanceView.setLayoutParams(NewInstanceViewParam);

                                    //实例化按钮
                                    Button NewInstanceButton = new Button(activity);
                                    NewInstanceButton.setAllCaps(false);
                                    NewInstanceButton.setBackground(null);
                                    NewInstanceButton.setId(NewParamEvent);
                                    NewInstanceButton.setOnClickListener(this);
                                    NewInstanceButton.setText("New ->");

                                    NewInstanceView.addView(NewInstanceButton);
                                    MainView.addView(NewInstanceView);

                                    AlertDialog.Builder NewDialog = new AlertDialog.Builder(activity);
                                    AlertDialog DDialog = NewDialog.setTitle("Constructor：<init>")
                                        .setMessage("请输入构造方法参数\n如需null空值则填写this@null\n需要当前activity或application也是如此\nActivity：this@activity\nApplication：this@application")
                                        .setView(MainView)
                                        .show();

                                    //设置标签
                                    NewInstanceButton.setTag(new Object[] {
                                        EditArray,
                                        DDialog
                                    });
                                }
                                break;
                        }
                    }
                }


                public class ReflectMethod extends BaseAdapter
                implements View.OnClickListener {

                    public static final int MethodNameTextView = 0xFF1;

                    public static final int InvokeEvent = 0xFF150;

                    public static final int InvokeParamEvent = 0xFF450;

                    //全部字段
                    private List < Method > Methods;

                    //当前选择的方法(点击,长按)
                    private Method CurrSelMethod;

                    //日志
                    private Main main;

                    ReflectMethod(List < Method > Methods) throws IOException {
                        this.Methods = Methods;
                        this.main = new Main("ReflectTool/Method.log");
                        this.main.setConfig("Invoke");
                    }

                    @Override
                    //条目数
                    public int getCount() {
                        return getMethods().size();
                    }

                    //获取所有方法
                    public List < Method > getMethods() {
                        return Methods;
                    }

                    @Override
                    //索引指定条目
                    public Object getItem(int position) {
                        //return ItemView.get(position);
                        return null;
                    }

                    @Override
                    public long getItemId(int position) {
                        return position;
                    }

                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        View view = initLayout(position);
                        return view;
                    }

                    //初始化最大显示条目数高度
                    public void initListViewHeight(ListView list) {
                        //最多显示八个
                        int totalHeight = 0;
                        int itemsToMeasure = Math.min(getCount(), 8);
                        if (itemsToMeasure < 8) {
                            //终止交易
                            return;
                        }
                        for (int i = 0; i < itemsToMeasure; i++) {
                            View item = initLayout(0);
                            item.measure(0, 0);
                            totalHeight += item.getMeasuredHeight();
                        }
                        //添加分割线高度
                        totalHeight += list.getDividerHeight() * (itemsToMeasure - 1);
                        //设置ListView高度
                        ViewGroup.LayoutParams params = list.getLayoutParams();
                        params.height = totalHeight;
                        list.requestLayout();
                    }

                    private LinearLayout initLayout(int index) {
                        Method method = getMethods().get(index);
                        LinearLayout linear = new LinearLayout(activity);
                        linear.setId(InvokeEvent);
                        linear.setTag(index);
                        linear.setOnClickListener(this);
                        //linear.setOnLongClickListener(this);
                        linear.setOrientation(LinearLayout.HORIZONTAL);
                        linear.setGravity(Gravity.CENTER_VERTICAL);
                        linear.setPadding(0, 30, 0, 30);

                        GradientDrawable drawable = new GradientDrawable();
                        drawable.setColor(0xFFFFFFFF);
                        int[][] states = new int[][] {
                            //启用状态
                            new int[] {
                                    android.R.attr.state_enabled
                                },
                                //禁用状态
                                new int[] {
                                    -android.R.attr.state_enabled
                                },
                                //按下状态
                                new int[] {
                                    android.R.attr.state_pressed
                                }
                        };
                        int[] colors = new int[] {
                            0xFFF5F5F5,
                            Color.GRAY,
                            0xFFF5F5F5
                        };
                        ColorStateList colorStateList = new ColorStateList(states, colors);
                        linear.setBackground(new RippleDrawable(colorStateList, drawable, null));

                        //标识
                        TextView M = new TextView(activity);
                        M.setGravity(Gravity.CENTER);
                        LinearLayout.LayoutParams FParams = new LinearLayout.LayoutParams(
                            100,
                            100);
                        FParams.leftMargin = 55;
                        FParams.rightMargin = 25;
                        M.setLayoutParams(FParams);
                        M.setText("M");
                        M.setTextSize(23);
                        //F.setTextColor(0xFFFB8C00);
                        if (isStatic(method)) {
                            M.setTextColor(0xFF4FC3F7);
                        } else {
                            M.setTextColor(0xFFFF6060);
                        }
                        M.setPadding(0, 0, 0, 0);
                        linear.addView(M);

                        //路径
                        TextView MethodText = new TextView(activity);
                        MethodText.setTextSize(13);
                        MethodText.setId(MethodNameTextView);
                        String Path = getPath(method);
                        MethodText.setText(Path);
                        if (isNative(method)) {
                            //如果是native则直接变黑
                            MethodText.setTextColor(Color.BLACK);
                        } else {
                            //如果当前类管理器没有实例且方法不是静态则变红
                            if (ClassesInstance == null && !isStatic(method)) {
                                MethodText.setTextColor(Color.RED);
                            }
                        }
                        linear.addView(MethodText);
                        return linear;
                    }

                    //路径
                    public String getPath(Method method) {
                        String Path = getAccessModifier(method.getModifiers());
                        //静态
                        Path += isStatic(method) ? " static " : " ";
                        //native函数
                        Path += isNative(method) ? "native " : "";
                        //方法
                        Path += method.getName();
                        //参数
                        Path += "(";
                        for (Class < ? > Parameter : method.getParameterTypes()) {
                            Path += ClassTypetoClassPath(Parameter);
                        }
                        Path += ")";
                        //返回值
                        Path += ClassTypetoClassPath(method.getReturnType());
                        return Path;
                    }

                    //方法是否静态
                    private boolean isStatic(Method method) {
                        return ((method.getModifiers() & Modifier.STATIC) != 0);
                    }

                    //方法是否为native
                    private boolean isNative(Method method) {
                        return Modifier.isNative(method.getModifiers());
                    }

                    //清理edittext颜色
                    private void ClearEditTextColor(EditText[] Edit) {
                        for (EditText edit: Edit) {
                            edit.setBackgroundTintList(null);
                        }
                    }

                    //对象转字符串
                    private String ObjecttoString(Object obj) {
                        if (obj.getClass().isArray()) {
                            return Arrays.toString((Object[]) obj);
                        }
                        return String.valueOf(obj);
                    }

                    //执行方法
                    private Object invoke(Method method) throws Exception {
                        return invoke(method, null);
                    }

                    public Object invoke(Method method, Object[] Value) throws Exception {
                        if (!method.isAccessible()) {
                            method.setAccessible(true);
                        }
                        Object value = method.invoke(ClassesInstance, Value);
                        if (value != null) {
                            setObjectValue(value);
                        }
                        return value;
                    }

                    @Override
                    public void onClick(View v) {
                        switch (v.getId()) {
                            //有参执行
                            case InvokeParamEvent:
                                Object[] tag = (Object[]) v.getTag();
                                //输入框
                                EditText[] ValueEditArray = (EditText[]) tag[0];
                                ClearEditTextColor(ValueEditArray);
                                //参数数量
                                int count = CurrSelMethod.getParameterCount();
                                //参数类型
                                Class < ? > [] ParamTypeArray = CurrSelMethod.getParameterTypes();
                                //参数值
                                Object[] ParamValue = new Object[count];
                                //循环
                                for (int i = 0; i < count; i++) {
                                    EditText ValueEdit = ValueEditArray[i];
                                    //用户文本
                                    String text = ValueEdit.getText().toString();
                                    //参数类型
                                    Class < ? > ParamType = ParamTypeArray[i];

                                    //判断是否为Null值
                                    String NullTag = text.toLowerCase() + ParseObjectIp(ParamType);
                                    if (ObjectManager.containsKey(NullTag)) {
                                        ParamValue[i] = BasicNullValue.get(ParamType);
                                        continue;
                                    }

                                    //判断是否为9大基本数据
                                    if (isBasicObject(ParamType)) {
                                        //查看用户使用的是否为对象管理器值
                                        Object value = getObjectValue(text);
                                        if (value == null) {
                                            try {
                                                //否则按基础数据处理
                                                value = StrToBasicObject(ParamType, text);
                                                ParamValue[i] = value;
                                            } catch (NumberFormatException e) {
                                                ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                                Toast.makeText(activity, "Param" + (i + 1) + "值与参数类型不符", 0).show();
                                                return;
                                            }
                                        } else {
                                            //判断用户值是否和参数类型一致
                                            if (!isObjectValueequals(value, ParamType)) {
                                                //暴毙
                                                ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                                Toast.makeText(activity, "Param" + (i + 1) + "值与参数类型不符", 0).show();
                                                return;
                                            }
                                        }
                                        //一致则填入值
                                        ParamValue[i] = value;
                                        continue;
                                    } else {
                                        //从管理器取值
                                        Object value = getObjectValue(text);
                                        if (value == null) {
                                            ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                            Toast.makeText(activity, "Param" + (i + 1) + "：该地址无对象", 0).show();
                                            return;
                                        }
                                        //校验值
                                        if (!isObjectValueequals(value, ParamType)) {
                                            ValueEdit.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                                            Toast.makeText(activity, "Param" + (i + 1) + "：该实例与参数类型不符", 0).show();
                                            return;
                                        }
                                        ParamValue[i] = value;
                                        continue;
                                    }
                                }
                                try {
                                    Object New = invoke(CurrSelMethod, ParamValue);
									//如果返回值等于null
                                    if (New == null) {
                                        String message = "：Null";
                                        if (CurrSelMethod.getReturnType() == Void.TYPE
											||CurrSelMethod.getReturnType() == ParseClass("java.lang.Void")) {
                                            message = "：Invoke";
                                        }
                                        main.WriteLog("java.lang.Object",
                                            "toString",
                                            "Invoke",
                                            "Class：" + toClassName() + "\n" +
                                            "Name：" + CurrSelMethod.getName() + "\n" +
                                            "ParamType：" + Arrays.toString((Object[]) ParamTypeArray) + "\n" +
                                            "ParamValue：" + Arrays.toString(ParamValue) + "\n" +
                                            "RetValueType：" + CurrSelMethod.getReturnType().getName() + "\n" +
                                            "RetValueStr：Null\n" +
                                            "Object：Null");
                                        ((AlertDialog) tag[1]).dismiss();
                                        Toast.makeText(activity, CurrSelMethod.getName() + message, 0).show();
                                        break;
                                    }
                                    String ip = ParseObjectIp(New);

                                    //复制到剪贴板
                                    ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                                    clipboard.setText(ip);

                                    String valueStr = ObjecttoString(New);
                                    main.WriteLog("java.lang.Object",
                                        "toString",
                                        "Invoke",
                                        "Class：" + toClassName() + "\n" +
                                        "Name：" + CurrSelMethod.getName() + "\n" +
                                        "ParamType：" + Arrays.toString((Object[]) ParamTypeArray) + "\n" +
                                        "ParamValue：" + Arrays.toString(ParamValue) + "\n" +
                                        "RetValueType：" + CurrSelMethod.getReturnType().getName() + "\n" +
                                        "RetValueStr：" + valueStr + "\n" +
                                        "Object：" + ip);

                                    ((AlertDialog) tag[1]).dismiss();

                                    Toast.makeText(activity, CurrSelMethod.getName() + "：" + valueStr, 0).show();
                                } catch (Exception e) {
                                    AlertDialog.Builder ExceptionDialog = new AlertDialog.Builder(activity);
									String mess = e.getCause().getMessage();
									if(mess == null){
										mess = "：Null";
									}else{
										mess = "：" + mess;
									}
                                    ExceptionDialog.setTitle("Exception")
                                        .setMessage(e.toString() + mess)
                                        .show();
                                }
                                break;
                                //无参执行
                            case InvokeEvent:
                                int index = (int) v.getTag();
                                Method method = getMethods().get(index);
                                String methodName = method.getName();
                                this.CurrSelMethod = method;
                                if (isNative(method)) {
                                    Toast.makeText(activity, "哒咩哟，" + methodName + "方法是native方法", 1).show();
                                    break;
                                }
                                if (ClassesInstance == null && !isStatic(method)) {
                                    Toast.makeText(activity, method.getName() + "是实例字段，当前Class没有实例", 0).show();
                                    break;
                                }
                                //如果无参则直接执行代码
                                if (method.getParameterCount() == 0) {
                                    try {
                                        String ip, ToastMessage, valueStr;
                                        Object value = invoke(method);
                                        if (method.getReturnType() == Void.TYPE || method.getReturnType() == ParseClass("java.lang.Void")) {
                                            //如果返回值为void则不复制内容
                                            ip = "void";
                                            valueStr = "void";
                                            ToastMessage = method.getName() + "：Invoke";
                                        } else {
                                            ToastMessage = method.getName() + "：";
                                            if (value != null) {
                                                ip = ParseObjectIp(value);
                                                ToastMessage += ObjecttoString(value);
                                                valueStr = ObjecttoString(value);
                                                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                                                clipboard.setText(ip);
                                            } else {
                                                ip = "null";
                                                ToastMessage += "null";
                                                valueStr = "null";
                                            }
                                        }
                                        main.WriteLog("java.lang.Object",
                                            "toString",
                                            "Invoke",
                                            "Class：" + toClassName() + "\n" +
                                            "Name：" + method.getName() + "\n" +
                                            "ParamType：[]\n" +
                                            "ParamValue：[]\n" +
                                            "RetValueType：" + CurrSelMethod.getReturnType().getName() + "\n" +
                                            "RetValueStr：" + valueStr + "\n" +
                                            "Object：" + ip);

                                        Toast.makeText(activity, ToastMessage, 1).show();
                                    } catch (Exception e) {
                                        AlertDialog.Builder ExceptionDialog = new AlertDialog.Builder(activity);
										String mess = e.getCause().getMessage();
										if(mess == null){
											mess = "：Null";
										}else{
											mess = "：" + mess;
										}
										ExceptionDialog.setTitle("Exception")
											.setMessage(e.toString() + mess)
											.show();
                                    }
                                } else {
                                    //主视图
                                    LinearLayout MainView = new LinearLayout(activity);
                                    MainView.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams MainViewParam = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT);
                                    MainView.setLayoutParams(MainViewParam);

                                    //滚动视图
                                    ScrollView Scroll = new ScrollView(activity);
                                    Scroll.setVerticalScrollBarEnabled(false);
                                    Scroll.setHorizontalScrollBarEnabled(false);
                                    LinearLayout ScrolllistView = new LinearLayout(activity);
                                    ScrolllistView.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams ScrolllistViewParam = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT);
                                    Scroll.setLayoutParams(ScrolllistViewParam);

                                    //列出所有参数供用户填写
                                    Class < ? > [] ParamsArrays = method.getParameterTypes();
                                    int Parametercount = method.getParameterCount();
                                    EditText[] EditArray = new EditText[Parametercount];
                                    for (int i = 0; i < Parametercount; i++) {
                                        //数据类型
                                        Class < ? > type = ParamsArrays[i];
                                        ObjectManager.put("this@null" + ParseObjectIp(type), BasicNullValue.get(type));

                                        //填写参数子视图
                                        LinearLayout setParamsView = new LinearLayout(activity);
                                        setParamsView.setGravity(Gravity.BOTTOM);
                                        setParamsView.setOrientation(LinearLayout.VERTICAL);
                                        setParamsView.setPadding(0, 10, 0, 0);

                                        //参数
                                        TextView ParamsText = new TextView(activity);
                                        ParamsText.setText("Params" + (i + 1) + "：" + type.getName());
                                        ParamsText.setPadding(0, 0, 0, 5);
                                        setParamsView.addView(ParamsText);

                                        //参数填写框
                                        EditText setValueEdit = new EditText(activity);
                                        setValueEdit.setHint("Value");
                                        setValueEdit.setSingleLine(true);
                                        setValueEdit.setBackgroundTintList(null);
                                        setParamsView.addView(setValueEdit);
                                        EditArray[i] = setValueEdit;

                                        ScrolllistView.addView(setParamsView);

                                        //如果条目数增加到4则限制高度
                                        if (i == 3) {
                                            int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(
                                                0,
                                                View.MeasureSpec.UNSPECIFIED);
                                            setParamsView.measure(0, heightMeasureSpec);
                                            int Height = (setParamsView.getMeasuredHeight() * 4) + setParamsView.getMeasuredHeight() / 4;
                                            LinearLayout.LayoutParams xxx = new LinearLayout.LayoutParams(
                                                LinearLayout.LayoutParams.MATCH_PARENT,
                                                Height);
                                            Scroll.setLayoutParams(xxx);
                                            //((ViewGroup.LayoutParams)ScrolllistView.getParent()).height = Height;
                                        }
                                    }
                                    Scroll.addView(ScrolllistView);
                                    MainView.addView(Scroll);

                                    //实例化框
                                    LinearLayout NewInstanceView = new LinearLayout(activity);
                                    NewInstanceView.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
                                    LinearLayout.LayoutParams NewInstanceViewParam = new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT);
                                    NewInstanceViewParam.topMargin = 30;
                                    NewInstanceViewParam.bottomMargin = 50;
                                    NewInstanceViewParam.rightMargin = 30;
                                    NewInstanceView.setLayoutParams(NewInstanceViewParam);

                                    //实例化按钮
                                    Button NewInstanceButton = new Button(activity);
                                    NewInstanceButton.setBackground(null);
                                    NewInstanceButton.setAllCaps(false);
                                    NewInstanceButton.setId(InvokeParamEvent);

                                    NewInstanceButton.setOnClickListener(this);
                                    NewInstanceButton.setText("Invoke ->");

                                    NewInstanceView.addView(NewInstanceButton);
                                    MainView.addView(NewInstanceView);

                                    AlertDialog.Builder NewDialog = new AlertDialog.Builder(activity);
                                    AlertDialog DDialog = NewDialog.setTitle("Method：" + method.getName())
                                        .setMessage("请输入方法参数\n如需null空值则填写this@null\n需要当前activity或application也是如此\nActivity：this@activity\nApplication：this@application")
                                        .setView(MainView)
                                        .show();

                                    //设置标签
                                    NewInstanceButton.setTag(new Object[] {
                                        EditArray,
                                        DDialog
                                    });
                                }
                                break;
                        }
                    }

                }

                //字段
                public class ReflectField extends BaseAdapter
                implements DialogInterface.OnClickListener,
                    View.OnClickListener,
                    View.OnLongClickListener {


                        public static final int setFieldValueEvent = 0xFFF58;

                        public static final int FieldNameTextView = 0xFF1;

                        public static final int getValueEvent = 0xFF150;

                        //全部字段
                        private List < Field > Fields;

                        //当前选择的字段(点击,长按)
                        private Field CurrSelField;

                        //日志
                        private Main main;

                        ReflectField(List < Field > Fields) throws IOException {
                            //field.setAccessible(true);
                            this.Fields = Fields;
                            this.main = new Main("ReflectTool/Field.log");
                        }

                        @Override
                        //条目数
                        public int getCount() {
                            return getFilds().size();
                        }

                        //获取所有字段
                        public List < Field > getFilds() {
                            return Fields;
                        }

                        @Override
                        //索引指定条目
                        public Object getItem(int position) {
                            //return ItemView.get(position);
                            return null;
                        }

                        @Override
                        public long getItemId(int position) {
                            return position;
                        }

                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            //如果已经存储则不再实例化(不可用,可能会在滑动的时候回收item点击和长按事件)
                            //if ((ItemView.size() - 1) <= position) {
                            //View view = initLayout(position);
                            //ItemView.add(view);
                            return initLayout(position);
                        }

                        //初始化最大显示条目数高度
                        public void initListViewHeight(ListView list) {
                            //最多显示八个
                            int totalHeight = 0;
                            int itemsToMeasure = Math.min(getCount(), 8);
                            if (itemsToMeasure < 8) {
                                //终止交易
                                return;
                            }
                            for (int i = 0; i < itemsToMeasure; i++) {
                                View item = initLayout(0);
                                item.measure(0, 0);
                                totalHeight += item.getMeasuredHeight();
                            }
                            //添加分割线高度
                            totalHeight += list.getDividerHeight() * (itemsToMeasure - 1);
                            //设置ListView高度
                            ViewGroup.LayoutParams params = list.getLayoutParams();
                            params.height = totalHeight;
                            list.requestLayout();
                        }

                        private LinearLayout initLayout(int index) {
                            Field field = getFilds().get(index);
                            LinearLayout linear = new LinearLayout(activity);
                            linear.setId(getValueEvent);
                            linear.setTag(index);
                            linear.setOnClickListener(this);
                            linear.setOnLongClickListener(this);
                            linear.setOrientation(LinearLayout.HORIZONTAL);
                            linear.setGravity(Gravity.CENTER_VERTICAL);
                            linear.setPadding(0, 30, 0, 30);

                            GradientDrawable drawable = new GradientDrawable();
                            drawable.setColor(0xFFFFFFFF);
                            int[][] states = new int[][] {
                                //启用状态
                                new int[] {
                                        android.R.attr.state_enabled
                                    },
                                    //禁用状态
                                    new int[] {
                                        -android.R.attr.state_enabled
                                    },
                                    //按下状态
                                    new int[] {
                                        android.R.attr.state_pressed
                                    }
                            };
                            int[] colors = new int[] {
                                0xFFF5F5F5,
                                Color.GRAY,
                                0xFFF5F5F5
                            };
                            ColorStateList colorStateList = new ColorStateList(states, colors);
                            linear.setBackground(new RippleDrawable(colorStateList, drawable, null));

                            //标识
                            TextView F = new TextView(activity);
                            F.setGravity(Gravity.CENTER);
                            LinearLayout.LayoutParams FParams = new LinearLayout.LayoutParams(
                                100,
                                100);
                            FParams.leftMargin = 55;
                            FParams.rightMargin = 25;
                            F.setLayoutParams(FParams);
                            F.setText("F");
                            F.setTextSize(23);
                            //F.setTextColor(0xFFFB8C00);
                            if (isStatic(field)) {
                                F.setTextColor(0xFF4FC3F7);
                            } else {
                                F.setTextColor(0xFFFF6060);
                            }
                            F.setPadding(0, 0, 0, 0);
                            linear.addView(F);

                            //路径
                            TextView FieldText = new TextView(activity);
                            FieldText.setId(FieldNameTextView);
                            FieldText.setTextSize(13);
                            String Path = getPath(field);
                            FieldText.setText(Path);
                            //如果当前类管理器没有实例且字段不是静态则变红
                            if (ClassesInstance == null && !isStatic(field)) {
                                FieldText.setTextColor(Color.RED);
                            }
                            linear.addView(FieldText);
                            return linear;
                        }

                        public String getPath(Field field) {
                            String Path = field.getName() + ":" + ClassTypetoClassPath(field.getType());
                            Path = getAccessModifier(field.getModifiers()) + (((isStatic(field)) ? " static " : " ")) + Path;
                            return Path;
                        }

                        //对象转字符串
                        private String ObjecttoString(Object obj) {
                            if (obj.getClass().isArray()) {
                                return Arrays.toString((Object[]) obj);
                            }
                            return String.valueOf(obj);
                        }

                        //字段是否静态
                        private boolean isStatic(Field field) {
                            return ((field.getModifiers() & Modifier.STATIC) != 0);
                        }

                        //获取
                        private Object getFieldValue(Field field) throws Exception {
                            Field fields = field;
                            if (!fields.isAccessible()) {
                                fields.setAccessible(true);
                            }
                            Object obj = field.get(ClassesInstance);
                            if (obj != null) {
                                setObjectValue(obj);
                            }
                            return obj;
                        }

                        //设置值
                        private void setFieldValue(Field field, Object value) throws Exception {
                            if (!field.isAccessible()) {
                                field.setAccessible(true);
                            }
                            if (value != null) {
                                setObjectValue(value);
                            }
                            field.set(ClassesInstance, value);
                        }

                        //点击事件
                        @Override
                        public void onClick(View v) {
                            Object value;
                            switch (v.getId()) {
                                //设置值
                                case setFieldValueEvent:
                                    try {
                                        Object[] vvalue = (Object[]) v.getTag();
                                        EditText setValueEdit = (EditText) vvalue[0];
                                        String Text = setValueEdit.getText().toString();
                                        //判断是否为Null值
                                        String NullTag = Text.toLowerCase() + ParseObjectIp(CurrSelField.getType());
                                        if (ObjectManager.containsKey(NullTag)) {
                                            value = getObjectValue(NullTag);
                                            ((AlertDialog) vvalue[1]).dismiss();
                                            setFieldValue(CurrSelField, value);
                                            String ToastMessage = value == null ? "null" : String.valueOf(value);
                                            Toast.makeText(activity, CurrSelField.getName() + "：" + ToastMessage, 1).show();
                                            return;
                                        }
                                        //判断是否为9大数据类型
                                        Class < ? > type = CurrSelField.getType();
                                        //前提对象管理器等于null
                                        if (getObjectValue(Text) == null && isBasicObject(type)) {
                                            try {
                                                value = StrToBasicObject(type, Text);
                                                ((AlertDialog) vvalue[1]).dismiss();
                                                setFieldValue(CurrSelField, value);
                                                Toast.makeText(activity, CurrSelField.getName() + "：" + value.toString(), 1).show();
                                            } catch (NumberFormatException e) {
                                                AlertDialog.Builder ExceptionDialog = new AlertDialog.Builder(activity);
                                                ExceptionDialog.setTitle("Exception")
                                                    .setMessage(e.toString())
                                                    .show();
                                                return;
                                            }
                                        } else {
                                            //不是则从对象管理器取值
                                            value = getObjectValue(Text);
                                            if (value == null) {
                                                Toast.makeText(activity, "该地址无对象", 1).show();
                                                return;
                                            }
                                            //判断类型是否符合
                                            if (!isObjectValueequals(value, CurrSelField.getType())) {
                                                Toast.makeText(activity, "该值对象与字段类型不符", 1).show();
                                                return;
                                            }
                                            //设置值
                                            setFieldValue(CurrSelField, value);

                                            //导出日志
                                            String valueType, valueStr, ValueIp;
                                            if (value == null) {
                                                valueType = "null";
                                                valueStr = "null";
                                                ValueIp = "null";
                                            } else {
                                                valueType = value.getClass().getTypeName();
                                                valueStr = ObjecttoString(value);
                                                ValueIp = ParseObjectIp(value);
                                                //setObjectValue(value);
                                            }

                                            main.setConfig("setValue");
                                            main.WriteLog("java.lang.Object",
                                                "toString",
                                                "setValue",
                                                "Class：" + toClassName() + "\n" +
                                                "ClassInstance：" + getInstance() + "\n" +
                                                "FieldName：" + CurrSelField.getName() + "\n" +
                                                "FieldType：" + valueType + "\n" +
                                                "FieldValue：" + valueStr + "\n" +
                                                "Object：" + ValueIp);

                                            Toast.makeText(activity, CurrSelField.getName() + "：" + valueStr, 1).show();
                                            ((AlertDialog) vvalue[1]).dismiss();
                                        }
                                    } catch (Exception e) {
                                        AlertDialog.Builder ExceptionDialog = new AlertDialog.Builder(activity);
										String mess = e.getCause().getMessage();
										if(mess == null){
											mess = "：Null";
										}else{
											mess = "：" + mess;
										}
										ExceptionDialog.setTitle("Exception")
											.setMessage(e.toString() + mess)
											.show();
                                        //throw new RuntimeException("设置字段失败了：" + e.toString());
                                    }
                                    break;
                                    //获取字段值
                                case getValueEvent:
                                    int position = (int) v.getTag();
                                    Field field = getFilds().get(position);
                                    CurrSelField = field;
                                    if (ClassesInstance == null && !isStatic(field)) {
                                        Toast.makeText(activity, field.getName() + "是实例字段，当前Class没有实例", 0).show();
                                        return;
                                    }
                                    try {
                                        //获取值
                                        value = getFieldValue(field);
                                        String valueType, valueStr, ValueIp;
                                        if (value == null) {
                                            valueType = "null";
                                            valueStr = "null";
                                            ValueIp = "null";
                                        } else {
                                            valueType = value.getClass().getTypeName();
                                            valueStr = ObjecttoString(value);
                                            ValueIp = ParseObjectIp(value);
                                            //setObjectValue(value);
                                        }

                                        Toast.makeText(activity, field.getName() + "：" + valueStr, 0).show();
                                        main.setConfig("getValue");
                                        main.WriteLog("java.lang.Object",
                                            "toString",
                                            "getValue",
                                            "Class：" + toClassName() + "\n" +
                                            "ClassInstance：" + getInstance() + "\n" +
                                            "FieldName：" + field.getName() + "\n" +
                                            "FieldType：" + valueType + "\n" +
                                            "FieldValue：" + valueStr + "\n" +
                                            "Object：" + ValueIp);
                                    } catch (Exception e) {
                                        Toast.makeText(activity, "字段异常：" + e.toString(), 0).show();
                                    }
                                    break;
                            }
                        }

                        @Override
                        public boolean onLongClick(View v) {
                            int position = (int) v.getTag();
                            Field field = getFilds().get(position);
                            CurrSelField = field;
                            if (ClassesInstance == null && !isStatic(field)) {
                                Toast.makeText(activity, field.getName() + "是实例字段，当前Class没有实例", 0).show();
                                return true;
                            }
                            try {
                                AlertDialog.Builder listDialog = new AlertDialog.Builder(activity);
                                String[] Str;
                                if (getFieldValue(field) == null) {
                                    Str = new String[] {
                                        "setValue"
                                    };
                                } else {
                                    Str = new String[] {
                                        "CopyResult",
                                        "CopyAddress",
                                        "setValue"
                                    };
                                }
                                Items = Str;
                                listDialog.setTitle("行为")
                                    .setItems(Str, this)
                                    .show();
                            } catch (Exception e) {
                                Toast.makeText(activity, "ToolField：长按事件异常", 0).show();
                            }
                            return true;
                        }

                        @Override
                        private String[] Items;
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                switch (Items[which]) {
                                    //复制结果
                                    //复制地址
                                    case "CopyResult":
                                    case "CopyAddress":
                                        ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                                        Object obj = getFieldValue(CurrSelField);
                                        String result;
                                        if (which == 0) {
                                            //复制结果
                                            result = ObjecttoString(obj);
                                        } else {
                                            //解析地址
                                            result = ParseObjectIp(obj);
                                        }
                                        clipboard.setText(result);
                                        Toast.makeText(activity, "复制成功：" + result, 0).show();
                                        break;
                                        //设置代码值
                                    case "setValue":
                                        AlertDialog.Builder Dialog = new AlertDialog.Builder(activity);

                                        //主视图
                                        LinearLayout MainLinear = new LinearLayout(activity);
                                        MainLinear.setOrientation(LinearLayout.VERTICAL);
                                        MainLinear.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.TOP);
                                        LinearLayout.LayoutParams MainLinearParams = new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            LinearLayout.LayoutParams.WRAP_CONTENT);
                                        MainLinear.setLayoutParams(MainLinearParams);

                                        //设置值编辑框
                                        EditText setValueEdit = new EditText(activity);
                                        LinearLayout.LayoutParams setValueEditParams = new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            LinearLayout.LayoutParams.WRAP_CONTENT);
                                        setValueEditParams.bottomMargin = 30;
                                        setValueEdit.setLayoutParams(setValueEditParams);
                                        setValueEdit.setHint(CurrSelField.getType().getName());
                                        setValueEdit.setBackgroundTintList(null);
                                        setValueEdit.setSingleLine(true);
                                        MainLinear.addView(setValueEdit);

                                        //子视图
                                        LinearLayout Main2Linear = new LinearLayout(activity);
                                        LinearLayout.LayoutParams Main2LinearParams = new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            LinearLayout.LayoutParams.WRAP_CONTENT);
                                        Main2LinearParams.topMargin = 30;
                                        Main2LinearParams.bottomMargin = 50;
                                        Main2LinearParams.rightMargin = 30;
                                        Main2LinearParams.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                                        Main2Linear.setLayoutParams(Main2LinearParams);

                                        //设置值按钮
                                        Button setValue = new Button(activity);
                                        setValue.setAllCaps(false);
                                        setValue.setBackground(null);
                                        setValue.setText("set ->");
                                        setValue.setTag(setValueEdit);
                                        setValue.setId(setFieldValueEvent);
                                        setValue.setOnClickListener(this);
                                        Main2Linear.addView(setValue);

                                        MainLinear.addView(Main2Linear);

                                        //设置Null值
                                        Class < ? > type = CurrSelField.getType();
                                        ObjectManager.put("this@null" + ParseObjectIp(type), BasicNullValue.get(type));

                                        AlertDialog alert = Dialog.setTitle("Field：" + CurrSelField.getName())
                                            .setMessage("请输入设定值\n如需null空值则填写this@null\n需要当前activity或application也是如此\nActivity：this@activity\nApplication：this@application")
                                            .setView(MainLinear)
                                            .show();
                                        //填入标签，给点击事件使用
                                        setValue.setTag(new Object[] {
                                            setValueEdit,
                                            alert
                                        });
                                        break;
                                }
                            } catch (Exception e) {
                                Toast.makeText(activity, "ToolField：长按事件的对话框点击事件异常", 0).show();
                            }
                        }

                    }
            }
    }
