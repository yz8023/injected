package com.doubihuaji.Tool;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.os.Bundle;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

//SPListener
//作用：监听SharedPreferences读写删操作
public class SPListener extends ContextWrapper 
implements Application.ActivityLifecycleCallbacks,
SharedPreferences,
SharedPreferences.Editor {

	//存储所有SPListener实例
	private static Map<String,SharedPreferences> SPCheca;

	//Contextlmp
	private Context mBase;

	//当前SharedPreferences
	private SharedPreferences SP;

	//文件名称
	private String SPName;

	//当前Editor
	private SharedPreferences.Editor SPEditor;

	static{
		SPCheca = new HashMap<String,SharedPreferences>();
	}


	private SPListener(Context mBase, String SPName, int Mode) {
		super(mBase);
		SharedPreferences sp = mBase.getSharedPreferences(SPName, Mode);
		this.SP = sp;
		this.SPName = SPName;
		this.SPEditor = sp.edit();
	}

	private SPListener(Context c) {
		super(c);
		mBase = c;
	}

	public static void init(ContextWrapper contextw) {
		try {
			//获取原Contextlmp实例
			Context Contextlmp = contextw.getBaseContext();
			//实体化自身成为代理类
			SPListener spListener = new SPListener(Contextlmp);
			if (contextw instanceof Application) {
				((Application)contextw).registerActivityLifecycleCallbacks(spListener);
			}
			//反射ContextWrapper类
			Class<?> C_ContextWrapper = Class.forName("android.content.ContextWrapper");
			//获取mBase字段
			Field F_mBase = C_ContextWrapper.getDeclaredField("mBase");
			//设置访问权限
			F_mBase.setAccessible(true);
			//设置为自身实例
			F_mBase.set(contextw, spListener);
		} catch (Exception e) {
			throw new RuntimeException("SPListener初始化失败");
		}
	}

	@Override
	//重写自实现
	public SharedPreferences getSharedPreferences(String name, int mode) {
		SharedPreferences SP = SPCheca.get(name);
		if (SP == null) {
			SP = new SPListener(mBase, name, mode);
			this.SPName = name;
			outLog(name,mode);
			SPCheca.put(name, SP);
		}
		return SP;
	}

	//日志
	private void outLog(Object... obj) {
		try {
			Main main = new Main("Main.log");
			main.setConfig("SPListener");
			//调用的方法
			StringBuffer log = new StringBuffer();
			log.append("SPName：")
				.append(SPName)
				.append(".xml")
				.append("\n");
			String method = PrintLog.splitStack(PrintLog.getBasestack(1))[1];
			switch (method) {
				case "getSharedPreferences":
					log.append("invoke->getSharedPreferences()");
					break;
					//get
				case "getAll":
					log.append("AllValue：")
						.append(obj[0]);
					break;
				case "getStringSet":
				case "getString":
				case "getInt":
				case "getLong":
				case "getFloat":
				case "getBoolean":
					log.append("Key：")
						.append(obj[0])
						.append("\n")
						.append("defValue：")
						.append(obj[1])
						.append("\n")
						.append("retValue：")
						.append(obj[2]);
					break;
				case "contains":
					log.append("Key：")
						.append(obj[0])
						.append("\n")
						.append("Contains：")
						.append(obj[1]);
					break;
				case "edit":
					log.append("invoke->edit()");
					break;
				case "registerOnSharedPreferenceChangeListener":
				case "unregisterOnSharedPreferenceChangeListener":
					log.append("ChangeListener：")
						.append(obj[0]);
					break;
					//put
				case "putStringSet":
				case "putString":
				case "putInt":
				case "putLong":
				case "putFloat":
				case "putBoolean":
					log.append("Key：")
						.append(obj[0])
						.append("\n")
						.append("setValue：")
						.append(obj[1]);
					break;
				case "remove":
					log.append("Key：")
						.append(obj[0]);
					break;
				case "commit":
					log.append("commit：")
						.append(obj[0]);
					break;
				case "apply":
					log.append("invoke->apply()");
					break;
				case "clear":
					log.append("invoke->clear()");
					break;

			}
			//获取堆栈
			String Stack = PrintLog.getBasestack();
			Stack = Stack.split("\n", 2)[1];
			//调用方法
			main.WriteLog(
				"android.content.SharedPreferences",
				method,
				"SPListener",
				log.toString()
				+ "\n——————【Stack】——————\n"
				+ Stack);
		} catch (Exception e) {}
	}

	//Application.ActivityLifecycleCallbacks
	@Override
	public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
		init(activity);
	}



	//SharedPreferences
	@Override
	public Map<String, ?> getAll() {
		Map<String, ?> all = SP.getAll();
		outLog(all);
		return all;
	}

	@Override
	public boolean getBoolean(String key, boolean defValue) {
		boolean value = SP.getBoolean(key, defValue);
		outLog(key, defValue, value);
		return value;
	}

	@Override
	public float getFloat(String key, float defValue) {
		float value = SP.getFloat(key, defValue);
		outLog(key, defValue, value);
		return value;
	}

	@Override
	public int getInt(String key, int defValue) {
		int value = SP.getInt(key, defValue);
		outLog(key, defValue, value);
		return value;
	}

	@Override
	public long getLong(String key, long defValue) {
		long value = SP.getLong(key, defValue);
		outLog(key, defValue, value);
		return value;
	}

	@Override
	public String getString(String key, String defValue) {
		String value = SP.getString(key, defValue);
		outLog(key, defValue, value);
		return value;
	}

	@Override
	public Set<String> getStringSet(String key, Set<String> defValues) {
		Set<String> value = SP.getStringSet(key, defValues);
		outLog(key, defValues, value);
		return value;
	}

	@Override
	public boolean contains(String key) {
		boolean value = SP.contains(key);
		outLog(key, value);
		return value;
	}

	@Override
	public SharedPreferences.Editor edit() {
		outLog();
		return this;
	}

	@Override
	public void registerOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener listener) {
		outLog(listener);
		SP.registerOnSharedPreferenceChangeListener(listener);
	}

	@Override
	public void unregisterOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener listener) {
		outLog(listener);
		SP.unregisterOnSharedPreferenceChangeListener(listener);
	}

	//SharedPreferences.Editor
	@Override
	public SharedPreferences.Editor putBoolean(String key, boolean value) {
		outLog(key, value);
		SPEditor.putBoolean(key, value);
		return this;
	}

	@Override
	public SharedPreferences.Editor putFloat(String key, float value) {
		outLog(key, value);
		SPEditor.putFloat(key, value);
		return this;
	}

	@Override
	public SharedPreferences.Editor putInt(String key, int value) {
		outLog(key, value);
		SPEditor.putInt(key, value);
		return this;
	}

	@Override
	public SharedPreferences.Editor putLong(String key, long value) {
		outLog(key, value);
		SPEditor.putLong(key, value);
		return this;
	}

	@Override
	public SharedPreferences.Editor putString(String key, String value) {
		outLog(key, value);
		SPEditor.putString(key, value);
		return this;
	}

	@Override
	public SharedPreferences.Editor putStringSet(String key, Set<String> values) {
		outLog(key, values);
		SPEditor.putStringSet(key, values);
		return this;
	}

	@Override
	public SharedPreferences.Editor remove(String key) {
		outLog(key);
		SPEditor.remove(key);
		return this;
	}

	@Override
	public void apply() {
		outLog();
		SPEditor.apply();
	}

	@Override
	public SharedPreferences.Editor clear() {
		outLog();
		SPEditor.clear();
		return this;
	}

	@Override
	public boolean commit() {
		boolean value = SPEditor.commit();
		outLog(value);
		return value;
	}


	@Override
	public void onActivityDestroyed(Activity activity) {
	}

	@Override
	public void onActivityPaused(Activity activity) {
	}

	@Override
	public void onActivityResumed(Activity activity) {
	}

	@Override
	public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
	}

	@Override
	public void onActivityStarted(Activity activity) {
	}

	@Override
	public void onActivityStopped(Activity activity) {
	}
}
