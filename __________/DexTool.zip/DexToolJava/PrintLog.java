package com.doubihuaji.Tool;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import android.os.Looper;

//PrintLog
//作用：打印日志，堆栈
public class PrintLog 
implements Runnable {

	private static boolean Thread;

	private Object obj;

	static{
		Thread = false;
	}

	private PrintLog(Object obj) {
		this.obj = obj;
	}

	//设置子线程打印日志
	public static void setPrintLogThread() {
		Thread = true;
	}

	//打印对象
	public static void Printlog(Object obj) {
		if (Thread) {
			StackTraceElement stack = RemoveDoubihuaji(Stack()).get(0);
			Object[] Obj = new Object[]{obj,stack.getClassName(),stack.getMethodName()};
			new Thread(new PrintLog(Obj)).start();
		} else {
			PrintObject(null, null, obj);
		}
	}

	//打印堆栈
	public static void PrintStack() {
		try {
			List<StackTraceElement> Stack = RemoveDoubihuaji(Stack());
			String Stacklog = StackString(Stack);
			Main main = new Main("/Main.log", true);
			main.setConfig("Stack");
			main.WriteLog(Stacklog);
		} catch (IOException e) {
			throw new RuntimeException("PrintLog.PrintStack输出流异常：" + e.toString());
		}
	}

	public static void Printint(int obj) {
		Printlog(new Integer(obj));
	}

	public static void Printlong(long obj) {
		Printlog(new Long(obj));
	}

	public static void Printboolean(boolean obj) {
		Printlog(new Boolean(obj));
	}

	public static void Printbyte(byte obj) {
		Printlog(new Byte(obj));
	}

	public static void Printdouble(double obj) {
		Printlog(new Double(obj));
	}

	public static void Printfloat(float obj) {
		Printlog(new Float(obj));
	}

	public static void Printshort(short obj) {
		Printlog(new Short(obj));
	}

	public static void Printchar(char obj) {
		Printlog(new Character(obj));
	}

	private static void PrintObject(String ClassName, String MethodName, Object obj) {
		String str = "";
		try {
			Main main = new Main("/Main.log");
			main.setConfig();
			//main.setConfig("PrintLog");
			if (obj != null) {
				Class<?> type = obj.getClass();
				//判断是否是数组
				if (type.isArray()) {
					switch (type.getName()) {
						case "[Ljava.lang.String;":
							str = Arrays.toString((String[])obj);
							break;
						case "[Ljava.lang.Boolean;":
							str = Arrays.toString((Boolean[])obj);
							break;
						case "[B":
							str = Arrays.toString((byte[])obj);
							break;
						case "[Ljava.lang.Double;":
							str = Arrays.toString((Double[])obj);
							break;
						case "[Ljava.lang.Float;":
							str = Arrays.toString((Float[])obj);
							break;
						case "[I":
							str = Arrays.toString((int[])obj);
							break;
						case "[J":
							str = Arrays.toString((long[])obj);
							break;
						case "[Ljava.lang.Short;":
							str = Arrays.toString((Short[])obj);
							break;
						case "[C":
							Integer[] IntValue = new Integer[((char[])obj).length];
							int num = 0;
							for (char c : ((char[])obj)) {
								IntValue[num] = (int) c;
								num++;
							}
							str = Arrays.toString(IntValue);
							break;
					}
					if (str.length() == 0) {
						str = Arrays.deepToString((Object[]) obj);
					}
				} else {
					switch (type.getName()) {
						case "java.lang.String":
							str = (String) obj;
							break;
						case "java.lang.Boolean":
							str = String.valueOf((boolean)obj);
							break;
						case "java.lang.Byte":
							str = String.valueOf((byte)obj);
							break;
						case "java.lang.Double":
							str = String.valueOf((Double)obj);
							break;
						case "java.lang.Float":
							str = String.valueOf((Float)obj);
							break;
						case "java.lang.Integer":
							str = String.valueOf((int)obj);
							break;
						case "java.lang.Long":
							str = String.valueOf((long)obj);
							break;
						case "java.lang.Short":
							str = String.valueOf((Short)obj);
							break;
						case "java.lang.Character":
							str = String.valueOf((int)(char)obj);
							break;
					}
					if (str.length() == 0) {
						str = obj.toString();
					}
				}
				main.WriteLog(ClassName, MethodName, "Printlog：" + type.getName(), str).flush();
			} else {
				main.WriteLog(ClassName, MethodName, "Printlog：Null", "null").flush();
			}

		} catch (IOException e) {
			//失败
			throw new RuntimeException("PrintLog.PrintObject输出流异常：" + e.toString());
		}
	}

	@Override
	public void run() {
		Object[] Obj = (Object[]) obj;
		PrintObject((String)Obj[1], (String)Obj[2], Obj[0]);
	}

	//获取堆栈字符串
	static String getstack() {
		List<StackTraceElement> Stack = RemoveDoubihuaji(Stack());
		return StackString(Stack);
	}
	
	//获取堆栈索引字符串
	static String getstack(int index) {
		return getstack().split("\n")[index];
	}

	//获取原堆栈字符串
	static String getBasestack() {
		List<StackTraceElement> list = new ArrayList<StackTraceElement>();
		for (StackTraceElement stack : Stack()) {
			String Stack = StackString(stack);
			if (Stack.startsWith("com.doubihuaji.Tool.PrintLog->")) {
				continue;
			}
			list.add(stack);
		}
		return StackString(list);
	}

	//获取原堆栈索引字符串
	static String getBasestack(int index) {
		return getBasestack().split("\n")[index];
	}

	//拆分堆栈
	static String[] splitStack(String stack) {
		String[] Stack = stack.split("->");
		String[] Str = new String[2];
		Str[0] = Stack[0];
		Str[1] = Stack[1].substring(0, Stack[1].lastIndexOf("("));
		return Str;
	}

	//获取堆栈
	private static StackTraceElement[] Stack() {
		return new Throwable().getStackTrace();
	}

	//拼装堆栈日志
	private static String StackString(List<StackTraceElement> stack) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < stack.size(); i++) {
			sb.append(StackString(stack.get(i))).append("\n");
		}
		int len = sb.length();
		sb.delete(len - 1, len);
		return sb.toString();
	}

	private static String StackString(StackTraceElement stack) {
		StringBuffer sb  = new StringBuffer();
		StackTraceElement item = stack;
		sb.append(item.getClassName());
		sb.append("->");
		sb.append(item.getMethodName());
		sb.append("(");
		String Filename = item.getFileName();
		if (Filename == null || Filename.length() == 0) {
			sb.append("File.java:");
		} else {
			sb.append(Filename);
		}
		sb.append(":");
		sb.append(item.getLineNumber());
		sb.append(")");
		//sb.append("\n");
		return sb.toString();
	}

	//移除逗比滑稽 确信:(
	private static List<StackTraceElement> RemoveDoubihuaji(StackTraceElement[] Stack) {
		List<StackTraceElement> list = new ArrayList<StackTraceElement>();
		String clas = "com.doubihuaji.Tool.";
		for (StackTraceElement stack : Stack) {
			if (!stack.getClassName().startsWith(clas)) {
				list.add(stack);
			}
		}
		return list;
	}

}
