package com.doubihuaji.Tool;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

//AllView
//作用：追踪View|遍历当前活动View
public class AllView
implements Application.ActivityLifecycleCallbacks,
View.OnClickListener,
ViewGroup.OnHierarchyChangeListener,
View.OnTouchListener,
Runnable,
Handler.Callback,
DialogInterface.OnClickListener {

	private Activity activity;

	private Main main;

	private ViewGroup ViewGroup;

	//图像
	private static Map<String,View> ViewManager;

	private static boolean tag = false;

	//调用
	public static void init(Application app) {
		app.registerActivityLifecycleCallbacks(new AllView());
		AllView.setViewTag();
	}

	//允许对view添加标签
	public static void setViewTag() {
		tag = true;
		ViewManager = new HashMap<String,View>();
	}

	//onCreate回调
	@Override
	private static final int getView = 0xFFFF0001;
	private static final int getImage = 0xFFFF0002;
	private static final int getImage2 = 0xFFFF0003;
	private static final int getImage2DiaEnv = 0xFFFF0004;
	public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
		try {
			this.activity = activity;
			main = new Main("/Main.log");
			main.setConfig("AddView");
			ViewGroup = activity.findViewById(android.R.id.content);
			ViewGroup.setOnHierarchyChangeListener(this);
			//获取窗口管理器
			WindowManager Service = (WindowManager) activity.getSystemService("window");
			this.Service = Service;
			//创建父布局
			WindowManager.LayoutParams Params = new WindowManager.LayoutParams();
			this.Params = Params;
			//高度
			Params.height = WindowManager.LayoutParams.WRAP_CONTENT;
			//宽度
			Params.width = WindowManager.LayoutParams.WRAP_CONTENT;
			//类型
			Params.type = 2;
			//焦点
			Params.flags = 8;
			//像素格式
			Params.format = 1;
			//方向
			Params.gravity = Gravity.LEFT;

			//框架
			LinearLayout Linear = new LinearLayout(activity);
			Linear.setOrientation(LinearLayout.VERTICAL);
			
			//遍历按钮
			Button button = new Button(activity);
			button.setText("getView");
			button.setId(getView);
			button.setOnClickListener(this);
			button.setOnTouchListener(this);

			//遍历图像
			Button button2 = new Button(activity);
			button2.setText("getImage");
			button2.setId(getImage);
			button2.setOnClickListener(this);
			button2.setOnTouchListener(this);

			//写出指定图像
			Button button3 = new Button(activity);
			button3.setText("getImage2");
			button3.setId(getImage2DiaEnv);
			button3.setOnClickListener(this);
			button3.setOnTouchListener(this);

			Linear.addView(button);
			Linear.addView(button2);
			Linear.addView(button3);
			Linear.setOnTouchListener(this);
			Linears = Linear;
			Service.addView(Linear, Params);
		} catch (Exception e) {
			throw new RuntimeException("AllView初始化失败：" + e.toString());
		}
	}

	//当父框架被添加布局时...
	@Override
	public void onChildViewAdded(View parent, View view) {
		try {
			addTag(view);
			String[] Stack = PrintLog.splitStack(PrintLog.getstack(0));
			main.WriteLog(Stack[0],
						  Stack[1],
						  "AddView",
						  "Parent：" + parent + "\n"
						  + "ParentID：" + Integer.toHexString(parent.getId()) + "\n"
						  + "ID：" + Integer.toHexString(view.getId()) + "\n"
						  + "Value：" + view + "\n"
						  + (tag ? "⭐️Tag⭐️：" + view.getContentDescription() : "")
						  + "\n——————【Stack】——————\n"
						  + PrintLog.getstack());
			//判断是否是框架
			if (view instanceof ViewGroup) {
				((ViewGroup)view).setOnHierarchyChangeListener(this);
				traverseAddView((ViewGroup)view, view.toString());
			}
			//判断是否是图像
			//if (view instanceof ImageView) {
			ViewManager.put(view.getContentDescription().toString(), view);
			//}
		} catch (Exception e) {
			throw new RuntimeException("AllView异常：" + e.toString());
		}
	}

	//移除布局时...
	@Override
	public void onChildViewRemoved(View parent, View child) {

	}

	//递归追加视图
	private void traverseAddView(ViewGroup viewg, String Parent) throws IOException {
		for (int i = 0; i < viewg.getChildCount(); i++) {
			//获取控件
			View view = viewg.getChildAt(i);
			addTag(view);
			//判断是否为子视图
			if (view instanceof ViewGroup) {
				((ViewGroup)view).setOnHierarchyChangeListener(this);
				traverseAddView((ViewGroup)view, view.toString());
			} 
			//判断是否为图像
			//if (view instanceof ImageView) {
			ViewManager.put(view.getContentDescription().toString(), view);
			//}
			String[] Stack = PrintLog.splitStack(PrintLog.getstack(0));
			main.WriteLog(Stack[0],
						  Stack[1],
						  "AddView",
						  "Parent：" + Parent + "\n"
						  + "ParentID：" + Integer.toHexString(viewg.getId()) + "\n"
						  + "ID：" + Integer.toHexString(view.getId()) + "\n"
						  + "Value：" + view + "\n"
						  + (tag ? "⭐️Tag⭐️：" + view.getContentDescription() : "")
						  + "\n——————【Stack】——————\n"
						  + PrintLog.getstack());
		}
	}

	//追加标记
	private void addTag(View v) {
		if (tag) {
			Random random = new Random();
			char[] Base = "doubihuaji".toCharArray();
			for (int i = 0; Base.length > i; i++) {
				Base[i] = (char) (Base[i] ^ random.nextInt(13000));
			}
			String label = "【" + new String(Base) + "】";
			//v.setTag();
			CharSequence Tag = v.getContentDescription();
			//如果等于null或者为0则标记
			if (Tag == null || Tag.length() == 0) {
				v.setContentDescription(label);
			} else {
				String TagStr = Tag.toString();
				if (!TagStr.startsWith("【") || !TagStr.endsWith("】")) {
					v.setContentDescription(label);
				}
			}
		}
	}

	//窗口按钮拖动监听
	int startX = 0;
	int startY = 0;
	int downx = 0;
	int downy = 0;
	private WindowManager Service;
	private WindowManager.LayoutParams Params;
	private LinearLayout Linears;
	public boolean onTouch(View view, MotionEvent motionEvent) {
		switch (motionEvent.getAction()) {
			case MotionEvent.ACTION_DOWN:
				//当前x
				startX = (int) motionEvent.getRawX();
				//当前y
				startY = (int) motionEvent.getRawY();
				downx = startX;
				downy = startY;
				return false;
			case MotionEvent.ACTION_UP:
				int rawX = (int) motionEvent.getRawX();
				int rawY = (int) motionEvent.getRawY();
				if (Math.abs(rawX - downx) >= 10 || Math.abs(rawY - downy) >= 10) {
					return false;
				}
				//onclick();
				return false;
			case MotionEvent.ACTION_MOVE:
				int rawX2 = (int) motionEvent.getRawX();
				int rawY2 = (int) motionEvent.getRawY();
				int i = rawX2 - startX;
				int i2 = rawY2 - startY;
				Params.x += i;
				Params.y += i2;
				startX = rawX2;
				startY = rawY2;
				Service.updateViewLayout(Linears, Params);
				return false;
			default:
				return false;
		}
	}

	//启动遍历当前页面
	@Override
	private int codeEvent;
	private EditText DiaEdit;
	public void onClick(View v) {
		codeEvent = v.getId();
		//如果是指定图像获取则创建弹窗
		if (codeEvent == getImage2DiaEnv) {
			DiaEdit = new EditText(activity);
			DiaEdit.setHint("特殊标签请包含【】输入️");
			AlertDialog.Builder dialog = new AlertDialog.Builder(activity);
			dialog.setIcon(activity.getApplication().getApplicationInfo().icon)
				.setTitle("获取指定图像")
				.setMessage("请输入该视图⭐️标签")
				.setView(DiaEdit)
				.setPositiveButton("确认", this)
				.show();
			return;
		}
		new Thread(this).start();
	}

	//指定图像对话框点击事件
	@Override
	public void onClick(DialogInterface dialog, int which) {
		codeEvent = getImage2;
		new Thread(this).start();
	}

	//窗口三按钮事件
	@Override
	public void run() {
		Looper.prepare();
		try {
			Handler handler = new Handler(Looper.getMainLooper(), this);
			Message message = handler.obtainMessage();
			message.what = ToastMessage;

			switch (codeEvent) {
				case getView:
					Main main = new Main("/" + activity.getClass().getSimpleName() + "-View.log");
					main.setConfig("ActivityView");
					traverseView(main, ViewGroup, "Null");
					message.obj = "获取成功";
					break;
				case getImage:
					Main main2 = new Main("/Image/#init.log");
					main2.setConfig("ImageView");
					traverseImage(main2, ViewGroup);
					message.obj = "获取成功";
					break;
				case getImage2:
					Main main3 = new Main("/Image/#init.log");
					main3.setConfig("ImageView");

					String str = DiaEdit.getText().toString();
					if (!str.contains("【") || !str.contains("】")) {
						//Toast.makeText(activity, "标签格式错误", 1).show();
						message.obj = "标签格式错误";
						break;
					}

					str = str.substring(str.indexOf("【"), str.lastIndexOf("】") + 1);
					View image = ViewManager.get(str);
					if (image == null) {
						//Toast.makeText(activity, str + "：该标签无图像", 1).show();
						message.obj = str + "：该标签无图像";
						break;
					}

					int count = 0;
					//判断是否是父视图，如果是则递归到有imageview为止
					if (image instanceof ImageView) {
						Image(str, (ImageView)image);
						count++;
					} else {
						count = traverseViewImageView(main3, (ViewGroup)image, str, count);
					}

					//String m;
					if (count == 0) {
						message.obj = "获取失败";
						//Toast.makeText(activity, "获取失败", 1).show();
					} else {
						message.obj = "获取成功";
						//Toast.makeText(activity, "获取成功", 1).show();
					}
					imagecount = 0;
					break;
			}

			handler.sendMessage(message);
			//Toast.makeText(v.getContext(), "获取成功", 1).show();
		} catch (Exception e) {
			throw new RuntimeException("AllView输出流异常：" + e.toString());
		}
	}

	//线程消息处理
	@Override
	private static final int ToastMessage = 0xFF000001;
	public boolean handleMessage(Message msg) {
		switch (msg.what) {
			case ToastMessage:
				String ToastMessageStr = (String) msg.obj;
				Toast.makeText(activity, ToastMessageStr, 1).show();
				break;
		}
		return false;
	}


	//递归遍历图像视图
	private int imagecount;
	private int traverseViewImageView(Main main, ViewGroup viewgroup, String filename, int count) throws Exception {
		for (int i = 0; i < viewgroup.getChildCount(); i++) {
			View view = viewgroup.getChildAt(i);
			//判断框架
			if (view instanceof ViewGroup) {
				traverseViewImageView(main, (ViewGroup)view, filename, imagecount);
			} else {
				//判断视图
				if (view instanceof ImageView) {
					if (Image(count + "_" + filename, (ImageView)view)) {
						imagecount = imagecount + 1;
					}
				}
			}
		}
		return imagecount;
	}

	//解析image
	private boolean Image(String str, ImageView image) throws Exception {
		Drawable Draw = image.getDrawable();
		if (Draw == null) {
			//Toast.makeText(activity, "图像视图无Drawable", 1).show();
			return false;
		}
		Bitmap bit = drawToBit(Draw);
		Main main = new Main("/Image/#init.log");
		main.setConfig("ImageView");

		String filename = str + ".png";
		//写入文件
		FileOutputStream output = main.Write(filename, new byte[0]);
		bit.compress(Bitmap.CompressFormat.PNG, 100, output);
		output.flush();
		//写入日志
		main.WriteLog(
			"ImageName：" + filename + "\n"
			+ "ID：" + Integer.toHexString(image.getId()) + "\n"
			+ "Value：" + image + "\n"
			+ "ClickEvent：" + getViewEvent(image, "mOnClickListener") + "\n"
			+ "LongClickEvent：" + getViewEvent(image, "mOnLongClickListener")
		).flush();
		return true;
	}


	//一键扒涩图
	private void traverseImage(Main main, ViewGroup viewgroup) throws Exception {
		for (int i = 0; i < viewgroup.getChildCount(); i++) {
			//获取控件
			View view = viewgroup.getChildAt(i);
			if (view instanceof ViewGroup) {
				traverseImage(main, (ViewGroup)view);
			} else {
				//如果是image则获取
				if (view instanceof ImageView) {
					ImageView image = (ImageView) view;
					Drawable draw = image.getDrawable();
					//不是null则获取
					if (draw != null) {
						Bitmap bit = drawToBit(draw);
						CharSequence context = image.getContentDescription();
						String filename = "1.png";
						if (context != null) {
							filename = context.toString();
							if (filename.length() == 0) {
								Random ran = new Random();
								filename = "Null" + ran.nextInt(100000) + ".png";
							} else {
								filename += ".png";
							}
						}
						//写入文件
						FileOutputStream output = main.Write(filename, new byte[0]);
						bit.compress(Bitmap.CompressFormat.PNG, 100, output);
						output.flush();
						//写入日志
						main.WriteLog(
							"ImageName：" + filename + "\n"
							+ "ID：" + Integer.toHexString(image.getId()) + "\n"
							+ "Value：" + image + "\n"
							+ "ClickEvent：" + getViewEvent(view, "mOnClickListener") + "\n"
							+ "LongClickEvent：" + getViewEvent(view, "mOnLongClickListener")
						).flush();
					}
				}
			}
		}
	}

	private Bitmap drawToBit(Drawable drawable) {
		Bitmap bitmap;
		if (drawable instanceof BitmapDrawable) {
			bitmap = ((BitmapDrawable) drawable).getBitmap();
		} else {
			if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
				bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
			} else {
				bitmap = Bitmap.createBitmap(
					drawable.getIntrinsicWidth(),
					drawable.getIntrinsicHeight(),
					Bitmap.Config.ARGB_8888);
			}
			Canvas canvas = new Canvas(bitmap);
			drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
			drawable.draw(canvas);
		}
		return bitmap;
	}

	//递归遍历view
	private void traverseView(Main main, ViewGroup viewgroup, String Parent) throws Exception {
		for (int i = 0; i < viewgroup.getChildCount(); i++) {
			StringBuffer sb = new StringBuffer();
			//获取控件
			View view = viewgroup.getChildAt(i);
			Object value = view;
			String type = view.getClass().getName();

			//判断控件是否是安卓类
			if (!type.startsWith("android.widget.")
				&& !type.startsWith("android.view.")) {
				//如果不是则获取最终父类
				Class<?> c = view.getClass().getSuperclass();
				//判断是否存在父类
				if (c != null) {
					while (true) {
						String name = c.getName();
						if (name.startsWith("android.widget.")
							|| name.startsWith("android.view.")) {
							type = name;
							break;
						} else {
							c = c.getSuperclass();
						}
					}
				}
			}



			sb.append("ViewClass：")
				.append(activity.getClass().getName())
				.append("\n")

				.append("Parent：")
				.append(Parent)
				.append("\n")

				.append("ParentID：")
				.append(Integer.toHexString(viewgroup.getId()))
				.append("\n")

				.append("TYPE：")
				.append(type)
				.append("\n")

				.append("Value：")
				.append(value)
				.append("\n")

				.append("ID：")
				.append(view.getId() == -1 ? -1 : Integer.toHexString(view.getId()))
				.append("\n")

				.append("️Tag️：")
				.append(view.getTag())
				.append("\n")

				.append("⭐️Tag⭐️️：")
				.append(view.getContentDescription())
				.append("\n")

				.append("isEnabled：")
				.append(view.isEnabled())
				.append("\n")

				.append("Visibility：")
				.append(view.getVisibility())
				.append("\n")

				.append("isClickable：")
				.append(view.isClickable())
				.append("\n")

				.append("ClickEvent：")
				.append(getViewEvent(view, "mOnClickListener"))
				.append("\n")

				.append("isLongClickable：")
				.append(view.isLongClickable())
				.append("\n")

				.append("LongClickEvent：")
				.append(getViewEvent(view, "mOnLongClickListener"))
				.append("\n")

				.append("isFocusable：")
				.append(view.isFocusable())
				.append("\n")

				.append("isFocused：")
				.append(view.isFocused())
				.append("\n")

				.append("Focusable：")
				.append(view.getFocusable())
				.append("");

			//如果此控件是子视图则递归
			if (view instanceof ViewGroup) {
				main.WriteLog(sb.toString()).flush();
				traverseView(main, (ViewGroup)view, view.toString());
			} else {
				switch (type) {
					case "android.widget.TextView":
						TextView view1 = (TextView) view;
						sb.append("\nText：")
							.append(view1.getText())
							.append("\n")

							.append("TextColor：")
							.append(view1.getTextColors())
							.append("\n")

							.append("TextChangedListener：")
							.append(getTextListeners(view1));
						main.WriteLog(sb.toString()).flush();
						continue;
					case "android.widget.Button":
						Button view2 = (Button) view;
						sb.append("\nText：")
							.append(view2.getText())
							.append("\n")

							.append("TextColor：")
							.append(view2.getTextColors())
							.append("\n")

							.append("TextChangedListener：")
							.append(getTextListeners(view2));
						main.WriteLog(sb.toString()).flush();
						continue;
					case "android.widget.EditText":
						EditText view3 = (EditText) view;
						sb.append("\nText：")
							.append(view3.getText())
							.append("\n")

							.append("TextHint：")
							.append(view3.getHint())
							.append("\n")

							.append("TextColor：")
							.append(view3.getTextColors())
							.append("\n")

							.append("TextChangedListener：")
							.append(getTextListeners(view3));
						main.WriteLog(sb.toString()).flush();
						continue;
				}

				//其它
				main.WriteLog(sb.toString()).flush();
			}
		}
	}

	//获取文本监听器
	private Object getTextListeners(Object In) throws Exception {
		//获取textview类
		Class<?> C_TextView = Class.forName("android.widget.TextView");
		//获取mListeners字段
		Field F_mListeners = C_TextView.getDeclaredField("mListeners");
		//设置访问权限
		F_mListeners.setAccessible(true);
		return F_mListeners.get(In);
	}

	//获取控件视图
	private Object getViewEvent(View view, String Event) throws Exception {
		//获取View类
		Class<?> C_View = Class.forName("android.view.View");
		//获取getListenerInfo方法
		Method M_getListenerInfo =  C_View.getDeclaredMethod("getListenerInfo");
		//设置访问权限
		M_getListenerInfo.setAccessible(true);
		//获取ListenerInfo实例
		Object ListenerInfo = M_getListenerInfo.invoke(view);
		//获取View$ListenerInfo类
		Class<?> C_View$ListenerInfo = ListenerInfo.getClass();
		//获取mOnClickListener字段
		Field F_mOnClickListener = C_View$ListenerInfo.getDeclaredField(Event);
		//设置访问权限
		F_mOnClickListener.setAccessible(true);
		//获取视图点击事件
		return F_mOnClickListener.get(ListenerInfo);
	}


	//看我干嘛
	@Override
	public void onActivityDestroyed(Activity activity) {
	}

	@Override
	public void onActivityPaused(Activity activity) {
	}

	@Override
	public void onActivityResumed(Activity activity) {
		this.activity = activity;
		//ResumedView(ViewGroup);
	}



	@Override
	public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
	}

	@Override
	public void onActivityStarted(Activity activity) {
	}

	@Override
	public void onActivityStopped(Activity activity) {
	}

}
