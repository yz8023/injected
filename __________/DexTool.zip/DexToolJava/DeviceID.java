package com.doubihuaji.Tool;
import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Random;

//DeviceID
//作用：伪造Android_id 随机id
public class DeviceID implements InvocationHandler {

	private Object ICP;

	private String Android_id;

	private static HashMap<String, String> Map;

	private static char[] HEX = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

	static{
		Map = new HashMap<String,String>();
	}

	private DeviceID(Object obj, int time) {
		Android_id = initRandomId(time);
		ICP = obj;
	}

	public static String A_getString() {
		return "";
	}

	//随机由abcdef123456789组成的16位字符串
	public static String getRandomID() {
		return getRandomStr("abcdef1234567890", 16);
	}

	//随机由abcdef123456789组成的16位字符串(只获取一次，后面调用都只获取第一次的随机id)
	public static String getKeyRandomID() {
		return getKeyRandomStr("abcdef1234567890", 16);
	}

	//随机由abcdef123456789组成的16位字符串(每间一段时间才进行随机id,时间单位分钟)
	public static String getRandomID(int Time) {
		return getKeyRandomID("$KEYTIME$", Time);
	}

	//随机由abcdef123456789组成的16位字符串(可获取多个随机id，后面调用输对应键值即可取出)
	public static String getKeyRandomID(String key) {
		return getKeyRandomStr("abcdef1234567890", 16, key);
	}

	//随机由abcdef123456789组成的16位字符串(间隔时间获取id，可获取多个随机id)
	public static String getKeyRandomID(String key, int Time) {
		return getKeyRandomStr("abcdef1234567890", 16, key, Time);
	}

	//随机自定义字符和长度字符串(只获取一次，后面调用都只获取第一次的随机id)
	public static String getKeyRandomStr(String str, int length) {
		return getKeyRandomStr(str, length, "$RandomAndroid_id$");
	}

	//随机自定义字符和长度字符串(同上，但多了时间间隔随机id)
	public static String getKeyRandomStr(String str, int length, int Time) {
		return getKeyRandomStr(str, length, "$DIYKEYTIME$", Time);
	}

	//获取对应键值随机字符串(同上，但能随机多个id)
	public static String getKeyRandomStr(String str, int length, String key) {
		String id = Map.get(key);
		if (id != null) {
			return id;
		}
		id = getRandomStr(str, length);
		Map.put(key, id);
		return id;
	}

	//随机自定义字符和长度字符串(可随机多个id以及间隔一段时间随机id)
	public static String getKeyRandomStr(String str, int length, String key, int Time) {
		String id = getRandomStr(str, length);
		SharedPreferences sp = Main.getContext().getSharedPreferences("DeviceID", 0);
		SharedPreferences.Editor spe = sp.edit();
		String $RandomID$ = "$KeyRandomID$" + key;
		String $RandomIDTime$ = "$KeyRandomIDTime$" + key;
		if (sp.getString($RandomID$, null) == null) {
			spe.putString($RandomID$, id)
				.putLong($RandomIDTime$, System.currentTimeMillis())
				.commit();
			return id;
		}
		long time = System.currentTimeMillis();
		long time2 = sp.getLong($RandomIDTime$, 0);
		if ((time - time2) < (long) (Time * 60 * 1000)) {
			return sp.getString($RandomID$, id);
		}
		spe.putString($RandomID$, id)
			.putLong($RandomIDTime$, System.currentTimeMillis())
			.commit();
		return id;
	}

	//随机指定特征字符和长度的字符串
	//str = 随机的特征字符串
	//length = 长度
	public static String getRandomStr(String str, int length) {
		StringBuffer sb = new StringBuffer();
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			sb.append(str.charAt(random.nextInt(str.length())));
		}
		return sb.toString();
	}

	//转uuid
	public static String toUUID(String str) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(str.getBytes());
			byte[] byt = md.digest();
			int l = byt.length;
			char[] out = new char[l << 1];
			for (int i = 0, j = 0; i < l; i++) {
				out[j++] = HEX[(0xF0 & byt[i]) >>> 4];
				out[j++] = HEX[0x0F & byt[i]];
			}
			String Uid = new String(out);

			//拼装uuid
			StringBuffer uuid = new StringBuffer();
			uuid.append(Uid.substring(0, 8))
				.append("-")
				.append(Uid.substring(8, 12))
				.append("-")
				.append(Uid.substring(12, 16))
				.append("-")
				.append(Uid.substring(16, 20))
				.append("-")
				.append(Uid.substring(20, 32));
			return uuid.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("DeviceID.toUUid转UUID失败：" + e.toString());
		}
	}

	//伪造android_id
	public static void ProxyAndroid_id() {
		ProxyAndroid_id(0);
	}

    public static void ProxyAndroid_id(int time) {
		try {
			//获取NameValueCache实例
			Class<Settings.Secure> Secure = Settings.Secure.class;
			Field dNameValueCache = Secure.getDeclaredField("sNameValueCache");
			dNameValueCache.setAccessible(true);
			Object NameValueCache = dNameValueCache.get(Secure);
			//获取ContentProviderProxy
			Class<?> cNameValueCache = NameValueCache.getClass();
			Field mProviderHolder = cNameValueCache.getDeclaredField("mProviderHolder");
			mProviderHolder.setAccessible(true);
			Object ProviderHolder = mProviderHolder.get(NameValueCache);
			Class<?> cProviderHolder = ProviderHolder.getClass();
			ContentResolver ContentResolver = Main.getContext().getContentResolver();
			Class<?> cContentResolver = Class.forName("android.content.ContentResolver");
			Method acquireProvider = cContentResolver.getDeclaredMethod("acquireProvider", new Class[]{String.class});
			acquireProvider.setAccessible(true);
			Object ICP = acquireProvider.invoke(ContentResolver, "settings");
			//代理mContentProvider
			Class cIContentProvider = Class.forName("android.content.IContentProvider");
			Object proxy = Proxy.newProxyInstance(cIContentProvider.getClassLoader(), new Class[]{cIContentProvider}, new DeviceID(ICP, time));
			Field mContentProvider = cProviderHolder.getDeclaredField("mContentProvider");
			mContentProvider.setAccessible(true);
			mContentProvider.set(ProviderHolder, proxy);
		} catch (Exception e) {
			throw new RuntimeException("DeviceID反射代理失败了：" + e.toString());
		}
	}

	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		Object object = method.invoke(ICP, args);
		if (method.getName().equals("call")) {
			Bundle bundle = (Bundle) object;
			String id = bundle.getString("value");
			if (id != null && id.length() == 16) {
				bundle.putString("value", Android_id);
			}
			return bundle;
		}
		return object;
	}

	//初始化id
	private String initRandomId(int Times) {
		String randomid = getRandomStr("abcdef1234567890", 16);
		if (Times == 0) {
			return randomid;
		}
		SharedPreferences sp = Main.getContext().getSharedPreferences("DeviceID", 0);
		SharedPreferences.Editor spe = sp.edit();
		if (sp.getString("$Android_id$", null) == null) {
			spe.putString("$Android_id$", randomid)
				.putLong("$Time$", System.currentTimeMillis())
				.commit();
			return randomid;
		}
		long time = System.currentTimeMillis();
		long time2 = sp.getLong("$Time$", 0);
		if ((time - time2) < (long) (Times * 60 * 1000)) {
			return sp.getString("$Android_id$", randomid);
		}
		spe.putString("$Android_id$", randomid)
			.putLong("$Time$", System.currentTimeMillis())
			.commit();
		return randomid;
	}

}
