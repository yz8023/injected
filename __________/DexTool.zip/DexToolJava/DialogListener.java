package com.doubihuaji.Tool;
import android.app.Activity;
import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

//DialogListener
//作用：监听吐司弹窗，Dialog弹窗
public class DialogListener extends ArrayList 
implements InvocationHandler,
Application.ActivityLifecycleCallbacks,
Runnable {

	//toast管理
	private Object INotificationManager;

	//日志
	private Main main;

	//弹窗令牌黑名单
	private static List<String> TokenBlacklist;

	//实例
	private Activity activity;

	//窗口服务
	private WindowManager Window;

	//窗口视图
	private View DialogView;

	static{
		TokenBlacklist = new ArrayList<String>();
		$Blacklist$();
	}

	public DialogListener() {}

	//Toast监听
	private DialogListener(Object INManager) throws IOException {
		INotificationManager = INManager;
		this.main = new Main("Main.log");
		this.main.setConfig("ToastListener");
	}

	//Dialog监听
	private DialogListener(Activity activity, ArrayList Array) throws IOException {
		super(Array);
		this.activity = activity;
		this.main = new Main("Main.log");
		this.main.setConfig("DialogListener");
	}

	//删除弹窗视图
	private DialogListener(WindowManager Window, View DialogView) {
		this.Window = Window;
		this.DialogView = DialogView;
	}

	//黑名单
	private static void $Blacklist$() {
		List<String> black = TokenBlacklist;
		black.add("");
		black.add("");
		black.add("");
		black.add("");
		black.add("");
	}

	//调用
	public static void init(Application App) {
		ToastListener(App.getApplicationInfo());
		App.registerActivityLifecycleCallbacks(new DialogListener());
	}

	//吐司监听器
	private static void ToastListener(ApplicationInfo AppInfo) {
		try {
			//判断sdk版本，因为字段灰名单版本的限制，只能在sdk < 28的情况使用
			if (AppInfo.targetSdkVersion > 28) {
				return;
			}
			//获取toast类
			Class<?> C_Toast = Toast.class;

			//从toast获取getService方法
			Method M_getService = C_Toast.getDeclaredMethod("getService");
			//设置可访问
			M_getService.setAccessible(true);
			//获取INotificationManager实例
			Object INManager = M_getService.invoke(null);

			//获取sService字段
			Field F_sService = C_Toast.getDeclaredField("sService");
			//设置访问权限
			F_sService.setAccessible(true);
			//设置代理
			Class<?> C_Service = INManager.getClass();
			F_sService.set(null, Proxy.newProxyInstance(C_Service.getClassLoader(), 
														C_Service.getInterfaces(), 
														new DialogListener(INManager)));
		} catch (Exception e) {
			throw new RuntimeException("ToastListener初始化失败：" + e.toString());
		}
	}

	@Override
	public Object invoke(Object object, Method method, Object[] object1) throws Throwable {
		String Stack = PrintLog.getstack().split("\n", 3)[2];
		String[] StackArray = Stack.split("\n");
		//判断是否为show方法调用
		if (StackArray[0].startsWith("android.widget.Toast->show")) {
			String[] Path = PrintLog.splitStack(StackArray[1]);
			StringBuffer Text = new StringBuffer();
			//仅文字
			if (method.getName().equals("enqueueTextToast")) {
				Text.append("mText：")
					.append(object1[2]);
			}

			//View视图
			if (method.getName().equals("enqueueToast")) {
				//Toast$TN实例
				Object Toast$TN = object1[2];
				//获取Toast$TN类
				Class<?> C_Toast$TN = Class.forName("android.widget.Toast$TN");
				//获取mNextView字段
				Field F_mNextView = C_Toast$TN.getDeclaredField("mNextView");
				//设置访问权限
				F_mNextView.setAccessible(true);
				//获取WeakReference实例
				View NextView = (View) F_mNextView.get(Toast$TN);
				//获取弹窗视图
				View mView = NextView;
				//View mView = (View) NextView.get();

				//判断是否为框架
				if (mView instanceof ViewGroup) {
					//是则遍历视图
					Text = TraverseView(Text, (ViewGroup)mView);
					Text.delete(Text.length() - 1, Text.length());
				} else {
					//否则判断控件是否为textview
					if (mView instanceof TextView) {
						//是则解析文字
						Text.append("mText：")
							.append(((TextView)mView).getText());
					} else {
						//否则返回Null
						Text.append("mText：Null");
					}
				}
			}

			//调用堆栈令牌
			StringBuffer TokenStack = new StringBuffer();
			for (String tokenstack : Stack.split("\n")) {
				//com.xxx.xxx->xxx
				TokenStack.append(tokenstack.split("\\(")[0]);
			}
			int token = TokenStack.toString().hashCode();


			//如果是黑名单吐司，则拦截方法
			if (TokenBlacklist.contains(String.valueOf(token))) {
				return false;
			}

			//判断是否关闭日志
			if (!TokenBlacklist.contains("Close")) {
				main.WriteLog(
					Path[0],
					Path[1],
					"ToastListener",
					"Token：" + token + "\n"
					+ Text.toString()
					+ "\n——————【Stack】——————\n"
					+ Stack);
			}
		}
		return method.invoke(INotificationManager, object1);
	}

	private StringBuffer TraverseView(StringBuffer Text, ViewGroup View) {
		for (int i = 0; i < View.getChildCount(); i++) {
			//获取控件
			View view = View.getChildAt(i);
			//判断是否为框架
			if (view instanceof ViewGroup) {
				//是则递归
				TraverseView(Text, (ViewGroup)view);
				continue;
			}
			//判断控件是否为TexTview
			if (view instanceof TextView) {
				//是则获取文字
				TextView textview = (TextView) view;
				//如果文本内容为空则不获取
				if (textview.getText().length() == 0) {
					continue;
				}
				Text.append("mText：")
					.append(textview.getText())
					.append("\n");
				continue;
			}
		}
		return Text;
	}

	@Override
	public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
		//Dialog监听
		ProxyWindow(activity);
	}

	private void ProxyWindow(Activity activity) {
		try {
			//获取窗口服务
			Object Windows = activity.getSystemService("window");
			//获取WindowManagerImpl
			Class<?> C_WindowManagerImpl = Class.forName("android.view.WindowManagerImpl");
			//获取mGlobal字段
			Field F_mGlobal = C_WindowManagerImpl.getDeclaredField("mGlobal");
			//设置访问权限
			F_mGlobal.setAccessible(true);
			//获取Global实例
			Object WMGlobal = F_mGlobal.get(Windows);

			//获取WindowManagerGlobal类
			Class<?> C_WindowManagerGlobal = Class.forName("android.view.WindowManagerGlobal");
			//获取mViews字段
			Field F_mViews = C_WindowManagerGlobal.getDeclaredField("mViews");
			//设置访问权限
			F_mViews.setAccessible(true);
			//获取arraylist实例
			ArrayList Views = (ArrayList) F_mViews.get(WMGlobal);

			//创建代理类
			ArrayList Proxy = new DialogListener(activity, Views);
			//将mViews字段设为代理类
			F_mViews.set(WMGlobal, Proxy);
		} catch (Exception e) {
			throw new RuntimeException("DialogListener初始化异常：" + e.toString());
		}
	}

	//视图集合
	@Override
	public boolean add(Object e) {
		dialogListener((View)e);
		return super.add(e);
	}

	private void dialogListener(View v) {
		//如果是Dialog->show的调用则捕获
		String Stack = PrintLog.getstack();
		if (Stack.contains("android.app.Dialog->show")) {
			try {
				//获取弹窗调用位置
				Stack = Stack.substring(Stack.indexOf("android.app.Dialog->show"));

				int Pathindex = 1;
				//判断弹窗类型
				if (Stack.contains("android.app.AlertDialog$Builder->show")) {
					//如果是使用AlertDialog$Builder创建的弹窗则路径索引+1
					Pathindex = Pathindex + 1;
				}

				//获取弹窗文字
				StringBuffer Text = new StringBuffer();
				Text = TraverseView(Text, (ViewGroup)v);
				if (Text.length() > 2) {
					Text.delete(Text.length() - 1, Text.length());
				}else{
					Text.append("mText：Null");
				}
				//调用堆栈令牌
				StringBuffer TokenStack = new StringBuffer();
				for (String tokenstack : Stack.split("\n")) {
					//com.xxx.xxx->xxx
					TokenStack.append(tokenstack.split("\\(")[0]);
				}
				int token = TokenStack.toString().hashCode();


				//如果是黑名单对话框，则kill
				if (TokenBlacklist.contains(String.valueOf(token))) {
					//获取窗口服务
					WindowManager Window = (WindowManager) activity.getSystemService("window");
					//子线程里循环杀死(因为追加弹窗视图在设置弹窗视图显示到页面活动的前面)
					new Thread(new DialogListener(Window, v)).start();
					return;
				}

				//关闭
				if (TokenBlacklist.contains("Close")) {
					return;
				}

				//
				String[] PPath = Stack.split("\n");
				String[] path = PrintLog.splitStack(PPath[Pathindex]);
				main.WriteLog(
					path[0],
					path[1],
					"DialogListener",
					"Token：" + token + "\n"
					+ Text.toString()
					+ "\n——————【Stack】——————\n"
					+ Stack
				);
			} catch (Exception e) {
				throw new RuntimeException("DialogListener输出流异常：" + e.toString());
			}
		}
	}

	//线程删除弹窗视图
	public void run() {
		//死循环检查是否添加到视图
		while (!DialogView.isAttachedToWindow()) {}
		//移除
		Window.removeViewImmediate(DialogView);
	}

	@Override
	public void onActivityDestroyed(Activity activity) {
	}

	@Override
	public void onActivityPaused(Activity activity) {
	}

	@Override
	public void onActivityResumed(Activity activity) {
	}

	@Override
	public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
	}

	@Override
	public void onActivityStarted(Activity activity) {
	}

	@Override
	public void onActivityStopped(Activity activity) {
	}

	//废弃方案
	//对话框监听器
//	private void DialogListener(String ServiceName) {
//		//判断是否为获取窗口服务
//		if (ServiceName.equals("window")) {
//			//判断此次调用是否为实例化Dialog时所调用的
//			if () {
//				try {
//					//获取堆栈
//					String stack = PrintLog.getstack().split("\n", 2)[1];
//					String ClassName = null;
//					String Mothod = null;
//					//获取实例化dialog具体位置
//					for (String Class : stack.split("\n")) {
//						//只要不是安卓包弹窗实现类则赋值
//						if (!Class.startsWith("android.app.Dialog->")
//							&& !Class.startsWith("android.app.AlertDialog->")
//							&& !Class.startsWith("android.app.AlertDialog$Builder->")
//							&& !Class.startsWith("android.app.SearchDialog->")
//							&& !Class.startsWith("android.app.Presentation->")
//							&& !Class.startsWith("android.text.method.CharacterPickerDialog->")
//							&& !Class.startsWith("com.android.internal.globalactions.ActionsDialog->")) {
//							String[] arr = PrintLog.splitStack(Class);
//							ClassName = arr[0];
//							Mothod = arr[1];
//							break;
//						}
//					}
//					main.WriteLog(ClassName, Mothod, "DialogListener", stack).flush();
//				} catch (IOException e) {
//					throw new RuntimeException("NewDialogListener.DialogListener输出流异常：" + e.toString());
//				}
//			}
//		}
//	}

}
