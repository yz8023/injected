package com.doubihuaji.Tool;

import android.app.Application;
import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

	private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss.SSS");
	
	private StringBuffer str;

	//日志文件路径
	private String FilePath;

	//日志文件夹路径
	private String FileDirectoryPath;

	//输出流
	private FileOutputStream Output;

	//创建日志文件
	public Main(String LogFileName) throws IOException {
		this(LogFileName, false);
	}

	public Main(String LogFileName, boolean NoContext) throws IOException {
		if (!LogFileName.startsWith("/")) {
			LogFileName = "/" + LogFileName;
		}
		//如果不采用context方式获取路径
		if (NoContext) {
			//则从/proc/self/cmdline获取当前包名
			FileInputStream Input = new FileInputStream("/proc/self/cmdline");
			byte[] b = new byte[1024];
			Input.read(b);
			String PackName = new String(b).split("\\x00")[0];

			String Path = "/storage/emulated/0/Android/data/"
				+ PackName
				+ "/files";
			new File(Path).mkdir();
			FilePath = Path + LogFileName;
			Input.close();
		} else {
			Application application = (Application) getContext();
			//如果是多层路径，则改变逻辑
			String Path = "";
			if (LogFileName.split("/").length > 1) {
				int end = LogFileName.lastIndexOf("/");
				int length = LogFileName.length();
				Path = LogFileName.substring(0, end);
				FileDirectoryPath = application.getExternalFilesDir(Path).getPath();
				String FileName = LogFileName.substring(end, length);
				LogFileName = FileName;
			}

			File files = application.getExternalFilesDir(Path);
			FilePath = files.getPath() + LogFileName;
		}
		Output = new FileOutputStream(FilePath, true);
		str = new StringBuffer();
		//setNewWrite(true);
	}



	//每次写入文件都重新实例化输出流
	//这么做的目的是即使用户删除文件，也不会影响输出
	private boolean NewWrite;
	public void setNewWrite(boolean z) {
		NewWrite = z;
	}

	//初始化配置
	public void setConfig() {
		setConfig("$Function$");
	}

	//初始化配置
	public void setConfig(String function) {
		str = new StringBuffer();
		str.append("$Time$ ");
		str.append("$Class$");
		str.append("\n");
		str.append("->");
		str.append("$Method$");
		str.append("(");
		str.append(function);
		str.append(")");
		str.append("\n");
		str.append("$Result$");
		str.append("\n")
			.append("————————————————————")
			.append("\n");
	}

	//写入日志
	public FileOutputStream WriteLog(String Result) throws IOException {
		return WriteLog(null, null, null, Result);
	}

	//写入日志
	public FileOutputStream WriteLog(String Class, String Method, String Function, String Result) throws IOException {
		if (NewWrite) {
			Output = new FileOutputStream(FilePath, true);
		}
		long time = System.currentTimeMillis();
		String[] ClasName = getPrinStack();
		String st = str.toString();
		st = st.replace("$Time$", TIME_FORMAT.format(new Date(time)))
			.replace("$Class$", Class == null ? ClasName[0] : Class)
			.replace("$Method$", Method == null ? ClasName[1] : Method)
			.replace("$Function$", Function == null ? "Null" : Function)
			.replace("$Result$", Result);
		Output.write(st.getBytes());
		return Output;
	}

	public FileOutputStream Write(String FileName, String byt) throws IOException {
		return Write(FileName, byt.getBytes());
	}

	public FileOutputStream Write(String FileName, byte[] byt) throws IOException {
		if (FileDirectoryPath == null) {
			throw new NullPointerException("Main初始化并不是文件夹路径");
		}
		if (!FileName.startsWith("/")) {
			FileName = "/" + FileName;
		}
		FileName = FileDirectoryPath + FileName;
		FileOutputStream output = new FileOutputStream(FileName);
		output.write(byt);

		return output;
	}

	//获取打印位置
	private static String[] getPrinStack() {
		String[] Str = new String[2];
		for (StackTraceElement stack : new Throwable().getStackTrace()) {
			String clas = stack.getClassName();
			if (!clas.startsWith("com.doubihuaji.Tool.")) {
				Str[0] = clas;
				Str[1] = stack.getMethodName();
				break;
			}
		}
		return Str;
	}

	//获取application参数
	private static Context context;
	static Context getContext() {
		if (context == null) {
			try {
				Class<?> ActivityThread = Class.forName("android.app.ActivityThread");
				Object currentApplication = ActivityThread.getMethod("currentActivityThread").invoke(null);
				context = (Context) ActivityThread.getMethod("getApplication").invoke(currentApplication);
			} catch (Exception e) {
				throw new NullPointerException("无法获取context参数");
			}
		}
		return context;
	}

}
