package com.doubihuaji.Tool;
import android.app.Activity;
import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.UserHandle;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

//ActivityJumpListener
//作用：监听activity跳转
public class ActivityJumpListener extends Instrumentation
implements Application.ActivityLifecycleCallbacks {

	private static Main main;

	private ActivityJumpListener() {}

	private ActivityJumpListener(Instrumentation instrumentation, String[] FieldArray) throws Exception {
		//初始化
		Class<?> C_Instrumentation = Class.forName("android.app.Instrumentation");
		//获取Instrumentation对象核心字段值
		Object[] value = new Object[6];
		for (int i = 0; i < FieldArray.length; i++) {
			String FieldName = FieldArray[i];
			Field F_obj = C_Instrumentation.getDeclaredField(FieldName);
			F_obj.setAccessible(true);
			value[i] = F_obj.get(instrumentation);
		}
		//实例化自己的同时，将核心值填入给自己
		for (Method method : C_Instrumentation.getDeclaredMethods()) {
			if (method.getName().equals("init")) {
				method.setAccessible(true);
				method.invoke(this, value);
				main = new Main("/Main.log");
				main.setConfig("ActivityJumpListener");
				break;
			}
		}
	}

	public static void init(Application APP) {
		//判断sdk版本，因为字段灰名单版本的限制，只能在sdk < 28的情况使用
		if (APP.getApplicationInfo().targetSdkVersion > 28) {
			return;
		}
		APP.registerActivityLifecycleCallbacks(new ActivityJumpListener());
	}
	
	@Override
	//onCreate回调
	public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
		try {
			//获取Activity类
			Class<?> C_Activity = Class.forName("android.app.Activity");
			//获取Activity类mInstrumentation字段
			Field mInstrumentation = C_Activity.getDeclaredField("mInstrumentation");
			//设置访问权限
			mInstrumentation.setAccessible(true);
			//获取Instrumentation实例
			Instrumentation instrumentation = (Instrumentation) mInstrumentation.get(activity);

			//对Instrumentation初始化
			String[] FieldName = new String[]{
				"mThread",
				"mInstrContext",
				"mAppContext",
				"mComponent",
				"mWatcher",
				"mUiAutomationConnection"
			};
			//将自身代理类赋值给Activity.mInstrumentation字段
			mInstrumentation.set(activity, new ActivityJumpListener(instrumentation, FieldName));
		} catch (Exception e) {
			throw new RuntimeException("ActivityJumpListener初始化失败：" + e.toString());
		}
	}

	//劫持
	public ActivityResult execStartActivity(Context who, IBinder contextThread, IBinder token, Activity target, Intent intent, int requestCode, Bundle options) {
		try {
			int count = 0;
			String[] Stack = null;
			for (String stack : PrintLog.getstack().split("\n")) {
				Stack = PrintLog.splitStack(stack);
				if (!Stack[0].equals("android.app.Activity")) {
					break;
				}
				count++;
			}
			main.WriteLog(Stack[0],
						  Stack[1],
						  "ActivityJumpListener",
						  "who：" + who + "\n"
						  + "contextThread：" + contextThread + "\n"
						  + "token：" + token + "\n"
						  + "target：" + target + "\n"
						  + "intent：" + intent + "\n"
						  + "requestCode：" + requestCode + "\n"
						  + "options：" + options
						  + "\n——————【Stack】——————\n"
						  + PrintLog.getstack().split("\n", count)[count - 1])
				.flush();
		} catch (IOException e) {
			throw new RuntimeException("ActivityJumpListener输出流异常：" + e.toString());
		}
		return super.execStartActivity(who, contextThread, token, target, intent, requestCode, options);
	}

	@Override
	public ActivityResult execStartActivity(Context who, IBinder contextThread, IBinder token, String target, Intent intent, int requestCode, Bundle options) {
		try {
			int count = 0;
			String[] Stack = null;
			for (String stack : PrintLog.getstack().split("\n")) {
				Stack = PrintLog.splitStack(stack);
				if (!Stack[0].equals("android.app.Activity")) {
					break;
				}
				count++;
			}
			main.WriteLog(Stack[0],
						  Stack[1],
						  "ActivityJumpListener",
						  "who：" + who + "\n"
						  + "contextThread：" + contextThread + "\n"
						  + "token：" + token + "\n"
						  + "target：" + target + "\n"
						  + "intent：" + intent + "\n"
						  + "requestCode：" + requestCode + "\n"
						  + "options：" + options
						  + "\n——————【Stack】——————\n"
						  + PrintLog.getstack().split("\n", count)[count - 1])
				.flush();
		} catch (IOException e) {
			throw new RuntimeException("ActivityJumpListener输出流异常：" + e.toString());
		}
		return super.execStartActivity(who, contextThread, token, target, intent, requestCode, options);
	}

	@Override
	public ActivityResult execStartActivity(Context who, IBinder contextThread, IBinder token, String resultWho, Intent intent, int requestCode, Bundle options, UserHandle user) {
		try {
			int count = 0;
			String[] Stack = null;
			for (String stack : PrintLog.getstack().split("\n")) {
				Stack = PrintLog.splitStack(stack);
				if (!Stack[0].equals("android.app.Activity")) {
					break;
				}
				count++;
			}
			main.WriteLog(Stack[0],
						  Stack[1],
						  "ActivityJumpListener",
						  "who：" + who + "\n"
						  + "contextThread：" + contextThread + "\n"
						  + "token：" + token + "\n"
						  + "resultWho：" + resultWho + "\n"
						  + "intent：" + intent + "\n"
						  + "requestCode：" + requestCode + "\n"
						  + "options：" + options + "\n"
						  + "user：" + user
						  + "\n——————【Stack】——————\n"
						  + PrintLog.getstack().split("\n", count)[count - 1])
				.flush();
		} catch (IOException e) {
			throw new RuntimeException("ActivityJumpListener输出流异常：" + e.toString());
		}
		return super.execStartActivity(who, contextThread, token, resultWho, intent, requestCode, options, user);
	}

	@Override
	public ActivityResult execStartActivityAsCaller(Context who, IBinder contextThread, IBinder token, Activity target, Intent intent, int requestCode, Bundle options, boolean ignoreTargetSecurity, int userId) {
		try {
			int count = 0;
			String[] Stack = null;
			for (String stack : PrintLog.getstack().split("\n")) {
				Stack = PrintLog.splitStack(stack);
				if (!Stack[0].equals("android.app.Activity")) {
					break;
				}
				count++;
			}
			main.WriteLog(Stack[0],
						  Stack[1],
						  "ActivityJumpListener",
						  "who：" + who + "\n"
						  + "contextThread：" + contextThread + "\n"
						  + "token：" + token + "\n"
						  + "target：" + target + "\n"
						  + "intent：" + intent + "\n"
						  + "requestCode：" + requestCode + "\n"
						  + "options：" + options + "\n"
						  + "ignoreTargetSecurity：" + ignoreTargetSecurity + "\n"
						  + "userId：" + userId
						  + "\n——————【Stack】——————\n"
						  + PrintLog.getstack().split("\n", count)[count - 1])
				.flush();
		} catch (IOException e) {
			throw new RuntimeException("ActivityJumpListener输出流异常：" + e.toString());
		}
		return super.execStartActivityAsCaller(who, contextThread, token, target, intent, requestCode, options, ignoreTargetSecurity, userId);
	}
	
	@Override
	public void onActivityStarted(Activity activity) {
	}

	@Override
	public void onActivityDestroyed(Activity activity) {
	}

	@Override
	public void onActivityPaused(Activity activity) {
	}

	@Override
	public void onActivityResumed(Activity activity) {
	}

	@Override
	public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
	}

	@Override
	public void onActivityStopped(Activity activity) {
	}

}
