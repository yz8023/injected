package 包名;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.widget.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CloudControlDialog extends Dialog {

    private final Activity activity;
    private String cloudControlUrl;

    private boolean isMasterSwitchOn = true;
    private boolean isPasswordEnabled = false;
    private boolean isPasswordVerified = false;
    private String password = "";
    private String title = "提示";
    private String content = "加载中...";
    private String button1Text = "确定";
    private String button2Text = "关闭";

    private EditText passwordInput;
    private Button button2;
    private LinearLayout dialogContainer;
    private TextView titleView;
    private TextView contentView;
    private LinearLayout passwordLayout;

    public CloudControlDialog(Activity activity) {
        super(activity, android.R.style.Theme_Translucent_NoTitleBar);
        this.activity = activity;
        setCancelable(false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        window.setGravity(Gravity.CENTER);

        RelativeLayout rootLayout = new RelativeLayout(activity);
        rootLayout.setLayoutParams(
                new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        View backgroundView = new View(activity);
        backgroundView.setLayoutParams(
                new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backgroundView.setBackgroundColor(Color.parseColor("#E1FFFFFF"));
        rootLayout.addView(backgroundView);

        dialogContainer = new LinearLayout(activity);
        dialogContainer.setOrientation(LinearLayout.VERTICAL);
        RelativeLayout.LayoutParams containerParams =
                new RelativeLayout.LayoutParams(dpToPx(320), ViewGroup.LayoutParams.WRAP_CONTENT);
        containerParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        dialogContainer.setLayoutParams(containerParams);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dpToPx(16));
        dialogContainer.setBackground(bg);
        dialogContainer.setElevation(dpToPx(8));

        titleView = new TextView(activity);
        titleView.setText(title);
        titleView.setTextSize(26);
        titleView.setTextColor(Color.parseColor("#ff303030"));
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(0, dpToPx(20), 0, dpToPx(10));
        dialogContainer.addView(titleView);

        ScrollView scrollView = new ScrollView(activity);
        LinearLayout.LayoutParams scrollParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        scrollParams.setMargins(dpToPx(16), 0, dpToPx(16), 0);
        scrollView.setLayoutParams(scrollParams);

        contentView = new TextView(activity);
        contentView.setText(content);
        contentView.setTextSize(16);
        contentView.setTextColor(Color.parseColor("#ff303030"));
        contentView.setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10));
        scrollView.addView(contentView);
        dialogContainer.addView(scrollView);

        passwordLayout = new LinearLayout(activity);
        passwordLayout.setOrientation(LinearLayout.VERTICAL);
        passwordLayout.setPadding(dpToPx(16), dpToPx(10), dpToPx(16), dpToPx(10));
        passwordLayout.setVisibility(View.GONE);
        passwordInput = new EditText(activity);
        passwordInput.setHint("请输入");
        passwordInput.setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10));
        passwordLayout.addView(passwordInput);
        dialogContainer.addView(passwordLayout);

        LinearLayout buttonLayout = new LinearLayout(activity);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);
        buttonLayout.setPadding(dpToPx(16), dpToPx(10), dpToPx(16), dpToPx(20));

        Button button1 = new Button(activity);
        button1.setText(button1Text);
        button1.setBackgroundColor(0xff303030);
        button1.setTextColor(0xFFFFFFFF);
        button1.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(100), dpToPx(42)));
        button1.setOnClickListener(
                v -> {
                    if (isPasswordEnabled) {
                        verifyPassword();
                    } else {
                        dismissWithAnimation();
                    }
                });
        buttonLayout.addView(button1);

        button2 = new Button(activity);
        button2.setText(parseButtonText(button2Text));
        button2.setBackgroundColor(0xff303030);
        button2.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams btn2Params = new LinearLayout.LayoutParams(dpToPx(100), dpToPx(42));
        btn2Params.setMargins(dpToPx(12), 0, 0, 0);
        button2.setLayoutParams(btn2Params);
        button2.setOnClickListener(
                v -> {
                    if (button2Text.contains("#")) {
                        String url = button2Text.split("#")[1];
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(url));
                        activity.startActivity(intent); 
                    }
                    dismissWithAnimation();
                });
        buttonLayout.addView(button2);

        dialogContainer.addView(buttonLayout);
        rootLayout.addView(dialogContainer);
        setContentView(rootLayout);

        showWithAnimation();
    }

    private void showWithAnimation() {
        
        AlphaAnimation bgAnim = new AlphaAnimation(0, 1);
        bgAnim.setDuration(300);
        bgAnim.setInterpolator(new DecelerateInterpolator());
        findViewById(android.R.id.content).startAnimation(bgAnim);

        
        AnimationSet dialogAnim = new AnimationSet(true);
        
        
        ScaleAnimation scaleAnim = new ScaleAnimation(
                0.9f, 1f, 0.9f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        scaleAnim.setDuration(300);
        
        
        AlphaAnimation alphaAnim = new AlphaAnimation(0, 1);
        alphaAnim.setDuration(200);
        
        
        TranslateAnimation translateAnim = new TranslateAnimation(
                0, 0, dpToPx(20), 0);
        translateAnim.setDuration(300);
        
        dialogAnim.addAnimation(scaleAnim);
        dialogAnim.addAnimation(alphaAnim);
        dialogAnim.addAnimation(translateAnim);
        dialogAnim.setInterpolator(new DecelerateInterpolator());
        
        dialogContainer.startAnimation(dialogAnim);
    }

    private void dismissWithAnimation() {
        if (isPasswordEnabled && !isPasswordVerified) return;
        
        
        AlphaAnimation bgAnim = new AlphaAnimation(1, 0);
        bgAnim.setDuration(300);
        bgAnim.setInterpolator(new AccelerateInterpolator());
        findViewById(android.R.id.content).startAnimation(bgAnim);

        
        AnimationSet dialogAnim = new AnimationSet(true);
        
        
        ScaleAnimation scaleAnim = new ScaleAnimation(
                1f, 0.95f, 1f, 0.95f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        scaleAnim.setDuration(250);
        
        
        AlphaAnimation alphaAnim = new AlphaAnimation(1, 0);
        alphaAnim.setDuration(250);
        
        
        TranslateAnimation translateAnim = new TranslateAnimation(
                0, 0, 0, dpToPx(20));
        translateAnim.setDuration(250);
        
        dialogAnim.addAnimation(scaleAnim);
        dialogAnim.addAnimation(alphaAnim);
        dialogAnim.addAnimation(translateAnim);
        dialogAnim.setInterpolator(new AccelerateInterpolator());
        
        dialogAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}
            
            @Override
            public void onAnimationEnd(Animation animation) {
                dismiss();
            }
            
            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
        
        dialogContainer.startAnimation(dialogAnim);
    }

    private void verifyPassword() {
        String input = passwordInput.getText().toString().trim();
        if (TextUtils.isEmpty(input)) {
            Toast.makeText(activity, "不能为空", Toast.LENGTH_SHORT).show();
        } else if (input.equals(password)) {
            isPasswordVerified = true;
            Toast.makeText(activity, "验证成功", Toast.LENGTH_SHORT).show();
            dismissWithAnimation();
        } else {
            Toast.makeText(activity, "验证失败", Toast.LENGTH_SHORT).show();
        }
    }

    private int dpToPx(int dp) {
        float density = activity.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private String parseButtonText(String buttonText) {
        if (buttonText.contains("#")) {
            return buttonText.split("#")[0];
        }
        return buttonText;
    }

    public void parseCloudConfig(String text) {
        try {
            Pattern p;
            Matcher m;

            p = Pattern.compile("〈总开关〉(.*?)〈总开关〉");
            m = p.matcher(text);
            if (m.find()) isMasterSwitchOn = "开".equals(m.group(1).trim());

            p = Pattern.compile("〈密码开关〉(.*?)〈密码开关〉");
            m = p.matcher(text);
            if (m.find()) isPasswordEnabled = "开".equals(m.group(1).trim());

            p = Pattern.compile("〈密码〉(.*?)〈密码〉");
            m = p.matcher(text);
            if (m.find()) password = m.group(1).trim();

            p = Pattern.compile("〈标题〉(.*?)〈标题〉");
            m = p.matcher(text);
            if (m.find()) title = m.group(1).trim();

            p = Pattern.compile("〈内容〉([\\s\\S]*?)〈内容〉");
            m = p.matcher(text);
            if (m.find()) content = m.group(1).trim();

            p = Pattern.compile("〈按钮1〉(.*?)〈按钮1〉");
            m = p.matcher(text);
            if (m.find()) button1Text = m.group(1).trim();

            p = Pattern.compile("〈按钮2〉(.*?)〈按钮2〉");
            m = p.matcher(text);
            if (m.find()) button2Text = m.group(1).trim();

        } catch (Exception e) {
            content = "配置解析失败";
            e.printStackTrace();
        }
    }

    private void updateUI() {
        titleView.setText(title);
        contentView.setText(content);
        passwordLayout.setVisibility(isPasswordEnabled ? View.VISIBLE : View.GONE);
        if (button2 != null) {
            button2.setVisibility(isPasswordEnabled ? View.GONE : View.VISIBLE);
            button2.setText(parseButtonText(button2Text));
        }
    }

    public void showWithConfig() {
        super.show();
        updateUI();
    }

    @Override
    public void onBackPressed() {
        if (!isPasswordEnabled || isPasswordVerified) super.onBackPressed();
    }

    public static void show(Activity activity, String cloudControlUrl) {
        new LoadCloudConfigTask(activity, cloudControlUrl).execute();
    }

    private static class LoadCloudConfigTask extends AsyncTask<Void, Void, String> {
        private final Activity activity;
        private final String url;

        LoadCloudConfigTask(Activity activity, String url) {
            this.activity = activity;
            this.url = url;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(5000);
                conn.setRequestMethod("GET");
                conn.connect();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line).append("\n");
                }
                return result.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (response != null && response.contains("［云控弹窗］")) {
                CloudControlDialog dialog = new CloudControlDialog(activity);
                dialog.parseCloudConfig(response);
                if (dialog.isMasterSwitchOn) {
                    dialog.showWithConfig();
                }
            } else {
                Toast.makeText(activity, "无法连接服务器，请检查网络", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
