#调用
invoke-static {p0}, Lcom/w/m/c;->init(Landroid/content/Context;)V
#帖子链接，里面详细讲了使用方法弹窗更新反馈都可以去主页联系我
# https://bbs.binmt.cc/forum.php?mod=viewthread&tid=150623